package com.jonny.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.settings.GameSettings;
import org.lwjgl.opengl.Display;

/** Applies graphics toggles and can always restore the player's original settings. */
public class GfxTuner {
    private static boolean snap;
    private static boolean oFancy, oShadows, oVsync;
    private static int oClouds, oAO, oParticle, oLimit, oRender;

    private static void snapshot(GameSettings s) {
        if (snap) return;
        oFancy = s.fancyGraphics;
        oShadows = s.entityShadows;
        oVsync = s.enableVsync;
        oClouds = s.clouds;
        oAO = s.ambientOcclusion;
        oParticle = s.particleSetting;
        oLimit = s.limitFramerate;
        oRender = s.renderDistanceChunks;
        snap = true;
    }

    public static void apply() {
        Minecraft mc = Minecraft.getMinecraft();
        GameSettings s = mc.gameSettings;
        if (s == null) return;
        snapshot(s);

        s.fancyGraphics = Feature.GFX_FAST.enabled ? false : oFancy;
        s.clouds = Feature.GFX_NO_CLOUDS.enabled ? 0 : oClouds;
        s.ambientOcclusion = Feature.GFX_NO_AO.enabled ? 0 : oAO;
        s.entityShadows = Feature.GFX_NO_SHADOWS.enabled ? false : oShadows;
        s.particleSetting = Feature.LOW_PARTICLES.enabled ? 2 : oParticle;

        if (Feature.GFX_UNCAP.enabled) {
            s.enableVsync = false;
            s.limitFramerate = 260;
        } else {
            s.enableVsync = oVsync;
            s.limitFramerate = oLimit;
        }
        try { Display.setVSyncEnabled(s.enableVsync); } catch (Throwable ignored) {}

        if (Config.renderDistance > 0 && s.renderDistanceChunks != Config.renderDistance) {
            s.renderDistanceChunks = Config.renderDistance;
            if (mc.renderGlobal != null) mc.renderGlobal.setDisplayListEntitiesDirty();
        }
    }

    /** Safe max-FPS preset. Leaves lighting, shadows, VBO and mipmaps alone. */
    public static void applyMaxFpsPreset() {
        Feature.ENTITY_CULLING.enabled = true;
        Feature.NAMETAG_CULLING.enabled = true;
        Feature.NO_WEATHER.enabled = true;
        Feature.LOW_FIRE.enabled = true;
        Feature.UNFOCUSED_LIMIT.enabled = true;
        Feature.GFX_FAST.enabled = true;
        Feature.GFX_NO_CLOUDS.enabled = true;
        Feature.LOW_PARTICLES.enabled = true;
        Feature.GFX_UNCAP.enabled = true;
        Feature.ENTITY_SCALE.enabled = true;
        Feature.PARTICLE_CAP.enabled = true;
        Feature.TILE_CULLING.enabled = true;
        Feature.PARTICLE_DIST.enabled = true;
        Feature.NO_ANIM_TEXTURES.enabled = true;
        Feature.NO_GLINT.enabled = true;
        Config.tileDistance = 24;
        Config.particleDistance = 20;
        Config.entityScale = 60;
        Config.particleCap = 200;
        Config.cullDistance = 48;
        Config.renderDistance = 8;
        apply();
        Config.save();
    }

    public static void resetAll() {
        for (Feature f : Feature.values()) f.enabled = f.def;
        Config.cullDistance = 64;
        Config.nametagDistance = 32;
        Config.renderDistance = 0;
        Config.entityScale = 75;
        Config.particleCap = 300;
        Config.tileDistance = 32;
        Config.particleDistance = 24;
        apply();
        GameSettings s = Minecraft.getMinecraft().gameSettings;
        if (snap && s != null && s.renderDistanceChunks != oRender) {
            s.renderDistanceChunks = oRender;
            if (Minecraft.getMinecraft().renderGlobal != null)
                Minecraft.getMinecraft().renderGlobal.setDisplayListEntitiesDirty();
        }
        Config.save();
    }
}
