package com.jonny.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.client.resources.I18n;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.item.ItemPotion;
import net.minecraft.item.ItemStack;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.MathHelper;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.List;

public class HudMods {
    public static final List<HudMod> ALL = new ArrayList<HudMod>();

    private static HudMod add(HudMod m) { ALL.add(m); return m; }

    private static int count(EntityPlayer p, Item item) {
        int n = 0;
        for (ItemStack s : p.inventory.mainInventory) if (s != null && s.getItem() == item) n += s.stackSize;
        return n;
    }

    private static final SimpleDateFormat CLOCK = new SimpleDateFormat("hh:mm a");

    public static final HudMod FPS = add(new HudMod("fps", "FPS", "Frames per second", true, 6, 6) {
        protected List<String[]> rows(Minecraft mc) { return one("FPS", String.valueOf(Minecraft.getDebugFPS())); }
    });

    public static final HudMod CPS = add(new HudMod("cps", "CPS", "Left | right clicks per second", true, 6, 24) {
        protected List<String[]> rows(Minecraft mc) { return one("CPS", Stats.left() + " | " + Stats.right()); }
    });

    public static final HudMod PING = add(new HudMod("ping", "Ping", "Your latency to the server", true, 6, 42) {
        protected List<String[]> rows(Minecraft mc) {
            int ping = 0;
            if (mc.thePlayer != null && mc.getNetHandler() != null) {
                net.minecraft.client.network.NetworkPlayerInfo info = mc.getNetHandler().getPlayerInfo(mc.thePlayer.getUniqueID());
                if (info != null) ping = info.getResponseTime();
            }
            return one("Ping", ping + " ms");
        }
    });

    public static final HudMod COORDS = add(new HudMod("coords", "Coordinates", "Your X Y Z position", false, 6, 60) {
        protected List<String[]> rows(Minecraft mc) {
            EntityPlayer p = mc.thePlayer;
            if (p == null) return one("XYZ", "0 0 0");
            return one("XYZ", MathHelper.floor_double(p.posX) + " " + MathHelper.floor_double(p.posY) + " " + MathHelper.floor_double(p.posZ));
        }
    });

    public static final HudMod DIRECTION = add(new HudMod("direction", "Direction", "Compass direction you face", false, 6, 78) {
        protected List<String[]> rows(Minecraft mc) {
            if (mc.thePlayer == null) return one("Facing", "North");
            EnumFacing f = EnumFacing.fromAngle(mc.thePlayer.rotationYaw);
            String n = f.getName();
            n = Character.toUpperCase(n.charAt(0)) + n.substring(1);
            int yaw = Math.round(MathHelper.wrapAngleTo180_float(mc.thePlayer.rotationYaw));
            return one("Facing", n + " " + yaw);
        }
    });

    public static final HudMod SPEED = add(new HudMod("speed", "Speed", "Blocks per second", false, 6, 96) {
        protected List<String[]> rows(Minecraft mc) {
            return one("Speed", String.format("%.1f b/s", Stats.speed));
        }
    });

    public static final HudMod CLOCK_MOD = add(new HudMod("clock", "Clock", "Real-world time", false, 6, 114) {
        protected List<String[]> rows(Minecraft mc) { return one("Time", CLOCK.format(new Date())); }
    });

    public static final HudMod MEMORY = add(new HudMod("memory", "Memory", "Java memory used", false, 6, 132) {
        protected List<String[]> rows(Minecraft mc) {
            Runtime rt = Runtime.getRuntime();
            long used = (rt.totalMemory() - rt.freeMemory()) / 1048576L;
            return one("RAM", used + " / " + (rt.maxMemory() / 1048576L) + " MB");
        }
    });

    public static final HudMod SERVER = add(new HudMod("server", "Server IP", "The server you are on", false, 6, 150) {
        protected List<String[]> rows(Minecraft mc) {
            net.minecraft.client.multiplayer.ServerData sd = mc.getCurrentServerData();
            return one("IP", sd == null ? "Singleplayer" : sd.serverIP);
        }
    });

    public static final HudMod COMBO = add(new HudMod("combo", "Combo", "Hits in a row", false, 6, 168) {
        protected List<String[]> rows(Minecraft mc) { return one("Combo", String.valueOf(Stats.combo)); }
    });

    public static final HudMod REACH = add(new HudMod("reach", "Reach", "Distance of your last hit", false, 6, 186) {
        protected List<String[]> rows(Minecraft mc) {
            return one("Reach", Stats.reach <= 0 ? "-" : String.format("%.2f", Stats.reach));
        }
    });

    public static final HudMod BW_RESOURCES = add(new HudMod("bwres", "Bedwars Resources", "Iron, gold, diamond, emerald", false, 6, 204) {
        protected List<String[]> rows(Minecraft mc) {
            List<String[]> l = new ArrayList<String[]>();
            EntityPlayer p = mc.thePlayer;
            if (p == null) return l;
            l.add(new String[]{"Iron", String.valueOf(count(p, Items.iron_ingot))});
            l.add(new String[]{"Gold", String.valueOf(count(p, Items.gold_ingot))});
            l.add(new String[]{"Diamond", String.valueOf(count(p, Items.diamond))});
            l.add(new String[]{"Emerald", String.valueOf(count(p, Items.emerald))});
            return l;
        }
    });

    public static final HudMod POTS = add(new HudMod("pots", "Pot Counter", "Potions in your inventory", false, 6, 252) {
        protected List<String[]> rows(Minecraft mc) {
            int n = 0;
            if (mc.thePlayer != null)
                for (ItemStack s : mc.thePlayer.inventory.mainInventory)
                    if (s != null && s.getItem() instanceof ItemPotion) n += s.stackSize;
            return one("Pots", String.valueOf(n));
        }
    });

    public static final HudMod ARROWS = add(new HudMod("arrows", "Arrow Counter", "Arrows in your inventory", false, 6, 270) {
        protected List<String[]> rows(Minecraft mc) {
            return one("Arrows", String.valueOf(mc.thePlayer == null ? 0 : count(mc.thePlayer, Items.arrow)));
        }
    });

    public static final HudMod KEYSTROKES = add(new HudMod("keys", "Keystrokes", "WASD, space and mouse buttons", true, 6, 64) {
        private void key(String label, boolean down, int x, int y, int kw, int kh) {
            UI.rrect(x, y, kw, kh, 3, down ? 0xC8FFFFFF : 0x78000000);
            int tw = UI.hudWidth(label);
            UI.hudText(label, x + (kw - tw) / 2, y + (kh - 9) / 2, down ? 0xFF111111 : 0xFFFFFFFF);
        }
        protected void render(Minecraft mc, boolean editor) {
            net.minecraft.client.settings.GameSettings gs = mc.gameSettings;
            w = 72; h = 84;
            key("W", gs.keyBindForward.isKeyDown(), 25, 0, 22, 22);
            key("A", gs.keyBindLeft.isKeyDown(), 0, 24, 22, 22);
            key("S", gs.keyBindBack.isKeyDown(), 25, 24, 22, 22);
            key("D", gs.keyBindRight.isKeyDown(), 50, 24, 22, 22);
            key("LMB " + Stats.left(), gs.keyBindAttack.isKeyDown(), 0, 48, 35, 22);
            key("RMB " + Stats.right(), gs.keyBindUseItem.isKeyDown(), 37, 48, 35, 22);
            key("-----", gs.keyBindJump.isKeyDown(), 0, 72, 72, 12);
        }
    });

    public static final HudMod ARMOR = add(new HudMod("armor", "Armor Status", "Armor and held item durability", true, 6, 160) {
        protected void render(Minecraft mc, boolean editor) {
            w = 56; h = 5 * 18;
            EntityPlayer p = mc.thePlayer;
            if (p == null) return;
            ItemStack[] stacks = new ItemStack[5];
            stacks[0] = p.getHeldItem();
            for (int i = 0; i < 4; i++) stacks[i + 1] = p.inventory.armorInventory[3 - i];
            int yy = 0;
            boolean any = false;
            for (ItemStack s : stacks) {
                if (s == null) continue;
                any = true;
                if (bg) UI.rrect(0, yy, w, 17, 3, 0x78000000);
                RenderHelper.enableGUIStandardItemLighting();
                mc.getRenderItem().renderItemAndEffectIntoGUI(s, 1, yy);
                RenderHelper.disableStandardItemLighting();
                GlStateManager.disableLighting();
                String t = s.getMaxDamage() > 0 ? String.valueOf(s.getMaxDamage() - s.getItemDamage()) : "";
                if (s.stackSize > 1) t = "x" + s.stackSize;
                float frac = s.getMaxDamage() > 0 ? (s.getMaxDamage() - s.getItemDamage()) / (float) s.getMaxDamage() : 1f;
                int col = frac > 0.5f ? 0xFF55FF55 : (frac > 0.25f ? 0xFFFFFF55 : 0xFFFF5555);
                UI.hudText(t, 20, yy + 4, col);
                yy += 18;
            }
            if (!any && editor) {
                UI.rrect(0, 0, w, 17, 3, 0x78000000);
                UI.hudText("Armor", 6, 4, 0xFFFFFFFF);
            }
            GlStateManager.enableAlpha();
            GlStateManager.disableBlend();
        }
    });

    public static final HudMod POTIONS = add(new HudMod("potions", "Potion Status", "Active potion effects", true, 6, 262) {
        protected List<String[]> rows(Minecraft mc) {
            List<String[]> l = new ArrayList<String[]>();
            if (mc.thePlayer == null) return l;
            Collection<PotionEffect> fx = mc.thePlayer.getActivePotionEffects();
            for (PotionEffect e : fx) {
                String n = I18n.format(e.getEffectName());
                if (e.getAmplifier() > 0) n += " " + (e.getAmplifier() + 1);
                l.add(new String[]{n, net.minecraft.potion.Potion.getDurationString(e)});
            }
            return l;
        }
    });

    public static void resetAll() { for (HudMod m : ALL) { m.enabled = m.defEnabled; m.resetPosition(); } }
}
