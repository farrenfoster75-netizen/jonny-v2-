package com.jonny.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Gui;

/** Drawing helpers shared by the menu and the HUD. */
public class UI {
    public static final int[] ACCENTS = {0x4DA3FF, 0xA66BFF, 0x3DDC84, 0xFF5C6C, 0xFFA63D, 0xFF6BC1};
    public static final String[] ACCENT_NAMES = {"Blue", "Purple", "Green", "Red", "Orange", "Pink"};
    public static final float HUD_SIZE = 9f;
    public static final int LINE_H = 11;

    public static int accent() { return ACCENTS[Math.floorMod(Config.accentIdx, ACCENTS.length)]; }

    public static void rrect(int x, int y, int w, int h, int r, int c) {
        r = Math.min(r, Math.min(w, h) / 2);
        if (r <= 0) { Gui.drawRect(x, y, x + w, y + h, c); return; }
        Gui.drawRect(x, y + r, x + w, y + h - r, c);
        for (int i = 0; i < r; i++) {
            double dy = r - i - 0.5;
            int inset = (int) Math.round(r - Math.sqrt(r * r - dy * dy));
            Gui.drawRect(x + inset, y + i, x + w - inset, y + i + 1, c);
            Gui.drawRect(x + inset, y + h - 1 - i, x + w - inset, y + h - i, c);
        }
    }

    public static float width(String s, float size, boolean bold) {
        return (bold ? ModernFont.BOLD : ModernFont.REG).width(s, size);
    }

    public static float height(float size) { return ModernFont.REG.height(size); }

    public static void text(String s, float x, float y, float size, int argb, boolean bold, boolean shadow) {
        (bold ? ModernFont.BOLD : ModernFont.REG).draw(s, x, y, size, argb, shadow);
    }

    /** HUD text: modern font when enabled, vanilla font otherwise. */
    public static void hudText(String s, int x, int y, int argb) {
        if (Config.modernFont) ModernFont.REG.draw(s, x, y, HUD_SIZE, argb, true);
        else Minecraft.getMinecraft().fontRendererObj.drawStringWithShadow(s, x, y, argb);
    }

    public static int hudWidth(String s) {
        if (Config.modernFont) return Math.round(ModernFont.REG.width(s, HUD_SIZE));
        return Minecraft.getMinecraft().fontRendererObj.getStringWidth(s);
    }

    public static int withAlpha(int rgb, int a) { return (Math.max(0, Math.min(255, a)) << 24) | (rgb & 0xFFFFFF); }
}
