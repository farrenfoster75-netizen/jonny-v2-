package com.jonny.client;

public enum Feature {
    // ---- PvP & utility ----
    TOGGLE_SPRINT(Category.PVP, "Toggle Sprint", "Auto-sprint while moving forward", true, false),
    TOGGLE_SNEAK(Category.PVP, "Toggle Sneak", "Tap a key to sneak (bind it in Controls)", false, false),
    FULLBRIGHT(Category.PVP, "Fullbright", "Maximum brightness everywhere", false, false),
    ZOOM(Category.PVP, "Zoom", "Hold C to zoom in", true, false),
    BLOCK_OUTLINE(Category.PVP, "Block Outline", "Colored outline using your accent color", true, false),
    CROSSHAIR(Category.PVP, "Custom Crosshair", "Replaces the vanilla crosshair", false, false),
    TIME_CHANGER(Category.PVP, "Time Changer", "Client-side time of day", false, false),
    HITBOXES(Category.PVP, "Show Hitboxes", "Entity hitboxes (costs FPS)", false, false),

    // ---- FPS boost ----
    ENTITY_CULLING(Category.FPS, "Entity Distance Culling", "Stop drawing far-away entities", true, false),
    ENTITY_SCALE(Category.FPS, "Short Entity Render Distance", "Items, arrows and mobs render closer", true, false),
    NAMETAG_CULLING(Category.FPS, "Nametag Culling", "Hide far-away nametags", true, false),
    PARTICLE_CAP(Category.FPS, "Particle Cap", "Hard limit on live particles", true, false),
    OCCLUSION_CULLING(Category.FPS, "Occlusion Culling (Beta)", "Skip entities hidden behind walls", false, false),
    ARMOR_STAND_CULL(Category.FPS, "Hide Armor Stands", "Also hides hologram text", false, false),
    TILE_CULLING(Category.FPS, "Tile Entity Culling", "Skip far chests, beds, banners, signs (Mixin)", true, false),
    PARTICLE_DIST(Category.FPS, "Particle Distance Culling", "Skip drawing far particles (Mixin)", true, false),
    NO_ANIM_TEXTURES(Category.FPS, "Freeze Animated Textures", "Water, lava and fire stop animating (Mixin)", false, false),
    NO_GLINT(Category.FPS, "Disable Enchant Glint", "Removes glint on armor and items (Mixin)", false, false),
    NO_WEATHER(Category.FPS, "Disable Weather", "No rain or thunder", true, false),
    LOW_FIRE(Category.FPS, "Low Fire Overlay", "Removes the fire screen overlay", true, false),
    UNFOCUSED_LIMIT(Category.FPS, "Unfocused FPS Limit", "30 FPS while tabbed out", true, false),

    // ---- Graphics ----
    GFX_FAST(Category.GRAPHICS, "Fast Graphics", "Turns off fancy graphics", true, true),
    GFX_NO_CLOUDS(Category.GRAPHICS, "No Clouds", "Removes clouds", true, true),
    LOW_PARTICLES(Category.GRAPHICS, "Minimal Particles", "Fewer particles from the game", true, true),
    GFX_UNCAP(Category.GRAPHICS, "Uncap FPS / No VSync", "Removes the frame cap", true, true),
    GFX_NO_AO(Category.GRAPHICS, "Flat Lighting", "Turns off smooth lighting", false, true),
    GFX_NO_SHADOWS(Category.GRAPHICS, "No Entity Shadows", "Removes the blob shadows", false, true);

    public enum Category {
        PVP("PVP & UTILITY"), FPS("FPS BOOST"), GRAPHICS("GRAPHICS");
        public final String title;
        Category(String title) { this.title = title; }
    }

    public final Category category;
    public final String label;
    public final String desc;
    public final boolean def;
    public final boolean gfx;
    public boolean enabled;

    Feature(Category category, String label, String desc, boolean def, boolean gfx) {
        this.category = category;
        this.label = label;
        this.desc = desc;
        this.def = def;
        this.gfx = gfx;
        this.enabled = def;
    }
}
