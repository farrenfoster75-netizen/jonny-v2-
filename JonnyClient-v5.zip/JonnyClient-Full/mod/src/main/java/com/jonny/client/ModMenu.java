package com.jonny.client;

import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.GlStateManager;
import org.lwjgl.input.Mouse;
import org.lwjgl.opengl.GL11;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.function.BooleanSupplier;
import java.util.function.IntConsumer;
import java.util.function.IntSupplier;

/** Modern mod menu: sidebar, animated switches, expandable HUD mod cards, smooth scrolling. */
public class ModMenu extends GuiScreen {
    private enum Tab {
        HUD("HUD MODS"), PVP("PVP & UTILITY"), FPS("FPS BOOST"), GFX("GRAPHICS"), SETTINGS("SETTINGS");
        final String title;
        Tab(String title) { this.title = title; }
    }

    private static final int BG = 0x0E1016, PANEL = 0x141720, ROW = 0x1A1E2A, ROW_HOVER = 0x232838,
            TEXT = 0xEDEFF5, SUB = 0x8B93A7, OFF = 0x384056;
    private static final int SB = 132;
    private static Tab lastTab = Tab.HUD;
    private static final Set<String> expanded = new HashSet<String>();

    private Tab tab = lastTab;
    private float scrollPos, scrollTarget;
    private int maxScroll;
    private final long openTime = System.currentTimeMillis();
    private float alpha = 1f;
    private int px, py, pw, ph, cx, cy, cw, ch;
    private Item dragging;
    private int dragX, dragW;
    private final Map<String, Float> anim = new HashMap<String, Float>();

    // ------------------------------------------------------------ helpers
    private int ca(int rgb) { return (((int) (alpha * 255)) << 24) | (rgb & 0xFFFFFF); }
    private int ac(int rgb, int a) { return (((int) (alpha * a)) << 24) | (rgb & 0xFFFFFF); }
    private void t(String s, float x, float y, float size, int rgb, boolean bold) { UI.text(s, x, y, size, ca(rgb), bold, false); }
    private float tw(String s, float size, boolean bold) { return UI.width(s, size, bold); }
    private static boolean in(int mx, int my, int x, int y, int w, int h) { return mx >= x && mx < x + w && my >= y && my < y + h; }
    private boolean inContent(int mx, int my) { return in(mx, my, cx, cy, cw, ch); }

    private static int mix(int c1, int c2, float f) {
        int r = (int) (((c1 >> 16) & 255) * (1 - f) + ((c2 >> 16) & 255) * f);
        int g = (int) (((c1 >> 8) & 255) * (1 - f) + ((c2 >> 8) & 255) * f);
        int b = (int) ((c1 & 255) * (1 - f) + (c2 & 255) * f);
        return (r << 16) | (g << 8) | b;
    }

    private float anim(String key, boolean on) {
        Float c = anim.get(key);
        float cur = c == null ? (on ? 1f : 0f) : c;
        float tgt = on ? 1f : 0f;
        cur += (tgt - cur) * 0.28f;
        if (Math.abs(tgt - cur) < 0.01f) cur = tgt;
        anim.put(key, cur);
        return cur;
    }

    private void drawSwitch(int x, int y, boolean on, String key) {
        float a = anim(key, on);
        UI.rrect(x, y, 32, 16, 8, ca(mix(OFF, UI.accent(), a)));
        UI.rrect(x + 2 + Math.round(16 * a), y + 2, 12, 12, 6, ca(0xFFFFFF));
    }

    private void drawTrack(int x, int y, int w, float frac) {
        frac = Math.max(0f, Math.min(1f, frac));
        int fw = (int) (w * frac);
        UI.rrect(x, y, w, 4, 2, ca(OFF));
        UI.rrect(x, y, Math.max(fw, 3), 4, 2, ca(UI.accent()));
        UI.rrect(x + fw - 5, y - 3, 10, 10, 5, ca(0xFFFFFF));
    }

    // ------------------------------------------------------------ rows
    private abstract class Item {
        abstract int step();
        abstract void draw(int x, int y, int w, int mx, int my);
        void click(int x, int y, int w, int mx, int my) {}
        void drag(int mx) {}
    }

    private abstract class SwitchRow extends Item {
        final String key, label, desc;
        SwitchRow(String key, String label, String desc) { this.key = key; this.label = label; this.desc = desc; }
        abstract boolean on();
        abstract void toggle();
        int step() { return 38; }
        void draw(int x, int y, int w, int mx, int my) {
            boolean hov = inContent(mx, my) && in(mx, my, x, y, w, 34);
            UI.rrect(x, y, w, 34, 6, ca(hov ? ROW_HOVER : ROW));
            t(label, x + 12, y + 5, 10f, TEXT, true);
            t(desc, x + 12, y + 19, 8f, SUB, false);
            drawSwitch(x + w - 44, y + 9, on(), key);
        }
        void click(int x, int y, int w, int mx, int my) { toggle(); }
    }

    private class FeatureRow extends SwitchRow {
        final Feature f;
        FeatureRow(Feature f) { super("f:" + f.name(), f.label, f.desc); this.f = f; }
        boolean on() { return f.enabled; }
        void toggle() {
            f.enabled = !f.enabled;
            if (f.gfx) GfxTuner.apply();
            if (f == Feature.ENTITY_SCALE) Events.refreshEntityWeights();
            Config.save();
        }
    }

    private class BoolRow extends SwitchRow {
        final BooleanSupplier get; final Runnable flip;
        BoolRow(String key, String label, String desc, BooleanSupplier get, Runnable flip) {
            super(key, label, desc); this.get = get; this.flip = flip;
        }
        boolean on() { return get.getAsBoolean(); }
        void toggle() { flip.run(); Config.save(); }
    }

    private class HudRow extends Item {
        final HudMod m;
        HudRow(HudMod m) { this.m = m; }
        boolean exp() { return expanded.contains(m.id); }
        int cardH() { return exp() ? 100 : 34; }
        int step() { return cardH() + 4; }
        void draw(int x, int y, int w, int mx, int my) {
            UI.rrect(x, y, w, cardH(), 6, ca(ROW));
            if (inContent(mx, my) && in(mx, my, x, y, w, 34)) UI.rrect(x, y, w, 34, 6, ca(ROW_HOVER));
            t(exp() ? "v" : ">", x + 12, y + 9, 10f, SUB, true);
            t(m.name, x + 28, y + 5, 10f, TEXT, true);
            t(m.desc, x + 28, y + 19, 8f, SUB, false);
            drawSwitch(x + w - 44, y + 9, m.enabled, "h:" + m.id);
            if (exp()) {
                int sy = y + 38;
                drawRect(x + 10, sy - 3, x + w - 10, sy - 2, ac(0xFFFFFF, 18));
                t("Scale", x + 12, sy + 2, 9f, TEXT, false);
                String v = m.scale + "%";
                t(v, x + w - 12 - tw(v, 9f, false), sy + 2, 9f, UI.accent(), false);
                drawTrack(x + 12, sy + 20, w - 24, (m.scale - 50) / 150f);
                t("Background", x + 12, sy + 36, 9f, TEXT, false);
                drawSwitch(x + w - 44, sy + 33, m.bg, "hb:" + m.id);
            }
        }
        void click(int x, int y, int w, int mx, int my) {
            if (my < y + 34) {
                if (mx >= x + w - 52) { m.enabled = !m.enabled; Config.save(); }
                else if (exp()) expanded.remove(m.id);
                else expanded.add(m.id);
                return;
            }
            int sy = y + 38;
            if (in(mx, my, x + 8, sy + 12, w - 16, 20)) { dragging = this; dragX = x; dragW = w; drag(mx); return; }
            if (in(mx, my, x + 8, sy + 30, w - 16, 24)) { m.bg = !m.bg; Config.save(); }
        }
        void drag(int mx) {
            float p = (mx - (dragX + 12)) / (float) (dragW - 24);
            p = Math.max(0f, Math.min(1f, p));
            m.scale = 50 + 5 * Math.round(p * 30f);
        }
    }

    private class SliderRow extends Item {
        final String label, suffix; final int min, max; final IntSupplier get; final IntConsumer set;
        SliderRow(String label, String suffix, int min, int max, IntSupplier get, IntConsumer set) {
            this.label = label; this.suffix = suffix; this.min = min; this.max = max; this.get = get; this.set = set;
        }
        int step() { return 44; }
        void draw(int x, int y, int w, int mx, int my) {
            UI.rrect(x, y, w, 40, 6, ca(ROW));
            t(label, x + 12, y + 6, 10f, TEXT, true);
            String v = get.getAsInt() + suffix;
            t(v, x + w - 12 - tw(v, 10f, true), y + 6, 10f, UI.accent(), true);
            drawTrack(x + 12, y + 28, w - 24, (get.getAsInt() - min) / (float) (max - min));
        }
        void click(int x, int y, int w, int mx, int my) { dragging = this; dragX = x; dragW = w; drag(mx); }
        void drag(int mx) {
            float p = (mx - (dragX + 12)) / (float) (dragW - 24);
            p = Math.max(0f, Math.min(1f, p));
            set.accept(Math.round(min + p * (max - min)));
        }
    }

    private class BtnRow extends Item {
        final java.util.function.Supplier<String> label; final Runnable action;
        BtnRow(java.util.function.Supplier<String> label, Runnable action) { this.label = label; this.action = action; }
        int step() { return 34; }
        void draw(int x, int y, int w, int mx, int my) {
            boolean hov = inContent(mx, my) && in(mx, my, x, y, w, 30);
            UI.rrect(x, y, w, 30, 6, ac(UI.accent(), 140));
            UI.rrect(x + 1, y + 1, w - 2, 28, 5, ca(hov ? ROW_HOVER : ROW));
            String s = label.get();
            t(s, x + (w - tw(s, 10f, true)) / 2f, y + 8, 10f, UI.accent(), true);
        }
        void click(int x, int y, int w, int mx, int my) { action.run(); Config.save(); }
    }

    private class HeaderRow extends Item {
        final String text;
        HeaderRow(String text) { this.text = text; }
        int step() { return 22; }
        void draw(int x, int y, int w, int mx, int my) { t(text, x + 4, y + 2, 8f, SUB, true); }
    }

    private BtnRow btn(String label, Runnable r) { return new BtnRow(() -> label, r); }

    private List<Item> items() {
        List<Item> l = new ArrayList<Item>();
        switch (tab) {
            case HUD:
                l.add(btn("Edit HUD Layout  (drag & drop)", () -> mc.displayGuiScreen(new HudEditor())));
                l.add(new HeaderRow("CLICK A MOD TO OPEN ITS SCALE AND BACKGROUND OPTIONS"));
                for (HudMod m : HudMods.ALL) l.add(new HudRow(m));
                break;
            case PVP:
                for (Feature f : Feature.values()) if (f.category == Feature.Category.PVP) l.add(new FeatureRow(f));
                l.add(new HeaderRow("OPTIONS"));
                l.add(new SliderRow("Time of day", "", 0, 24000, () -> Config.timeValue, v -> Config.timeValue = v));
                l.add(new BtnRow(() -> "Crosshair style: " + new String[]{"Cross", "Dot", "Plus"}[Math.floorMod(Config.crosshairStyle, 3)] + "  (click)",
                        () -> Config.crosshairStyle = (Config.crosshairStyle + 1) % 3));
                break;
            case FPS:
                l.add(btn("Apply MAX FPS Preset", GfxTuner::applyMaxFpsPreset));
                for (Feature f : Feature.values()) if (f.category == Feature.Category.FPS) l.add(new FeatureRow(f));
                l.add(new HeaderRow("TUNING"));
                l.add(new SliderRow("Entity cull distance", "", 16, 128, () -> Config.cullDistance, v -> Config.cullDistance = v));
                l.add(new SliderRow("Entity render distance", "%", 25, 100, () -> Config.entityScale,
                        v -> { Config.entityScale = v; Events.refreshEntityWeights(); }));
                l.add(new SliderRow("Nametag distance", "", 8, 64, () -> Config.nametagDistance, v -> Config.nametagDistance = v));
                l.add(new SliderRow("Tile entity distance", "", 8, 64, () -> Config.tileDistance, v -> Config.tileDistance = v));
                l.add(new SliderRow("Particle draw distance", "", 8, 64, () -> Config.particleDistance, v -> Config.particleDistance = v));
                l.add(new SliderRow("Particle cap", "", 50, 1000, () -> Config.particleCap, v -> Config.particleCap = v));
                l.add(new SliderRow("Render distance (chunks)", "", 2, 16, () -> mc.gameSettings.renderDistanceChunks,
                        v -> { Config.renderDistance = v; GfxTuner.apply(); }));
                break;
            case GFX:
                for (Feature f : Feature.values()) if (f.category == Feature.Category.GRAPHICS) l.add(new FeatureRow(f));
                break;
            default:
                l.add(new BoolRow("s:font", "Modern HUD font", "Smooth Segoe UI text on the HUD",
                        () -> Config.modernFont, () -> Config.modernFont = !Config.modernFont));
                l.add(new BtnRow(() -> "Accent color: " + UI.ACCENT_NAMES[Math.floorMod(Config.accentIdx, UI.ACCENTS.length)] + "  (click)",
                        () -> Config.accentIdx = (Config.accentIdx + 1) % UI.ACCENTS.length));
                l.add(btn("Reset HUD positions and options", HudMods::resetAll));
                l.add(btn("Reset everything to default", () -> { HudMods.resetAll(); GfxTuner.resetAll(); Events.refreshEntityWeights(); }));
                break;
        }
        return l;
    }

    private String subtitle() {
        switch (tab) {
            case HUD: {
                int n = 0;
                for (HudMod m : HudMods.ALL) if (m.enabled) n++;
                return n + " of " + HudMods.ALL.size() + " HUD mods enabled";
            }
            case PVP: return "Combat and utility mods";
            case FPS: return "Performance systems and tuning";
            case GFX: return "Game graphics toggles (all restorable)";
            default: return "Look and reset options";
        }
    }

    // ------------------------------------------------------------ screen
    @Override
    public void initGui() {
        pw = Math.min(width - 20, 580);
        ph = Math.min(height - 20, 350);
        px = (width - pw) / 2;
        py = (height - ph) / 2;
        cx = px + SB + 14;
        cy = py + 50;
        cw = pw - SB - 28;
        ch = ph - 62;
    }

    @Override
    public void drawScreen(int mx, int my, float pt) {
        alpha = Math.max(0.12f, Math.min(1f, (System.currentTimeMillis() - openTime) / 220f));
        drawRect(0, 0, width, height, ((int) (alpha * 150)) << 24);

        GlStateManager.pushMatrix();
        GlStateManager.translate(0f, (1f - alpha) * 10f, 0f);

        UI.rrect(px - 1, py - 1, pw + 2, ph + 2, 10, ac(UI.accent(), 70));
        UI.rrect(px, py, pw, ph, 9, ca(BG));
        UI.rrect(px, py, SB, ph, 9, ca(PANEL));
        drawRect(px + SB - 9, py, px + SB, py + ph, ca(PANEL));

        // logo
        t("JONNY", px + 16, py + 14, 16f, TEXT, true);
        t("CLIENT", px + 16, py + 29, 12f, UI.accent(), true);

        // tabs
        Tab[] tabs = Tab.values();
        for (int i = 0; i < tabs.length; i++) {
            int ty = py + 62 + i * 28;
            boolean sel = tabs[i] == tab;
            boolean hov = in(mx, my, px + 10, ty, SB - 20, 24);
            if (sel) {
                UI.rrect(px + 10, ty, SB - 20, 24, 6, ac(UI.accent(), 45));
                UI.rrect(px + 10, ty + 5, 3, 14, 1, ca(UI.accent()));
            } else if (hov) UI.rrect(px + 10, ty, SB - 20, 24, 6, ca(ROW));
            t(tabs[i].title, px + 22, ty + 6, 9f, sel ? UI.accent() : TEXT, true);
        }
        t("Right Shift to close", px + 14, py + ph - 20, 8f, SUB, false);

        // header
        t(tab.title, cx, py + 13, 15f, TEXT, true);
        t(subtitle(), cx, py + 31, 8.5f, SUB, false);
        boolean xHover = in(mx, my, px + pw - 32, py + 12, 20, 20);
        UI.rrect(px + pw - 32, py + 12, 20, 20, 6, ca(xHover ? 0xD04050 : ROW));
        t("x", px + pw - 25, py + 15, 11f, TEXT, true);

        // content
        List<Item> list = items();
        int total = 0;
        for (Item it : list) total += it.step();
        maxScroll = Math.max(0, total - ch);
        scrollTarget = Math.max(0, Math.min(maxScroll, scrollTarget));
        scrollPos += (scrollTarget - scrollPos) * 0.28f;
        int scroll = Math.round(scrollPos);

        ScaledResolution sr = new ScaledResolution(mc);
        int f = sr.getScaleFactor();
        GL11.glEnable(GL11.GL_SCISSOR_TEST);
        GL11.glScissor(cx * f, (sr.getScaledHeight() - (cy + ch)) * f, cw * f, ch * f);
        int y = cy - scroll;
        int rw = cw - 8;
        for (Item it : list) {
            if (y + it.step() > cy - 50 && y < cy + ch + 50) it.draw(cx, y, rw, mx, my);
            y += it.step();
        }
        GL11.glDisable(GL11.GL_SCISSOR_TEST);

        if (maxScroll > 0) {
            int barH = Math.max(24, ch * ch / (ch + maxScroll));
            int barY = cy + (int) ((ch - barH) * (scroll / (float) maxScroll));
            UI.rrect(cx + cw - 3, barY, 3, barH, 1, ac(UI.accent(), 200));
        }

        GlStateManager.popMatrix();
        super.drawScreen(mx, my, pt);
    }

    @Override
    protected void mouseClicked(int mx, int my, int btn) throws IOException {
        super.mouseClicked(mx, my, btn);
        if (btn != 0) return;
        if (in(mx, my, px + pw - 32, py + 12, 20, 20)) { mc.displayGuiScreen(null); return; }
        Tab[] tabs = Tab.values();
        for (int i = 0; i < tabs.length; i++) {
            if (in(mx, my, px + 10, py + 62 + i * 28, SB - 20, 24)) {
                tab = tabs[i]; lastTab = tab; scrollTarget = 0; scrollPos = 0;
                return;
            }
        }
        if (!inContent(mx, my)) return;
        int y = cy - Math.round(scrollPos);
        int rw = cw - 8;
        for (Item it : items()) {
            int st = it.step();
            if (my >= y && my < y + st - 4 && mx >= cx && mx < cx + rw) { it.click(cx, y, rw, mx, my); return; }
            y += st;
        }
    }

    @Override
    protected void mouseClickMove(int mx, int my, int btn, long time) {
        if (dragging != null) dragging.drag(mx);
    }

    @Override
    protected void mouseReleased(int mx, int my, int state) {
        super.mouseReleased(mx, my, state);
        dragging = null;
        Config.save();
    }

    @Override
    public void handleMouseInput() throws IOException {
        super.handleMouseInput();
        int d = Mouse.getEventDWheel();
        if (d != 0) scrollTarget = Math.max(0, Math.min(maxScroll, scrollTarget - Integer.signum(d) * 40));
    }

    @Override
    public void onGuiClosed() { Config.save(); }

    @Override
    public boolean doesGuiPauseGame() { return false; }
}
