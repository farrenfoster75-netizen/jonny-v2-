package com.jonny.client.mixins;

import com.jonny.client.Feature;
import net.minecraft.client.renderer.entity.layers.LayerArmorBase;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(LayerArmorBase.class)
public class MixinLayerArmorBase {
    @Inject(method = "renderGlint", at = @At("HEAD"), cancellable = true, require = 0)
    private void jonny$noArmorGlint(CallbackInfo ci) {
        if (Feature.NO_GLINT.enabled) ci.cancel();
    }
}
