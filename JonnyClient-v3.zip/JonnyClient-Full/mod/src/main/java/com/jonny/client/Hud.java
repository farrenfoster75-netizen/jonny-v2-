package com.jonny.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.network.NetworkPlayerInfo;
import net.minecraft.client.settings.KeyBinding;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class Hud {
    public static final int INFO_W = 76, KEYS_W = 64, KEYS_H = 42;

    @SubscribeEvent
    public void onRender(RenderGameOverlayEvent.Text e) {
        Minecraft mc = Minecraft.getMinecraft();
        if (mc.gameSettings.showDebugInfo || mc.currentScreen instanceof HudEditor) return;
        draw(false);
    }

    public static int infoH() {
        int n = 0;
        if (Feature.HUD_FPS.enabled) n++;
        if (Feature.HUD_CPS.enabled) n++;
        if (Feature.HUD_PING.enabled) n++;
        return Math.max(1, n) * 10;
    }

    public static void draw(boolean editor) {
        Minecraft mc = Minecraft.getMinecraft();
        FontRenderer fr = mc.fontRendererObj;
        int x = Config.infoX, y = Config.infoY;
        if (Feature.HUD_FPS.enabled) { fr.drawStringWithShadow("FPS: " + Minecraft.getDebugFPS(), x, y, 0xFFFFFF); y += 10; }
        if (Feature.HUD_CPS.enabled) { fr.drawStringWithShadow("CPS: " + Events.getCps(), x, y, 0xFFFFFF); y += 10; }
        if (Feature.HUD_PING.enabled) {
            int ping = 0;
            if (mc.thePlayer != null && mc.getNetHandler() != null) {
                NetworkPlayerInfo info = mc.getNetHandler().getPlayerInfo(mc.thePlayer.getUniqueID());
                if (info != null) ping = info.getResponseTime();
            }
            fr.drawStringWithShadow("Ping: " + ping + "ms", x, y, 0xFFFFFF);
        }
        if (Feature.KEYSTROKES.enabled || editor) {
            int kx = Config.keysX, ky = Config.keysY;
            key(fr, mc.gameSettings.keyBindForward, "W", kx + 22, ky);
            key(fr, mc.gameSettings.keyBindLeft, "A", kx, ky + 22);
            key(fr, mc.gameSettings.keyBindBack, "S", kx + 22, ky + 22);
            key(fr, mc.gameSettings.keyBindRight, "D", kx + 44, ky + 22);
        }
    }

    private static void key(FontRenderer fr, KeyBinding kb, String label, int x, int y) {
        boolean down = kb.isKeyDown();
        Gui.drawRect(x, y, x + 20, y + 20, down ? 0xAAFFFFFF : 0x80000000);
        fr.drawString(label, x + 7, y + 6, down ? 0x000000 : 0xFFFFFF);
    }
}
