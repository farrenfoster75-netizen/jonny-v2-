package com.jonny.client;

import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.GlStateManager;
import org.lwjgl.input.Mouse;
import org.lwjgl.opengl.GL11;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.function.IntConsumer;
import java.util.function.IntSupplier;

public class ModMenu extends GuiScreen {
    private static final int ACCENT = 0x4DA3FF, BG = 0x0F1117, PANEL = 0x171A23, ROW = 0x1E2230,
            ROW_HOVER = 0x282E42, TEXT = 0xE8EAF0, SUB = 0x8A90A2, OFF = 0x3A4054;
    private static final int SIDEBAR = 98;

    private Feature.Category tab = Feature.Category.FPS;
    private int scroll, maxScroll;
    private final long openTime = System.currentTimeMillis();
    private float alpha = 1f;
    private int px, py, pw, ph, cx, cy, cw, ch;
    private Item dragging;
    private int dragX, dragW;

    // ---------- helpers ----------
    private int ca(int rgb) { return (((int) (alpha * 255)) << 24) | (rgb & 0xFFFFFF); }

    private static void rr(int x, int y, int w, int h, int c) {
        drawRect(x + 1, y, x + w - 1, y + h, c);
        drawRect(x, y + 1, x + w, y + h - 1, c);
    }

    private static boolean in(int mx, int my, int x, int y, int w, int h) {
        return mx >= x && mx < x + w && my >= y && my < y + h;
    }

    private boolean inContent(int mx, int my) { return in(mx, my, cx, cy, cw, ch); }

    // ---------- items ----------
    private abstract class Item {
        abstract int height();
        abstract void draw(int x, int y, int w, int mx, int my);
        void click(int x, int y, int w, int mx, int my) {}
        void drag(int mx) {}
    }

    private class Toggle extends Item {
        final Feature f;
        Toggle(Feature f) { this.f = f; }
        int height() { return 28; }
        void draw(int x, int y, int w, int mx, int my) {
            boolean hover = inContent(mx, my) && in(mx, my, x, y, w, 26);
            rr(x, y, w, 26, ca(hover ? ROW_HOVER : ROW));
            fontRendererObj.drawStringWithShadow(f.label, x + 8, y + 4, ca(TEXT));
            GlStateManager.pushMatrix();
            GlStateManager.translate(x + 8, y + 15, 0);
            GlStateManager.scale(0.8f, 0.8f, 1f);
            fontRendererObj.drawString(f.desc, 0, 0, ca(SUB));
            GlStateManager.popMatrix();
            int sx = x + w - 34, sy = y + 7;
            rr(sx, sy, 26, 12, ca(f.enabled ? ACCENT : OFF));
            rr(f.enabled ? sx + 16 : sx + 2, sy + 2, 8, 8, ca(0xFFFFFF));
        }
        void click(int x, int y, int w, int mx, int my) {
            f.enabled = !f.enabled;
            if (f.gfx) GfxTuner.apply();
            Config.save();
        }
    }

    private class Slider extends Item {
        final String label; final int min, max; final IntSupplier get; final IntConsumer set;
        Slider(String label, int min, int max, IntSupplier get, IntConsumer set) {
            this.label = label; this.min = min; this.max = max; this.get = get; this.set = set;
        }
        int height() { return 32; }
        void draw(int x, int y, int w, int mx, int my) {
            rr(x, y, w, 30, ca(ROW));
            fontRendererObj.drawStringWithShadow(label, x + 8, y + 4, ca(TEXT));
            String v = String.valueOf(get.getAsInt());
            fontRendererObj.drawStringWithShadow(v, x + w - 8 - fontRendererObj.getStringWidth(v), y + 4, ca(ACCENT));
            int tx = x + 8, tw = w - 16, ty = y + 20;
            float p = (get.getAsInt() - min) / (float) (max - min);
            p = Math.max(0f, Math.min(1f, p));
            int fw = (int) (tw * p);
            rr(tx, ty, tw, 4, ca(OFF));
            rr(tx, ty, Math.max(fw, 2), 4, ca(ACCENT));
            rr(tx + fw - 3, ty - 2, 6, 8, ca(0xFFFFFF));
        }
        void click(int x, int y, int w, int mx, int my) { dragging = this; dragX = x; dragW = w; drag(mx); }
        void drag(int mx) {
            float p = (mx - (dragX + 8)) / (float) (dragW - 16);
            p = Math.max(0f, Math.min(1f, p));
            set.accept(Math.round(min + p * (max - min)));
        }
    }

    private class Btn extends Item {
        final String label; final Runnable action;
        Btn(String label, Runnable action) { this.label = label; this.action = action; }
        int height() { return 28; }
        void draw(int x, int y, int w, int mx, int my) {
            boolean hover = inContent(mx, my) && in(mx, my, x, y, w, 26);
            rr(x, y, w, 26, ca(ACCENT));
            rr(x + 1, y + 1, w - 2, 24, ca(hover ? 0x2A3A5C : ROW));
            fontRendererObj.drawStringWithShadow(label, x + (w - fontRendererObj.getStringWidth(label)) / 2, y + 9, ca(ACCENT));
        }
        void click(int x, int y, int w, int mx, int my) { action.run(); }
    }

    private List<Item> items() {
        List<Item> l = new ArrayList<Item>();
        if (tab == Feature.Category.FPS) l.add(new Btn("Apply MAX FPS Preset", GfxTuner::applyMaxFpsPreset));
        for (Feature f : Feature.values()) if (f.category == tab) l.add(new Toggle(f));
        if (tab == Feature.Category.FPS) {
            l.add(new Slider("Entity cull distance", 16, 128, () -> Config.cullDistance, v -> Config.cullDistance = v));
            l.add(new Slider("Nametag distance", 8, 64, () -> Config.nametagDistance, v -> Config.nametagDistance = v));
            l.add(new Slider("Render distance (chunks)", 2, 16,
                    () -> mc.gameSettings.renderDistanceChunks,
                    v -> { Config.renderDistance = v; GfxTuner.apply(); }));
            l.add(new Btn("Reset everything to default", GfxTuner::resetAll));
        }
        if (tab == Feature.Category.HUD) l.add(new Btn("Edit HUD Layout", () -> mc.displayGuiScreen(new HudEditor())));
        return l;
    }

    // ---------- screen ----------
    @Override
    public void initGui() {
        pw = Math.min(width - 30, 480);
        ph = Math.min(height - 30, 290);
        px = (width - pw) / 2;
        py = (height - ph) / 2;
        cx = px + SIDEBAR + 12;
        cy = py + 34;
        cw = pw - SIDEBAR - 18;
        ch = ph - 40;
    }

    @Override
    public void drawScreen(int mx, int my, float pt) {
        alpha = Math.max(0.12f, Math.min(1f, (System.currentTimeMillis() - openTime) / 200f));
        drawRect(0, 0, width, height, ((int) (alpha * 140)) << 24);

        GlStateManager.pushMatrix();
        GlStateManager.translate(0, (1f - alpha) * 8f, 0);

        rr(px - 1, py - 1, pw + 2, ph + 2, (((int) (alpha * 110)) << 24) | ACCENT);
        rr(px, py, pw, ph, ca(BG));

        GlStateManager.pushMatrix();
        GlStateManager.translate(px + 12, py + 10, 0);
        GlStateManager.scale(1.5f, 1.5f, 1f);
        fontRendererObj.drawStringWithShadow("JONNY", 0, 0, ca(TEXT));
        fontRendererObj.drawStringWithShadow("CLIENT", fontRendererObj.getStringWidth("JONNY "), 0, ca(ACCENT));
        GlStateManager.popMatrix();

        boolean xHover = in(mx, my, px + pw - 22, py + 8, 14, 14);
        rr(px + pw - 22, py + 8, 14, 14, ca(xHover ? 0xD04050 : ROW));
        fontRendererObj.drawStringWithShadow("x", px + pw - 18, py + 11, ca(TEXT));

        rr(px + 6, py + 34, SIDEBAR, ph - 40, ca(PANEL));
        Feature.Category[] cats = Feature.Category.values();
        for (int i = 0; i < cats.length; i++) {
            int ty = py + 40 + i * 22;
            boolean sel = cats[i] == tab;
            boolean hover = in(mx, my, px + 10, ty, SIDEBAR - 8, 18);
            if (sel) rr(px + 10, ty, SIDEBAR - 8, 18, ca(ACCENT));
            else if (hover) rr(px + 10, ty, SIDEBAR - 8, 18, ca(ROW_HOVER));
            fontRendererObj.drawStringWithShadow(cats[i].title, px + 16, ty + 5, sel ? ca(0x06101F) : ca(TEXT));
        }

        List<Item> list = items();
        int total = 0;
        for (Item it : list) total += it.height();
        maxScroll = Math.max(0, total - ch);
        scroll = Math.max(0, Math.min(maxScroll, scroll));

        ScaledResolution sr = new ScaledResolution(mc);
        int f = sr.getScaleFactor();
        GL11.glEnable(GL11.GL_SCISSOR_TEST);
        GL11.glScissor(cx * f, (sr.getScaledHeight() - (cy + ch)) * f, cw * f, ch * f);
        int y = cy - scroll;
        int rw = cw - 8;
        for (Item it : list) {
            it.draw(cx, y, rw, mx, my);
            y += it.height();
        }
        GL11.glDisable(GL11.GL_SCISSOR_TEST);

        if (maxScroll > 0) {
            int barH = Math.max(20, ch * ch / (ch + maxScroll));
            int barY = cy + (int) ((ch - barH) * (scroll / (float) maxScroll));
            rr(cx + cw - 4, barY, 3, barH, ca(ACCENT));
        }

        GlStateManager.popMatrix();
        super.drawScreen(mx, my, pt);
    }

    @Override
    protected void mouseClicked(int mx, int my, int btn) throws IOException {
        super.mouseClicked(mx, my, btn);
        if (btn != 0) return;
        if (in(mx, my, px + pw - 22, py + 8, 14, 14)) { mc.displayGuiScreen(null); return; }
        Feature.Category[] cats = Feature.Category.values();
        for (int i = 0; i < cats.length; i++) {
            if (in(mx, my, px + 10, py + 40 + i * 22, SIDEBAR - 8, 18)) { tab = cats[i]; scroll = 0; return; }
        }
        if (!inContent(mx, my)) return;
        int y = cy - scroll;
        int rw = cw - 8;
        for (Item it : items()) {
            int h = it.height();
            if (my >= y && my < y + h - 2 && mx >= cx && mx < cx + rw) { it.click(cx, y, rw, mx, my); return; }
            y += h;
        }
    }

    @Override
    protected void mouseClickMove(int mx, int my, int btn, long time) {
        if (dragging != null) dragging.drag(mx);
    }

    @Override
    protected void mouseReleased(int mx, int my, int state) {
        super.mouseReleased(mx, my, state);
        dragging = null;
        Config.save();
    }

    @Override
    public void handleMouseInput() throws IOException {
        super.handleMouseInput();
        int d = Mouse.getEventDWheel();
        if (d != 0) scroll = Math.max(0, Math.min(maxScroll, scroll - Integer.signum(d) * 20));
    }

    @Override
    public void onGuiClosed() { Config.save(); }

    @Override
    public boolean doesGuiPauseGame() { return false; }
}
