package com.jonny.client;

import java.io.*;
import java.util.Properties;

public class Config {
    public static int cullDistance = 64;
    public static int nametagDistance = 32;
    public static int renderDistance = 0; // 0 = leave vanilla setting alone
    public static int infoX = 4, infoY = 4, keysX = 4, keysY = 44;
    private static File file;

    private static int geti(Properties p, String k, int d) {
        try { return Integer.parseInt(p.getProperty(k, String.valueOf(d))); } catch (Exception e) { return d; }
    }

    public static void load(File f) {
        file = f;
        Properties p = new Properties();
        try (FileInputStream in = new FileInputStream(f)) {
            p.load(in);
        } catch (Exception ignored) { return; }
        for (Feature ft : Feature.values())
            ft.enabled = Boolean.parseBoolean(p.getProperty(ft.name(), String.valueOf(ft.def)));
        cullDistance = geti(p, "cullDistance", 64);
        nametagDistance = geti(p, "nametagDistance", 32);
        renderDistance = geti(p, "renderDistance", 0);
        infoX = geti(p, "infoX", 4);
        infoY = geti(p, "infoY", 4);
        keysX = geti(p, "keysX", 4);
        keysY = geti(p, "keysY", 44);
    }

    public static void save() {
        if (file == null) return;
        Properties p = new Properties();
        for (Feature ft : Feature.values()) p.setProperty(ft.name(), String.valueOf(ft.enabled));
        p.setProperty("cullDistance", String.valueOf(cullDistance));
        p.setProperty("nametagDistance", String.valueOf(nametagDistance));
        p.setProperty("renderDistance", String.valueOf(renderDistance));
        p.setProperty("infoX", String.valueOf(infoX));
        p.setProperty("infoY", String.valueOf(infoY));
        p.setProperty("keysX", String.valueOf(keysX));
        p.setProperty("keysY", String.valueOf(keysY));
        try {
            file.getParentFile().mkdirs();
            try (FileOutputStream out = new FileOutputStream(file)) { p.store(out, "Jonny Client"); }
        } catch (Exception ignored) {}
    }
}
