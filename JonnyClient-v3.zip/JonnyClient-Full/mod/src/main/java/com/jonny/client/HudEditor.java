package com.jonny.client;

import net.minecraft.client.gui.GuiScreen;

import java.io.IOException;

public class HudEditor extends GuiScreen {
    private int drag = 0; // 0 none, 1 info, 2 keys
    private int offX, offY;

    private boolean in(int mx, int my, int x, int y, int w, int h) {
        return mx >= x && mx < x + w && my >= y && my < y + h;
    }

    private void outline(int x, int y, int w, int h, int c) {
        drawRect(x - 1, y - 1, x + w + 1, y, c);
        drawRect(x - 1, y + h, x + w + 1, y + h + 1, c);
        drawRect(x - 1, y, x, y + h, c);
        drawRect(x + w, y, x + w + 1, y + h, c);
    }

    @Override
    public void drawScreen(int mx, int my, float pt) {
        drawRect(0, 0, width, height, 0x88000000);
        Hud.draw(true);
        outline(Config.infoX, Config.infoY, Hud.INFO_W, Hud.infoH(), 0xFF4DA3FF);
        outline(Config.keysX, Config.keysY, Hud.KEYS_W, Hud.KEYS_H, 0xFF4DA3FF);
        drawCenteredString(fontRendererObj, "Drag the HUD elements. Press ESC when done.", width / 2, 12, 0xFFFFFF);
        super.drawScreen(mx, my, pt);
    }

    @Override
    protected void mouseClicked(int mx, int my, int btn) throws IOException {
        super.mouseClicked(mx, my, btn);
        if (btn != 0) return;
        if (in(mx, my, Config.infoX, Config.infoY, Hud.INFO_W, Hud.infoH())) {
            drag = 1; offX = mx - Config.infoX; offY = my - Config.infoY;
        } else if (in(mx, my, Config.keysX, Config.keysY, Hud.KEYS_W, Hud.KEYS_H)) {
            drag = 2; offX = mx - Config.keysX; offY = my - Config.keysY;
        }
    }

    @Override
    protected void mouseClickMove(int mx, int my, int btn, long time) {
        if (drag == 1) {
            Config.infoX = Math.max(0, Math.min(width - Hud.INFO_W, mx - offX));
            Config.infoY = Math.max(0, Math.min(height - Hud.infoH(), my - offY));
        } else if (drag == 2) {
            Config.keysX = Math.max(0, Math.min(width - Hud.KEYS_W, mx - offX));
            Config.keysY = Math.max(0, Math.min(height - Hud.KEYS_H, my - offY));
        }
    }

    @Override
    protected void mouseReleased(int mx, int my, int state) {
        super.mouseReleased(mx, my, state);
        drag = 0;
    }

    @Override
    protected void keyTyped(char c, int code) throws IOException {
        if (code == 1) { mc.displayGuiScreen(new ModMenu()); return; }
        super.keyTyped(c, code);
    }

    @Override
    public void onGuiClosed() { Config.save(); }

    @Override
    public boolean doesGuiPauseGame() { return false; }
}
