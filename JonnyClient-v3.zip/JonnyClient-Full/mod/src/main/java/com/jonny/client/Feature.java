package com.jonny.client;

public enum Feature {
    ENTITY_CULLING(Category.FPS, "Entity Distance Culling", "Stop drawing far-away entities", true, false),
    NAMETAG_CULLING(Category.FPS, "Nametag Culling", "Hide far-away nametags", true, false),
    ARMOR_STAND_CULL(Category.FPS, "Hide Armor Stands", "Also hides hologram text", false, false),
    NO_WEATHER(Category.FPS, "Disable Weather", "No rain or thunder", true, false),
    LOW_FIRE(Category.FPS, "Low Fire Overlay", "Removes the fire screen overlay", true, false),
    UNFOCUSED_LIMIT(Category.FPS, "Unfocused FPS Limit", "30 FPS while tabbed out", true, false),

    GFX_FAST(Category.GRAPHICS, "Fast Graphics", "Turns off fancy graphics", true, true),
    GFX_NO_CLOUDS(Category.GRAPHICS, "No Clouds", "Removes clouds", true, true),
    LOW_PARTICLES(Category.GRAPHICS, "Minimal Particles", "Fewer particles", true, true),
    GFX_UNCAP(Category.GRAPHICS, "Uncap FPS / No VSync", "Removes the frame cap", true, true),
    GFX_NO_AO(Category.GRAPHICS, "Flat Lighting", "Turns off smooth lighting", false, true),
    GFX_NO_SHADOWS(Category.GRAPHICS, "No Entity Shadows", "Removes the blob shadows", false, true),

    TOGGLE_SPRINT(Category.PVP, "Toggle Sprint", "Auto-sprint while moving forward", true, false),
    FULLBRIGHT(Category.PVP, "Fullbright", "Maximum brightness", false, false),
    ZOOM(Category.PVP, "Zoom", "Hold C to zoom in", true, false),

    HUD_FPS(Category.HUD, "FPS Counter", "Shows your FPS", true, false),
    HUD_CPS(Category.HUD, "CPS Counter", "Shows clicks per second", true, false),
    HUD_PING(Category.HUD, "Ping", "Shows your ping", true, false),
    KEYSTROKES(Category.HUD, "Keystrokes", "Shows WASD presses", true, false);

    public enum Category {
        FPS("FPS BOOST"), GRAPHICS("GRAPHICS"), PVP("PVP"), HUD("HUD");
        public final String title;
        Category(String title) { this.title = title; }
    }

    public final Category category;
    public final String label;
    public final String desc;
    public final boolean def;
    public final boolean gfx;
    public boolean enabled;

    Feature(Category category, String label, String desc, boolean def, boolean gfx) {
        this.category = category;
        this.label = label;
        this.desc = desc;
        this.def = def;
        this.gfx = gfx;
        this.enabled = def;
    }
}
