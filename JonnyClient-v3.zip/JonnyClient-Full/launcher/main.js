const { app, BrowserWindow, ipcMain } = require('electron');
const path = require('path');
const fs = require('fs');
const AdmZip = require('adm-zip');
const { Client } = require('minecraft-launcher-core');
const { Auth } = require('msmc');

const GAME_DIR = path.join(app.getPath('appData'), '.jonnyclient');
const FORGE_VER = '1.8.9-11.15.1.2318-1.8.9';
const FORGE_URL = `https://maven.minecraftforge.net/net/minecraftforge/forge/${FORGE_VER}/forge-${FORGE_VER}-universal.jar`;
const JAVA_URL = 'https://api.adoptium.net/v3/binary/latest/8/ga/windows/x64/jre/hotspot/normal/eclipse';
let win;

function log(msg) {
  const safe = String(msg).replace(/--accessToken\s+\S+/g, '--accessToken [hidden]').replace(/--uuid\s+\S+/g, '--uuid [hidden]');
  if (win && !win.isDestroyed()) win.webContents.send('log', safe);
}

async function download(url, dest, label) {
  log(`Downloading ${label}...`);
  const r = await fetch(url);
  if (!r.ok) throw new Error(`${label} download failed (${r.status})`);
  fs.mkdirSync(path.dirname(dest), { recursive: true });
  fs.writeFileSync(dest, Buffer.from(await r.arrayBuffer()));
}

function findJavaExe(dir) {
  if (!fs.existsSync(dir)) return null;
  for (const d of fs.readdirSync(dir)) {
    const p = path.join(dir, d, 'bin', 'javaw.exe');
    if (fs.existsSync(p)) return p;
  }
  return null;
}

async function ensureJava() {
  const dir = path.join(GAME_DIR, 'runtime');
  let exe = findJavaExe(dir);
  if (exe) return exe;
  const zipPath = path.join(GAME_DIR, 'java8.zip');
  await download(JAVA_URL, zipPath, 'Java 8');
  log('Extracting Java...');
  new AdmZip(zipPath).extractAllTo(dir, true);
  fs.unlinkSync(zipPath);
  exe = findJavaExe(dir);
  if (!exe) throw new Error('Could not set up Java');
  return exe;
}

async function ensureForge() {
  const p = path.join(GAME_DIR, 'forge', `forge-${FORGE_VER}-universal.jar`);
  if (!fs.existsSync(p)) await download(FORGE_URL, p, 'Forge 1.8.9');
  return p;
}

function installMod() {
  const modsDir = path.join(GAME_DIR, 'mods');
  fs.mkdirSync(modsDir, { recursive: true });
  const src = app.isPackaged
    ? path.join(process.resourcesPath, 'mod', 'JonnyClient-1.0.jar')
    : path.join(__dirname, 'mod', 'JonnyClient-1.0.jar');
  if (!fs.existsSync(src)) throw new Error('Jonny Client mod jar missing from launcher');
  fs.copyFileSync(src, path.join(modsDir, 'JonnyClient-1.0.jar'));
}

ipcMain.handle('play', async (_e, ramGb) => {
  try {
    log('Opening Microsoft login...');
    const auth = new Auth('select_account');
    const xbox = await auth.launch('electron');
    const mc = await xbox.getMinecraft();
    log(`Logged in as ${mc.profile.name}`);

    const javaPath = await ensureJava();
    const forge = await ensureForge();
    installMod();

    const launcher = new Client();
    launcher.on('debug', log);
    launcher.on('data', log);
    launcher.on('progress', (p) => { if (p.task === p.total || p.task % 100 === 0) log(`${p.type}: ${p.task}/${p.total}`); });
    launcher.on('close', () => log('Game closed.'));

    log('Launching Minecraft 1.8.9...');
    await launcher.launch({
      authorization: mc.mclc(),
      root: GAME_DIR,
      javaPath,
      forge,
      version: { number: '1.8.9', type: 'release' },
      memory: { max: `${ramGb}G`, min: `${ramGb}G` },
      customArgs: [
        '-XX:+UseG1GC', '-XX:+UnlockExperimentalVMOptions', '-XX:MaxGCPauseMillis=50',
        '-XX:G1NewSizePercent=20', '-XX:G1ReservePercent=20', '-XX:G1HeapRegionSize=16M'
      ]
    });
    return 'ok';
  } catch (err) {
    log('ERROR: ' + (err && err.message ? err.message : err));
    return 'error';
  }
});

app.whenReady().then(() => {
  win = new BrowserWindow({
    width: 760, height: 520, resizable: false, backgroundColor: '#0f1117',
    autoHideMenuBar: true, title: 'Jonny Client',
    webPreferences: { nodeIntegration: true, contextIsolation: false }
  });
  win.loadFile('index.html');
  win.webContents.once('did-finish-load', () => log('Launcher v3 (new menu + safer FPS)'));
});
app.on('window-all-closed', () => app.quit());
