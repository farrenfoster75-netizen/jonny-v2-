const { app, BrowserWindow, ipcMain, shell } = require('electron');
const os = require('os');
const { execFile } = require('child_process');
const path = require('path');
const fs = require('fs');
const AdmZip = require('adm-zip');
const { Client } = require('minecraft-launcher-core');
const { Auth } = require('msmc');

const GAME_DIR = path.join(app.getPath('appData'), '.jonnyclient');
const FORGE_VER = '1.8.9-11.15.1.2318-1.8.9';
const FORGE_URL = `https://maven.minecraftforge.net/net/minecraftforge/forge/${FORGE_VER}/forge-${FORGE_VER}-universal.jar`;
const JAVA_URL = 'https://api.adoptium.net/v3/binary/latest/8/ga/windows/x64/jre/hotspot/normal/eclipse';
let win;

function log(msg) {
  const safe = String(msg).replace(/--accessToken\s+\S+/g, '--accessToken [hidden]').replace(/--uuid\s+\S+/g, '--uuid [hidden]');
  if (win && !win.isDestroyed()) win.webContents.send('log', safe);
}

async function download(url, dest, label) {
  log(`Downloading ${label}...`);
  const r = await fetch(url);
  if (!r.ok) throw new Error(`${label} download failed (${r.status})`);
  fs.mkdirSync(path.dirname(dest), { recursive: true });
  fs.writeFileSync(dest, Buffer.from(await r.arrayBuffer()));
}

function findJavaExe(dir) {
  if (!fs.existsSync(dir)) return null;
  for (const d of fs.readdirSync(dir)) {
    const p = path.join(dir, d, 'bin', 'javaw.exe');
    if (fs.existsSync(p)) return p;
  }
  return null;
}

async function ensureJava() {
  const dir = path.join(GAME_DIR, 'runtime');
  let exe = findJavaExe(dir);
  if (exe) return exe;
  const zipPath = path.join(GAME_DIR, 'java8.zip');
  await download(JAVA_URL, zipPath, 'Java 8');
  log('Extracting Java...');
  new AdmZip(zipPath).extractAllTo(dir, true);
  fs.unlinkSync(zipPath);
  exe = findJavaExe(dir);
  if (!exe) throw new Error('Could not set up Java');
  return exe;
}

async function ensureForge() {
  const p = path.join(GAME_DIR, 'forge', `forge-${FORGE_VER}-universal.jar`);
  if (!fs.existsSync(p)) await download(FORGE_URL, p, 'Forge 1.8.9');
  return p;
}

function installMod() {
  const modsDir = path.join(GAME_DIR, 'mods');
  fs.mkdirSync(modsDir, { recursive: true });
  const src = app.isPackaged
    ? path.join(process.resourcesPath, 'mod', 'JonnyClient-1.0.jar')
    : path.join(__dirname, 'mod', 'JonnyClient-1.0.jar');
  if (!fs.existsSync(src)) throw new Error('Jonny Client mod jar missing from launcher');
  fs.copyFileSync(src, path.join(modsDir, 'JonnyClient-1.0.jar'));
}

ipcMain.handle('openMods', async () => {
  const dir = path.join(GAME_DIR, 'mods');
  fs.mkdirSync(dir, { recursive: true });
  await shell.openPath(dir);
});

function setGpuPreference(javaPath) {
  if (process.platform !== 'win32') return;
  execFile('reg', ['add', 'HKCU\\Software\\Microsoft\\DirectX\\UserGpuPreferences', '/v', javaPath, '/t', 'REG_SZ', '/d', 'GpuPreference=2;', '/f'],
    (err) => log(err ? 'Could not set the GPU preference.' : 'Windows graphics: Java set to High performance GPU (undo in Windows Settings > Graphics).'));
}

function applyPriority(child) {
  try {
    if (child && child.pid) { os.setPriority(child.pid, os.constants.priority.PRIORITY_HIGH); log('Game CPU priority: High'); }
  } catch (e) { log('Could not raise CPU priority.'); }
}

ipcMain.handle('play', async (_e, ramGb, boost) => {
  try {
    log('Opening Microsoft login...');
    const auth = new Auth('select_account');
    const xbox = await auth.launch('electron');
    const mc = await xbox.getMinecraft();
    log(`Logged in as ${mc.profile.name}`);

    const javaPath = await ensureJava();
    const forge = await ensureForge();
    installMod();

    if (boost) setGpuPreference(javaPath);
    const launcher = new Client();
    launcher.on('debug', log);
    launcher.on('data', log);
    launcher.on('progress', (p) => { if (p.task === p.total || p.task % 100 === 0) log(`${p.type}: ${p.task}/${p.total}`); });
    launcher.on('close', () => log('Game closed.'));

    log('Launching Minecraft 1.8.9...');
    const child = await launcher.launch({
      authorization: mc.mclc(),
      root: GAME_DIR,
      javaPath,
      forge,
      version: { number: '1.8.9', type: 'release' },
      memory: { max: `${ramGb}G`, min: `${ramGb}G` },
      customArgs: [
        '-XX:+UseG1GC', '-XX:+UnlockExperimentalVMOptions', '-XX:MaxGCPauseMillis=40',
        '-XX:G1NewSizePercent=30', '-XX:G1MaxNewSizePercent=40', '-XX:G1HeapRegionSize=8M',
        '-XX:G1ReservePercent=20', '-XX:G1HeapWastePercent=5', '-XX:G1MixedGCCountTarget=4',
        '-XX:InitiatingHeapOccupancyPercent=15', '-XX:G1MixedGCLiveThresholdPercent=90',
        '-XX:G1RSetUpdatingPauseTimePercent=5', '-XX:SurvivorRatio=32', '-XX:MaxTenuringThreshold=1',
        '-XX:+ParallelRefProcEnabled', '-XX:+DisableExplicitGC', '-XX:+AlwaysPreTouch',
        '-XX:+PerfDisableSharedMem', '-XX:+OptimizeStringConcat', '-Djava.net.preferIPv4Stack=true'
      ]
    });
    if (boost) applyPriority(child);
    return 'ok';
  } catch (err) {
    log('ERROR: ' + (err && err.message ? err.message : err));
    return 'error';
  }
});

app.whenReady().then(() => {
  win = new BrowserWindow({
    width: 760, height: 520, resizable: false, backgroundColor: '#0f1117',
    autoHideMenuBar: true, title: 'Jonny Client',
    webPreferences: { nodeIntegration: true, contextIsolation: false }
  });
  win.loadFile('index.html');
  win.webContents.once('did-finish-load', () => log('Launcher vX (deep FPS pack: layer + sign culling, tuned JVM)'));
});
app.on('window-all-closed', () => app.quit());
