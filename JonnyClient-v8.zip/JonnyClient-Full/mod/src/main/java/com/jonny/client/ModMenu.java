package com.jonny.client;

import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.util.ChatAllowedCharacters;
import net.minecraft.util.ResourceLocation;
import org.lwjgl.input.Keyboard;
import org.lwjgl.input.Mouse;
import org.lwjgl.opengl.GL11;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.BooleanSupplier;
import java.util.function.IntConsumer;
import java.util.function.IntSupplier;

/** Jonny Client vX menu: translucent gold card grid, profiles, search, option drawers, cosmetics. */
public class ModMenu extends GuiScreen {
    private enum Top {
        MODS("MODS"), COSMETICS("COSMETICS"), SETTINGS("SETTINGS");
        final String title;
        Top(String t) { title = t; }
    }

    private static final String[] MOD_CATS = {"ALL", "HUD", "PVP", "FPS", "GRAPHICS"};
    private static final String[] COS_CATS = {"CAPES", "WINGS", "BANDANAS", "HEAD"};
    private static final int BG = 0x0B0905, PANEL = 0x16120A, CARD = 0x1E190D, CARD_H = 0x30270F,
            TEXT = 0xF7F0DE, SUB = 0xAA9E83, OFF = 0x3B3322, DARK = 0x0A0804;
    private static Top lastTop = Top.MODS;
    private static int lastModCat = 0, lastCosCat = 0;

    private Top top = lastTop;
    private int modCat = lastModCat, cosCat = lastCosCat;
    private String search = "";
    private boolean searchFocus;
    private float scrollPos, scrollTarget;
    private int maxScroll;
    private final long openTime = System.currentTimeMillis();
    private float alpha = 1f;
    private int px, py, pw, ph, sf, sh;
    private int leftX, leftY, leftW, leftH, mainX, mainW, gridX, gridY, gridW, gridH, chipY;
    private int hx, hy, hw, hh;
    private Item dragging;
    private int dragX, dragW;
    private Entry drawer;
    private String flash = "";
    private long flashUntil;
    private final Map<String, Float> anim = new HashMap<String, Float>();
    private final List<Entry> entries = new ArrayList<Entry>();
    private static final int TOPH = 48;

    // ------------------------------------------------------------ helpers
    private int c(int rgb, int a) { return (((int) (alpha * a)) << 24) | (rgb & 0xFFFFFF); }
    private int gold() { return UI.accent(); }
    private void t(String s, float x, float y, float size, int rgb, boolean bold) { UI.text(s, x, y, size, c(rgb, 255), bold, false); }
    private void tc(String s, float cx, float y, float size, int rgb, boolean bold) { t(s, cx - UI.width(s, size, bold) / 2f, y, size, rgb, bold); }
    private float tw(String s, float size, boolean bold) { return UI.width(s, size, bold); }
    private static boolean in(int mx, int my, int x, int y, int w, int h) { return mx >= x && mx < x + w && my >= y && my < y + h; }
    private boolean hov(int mx, int my) { return in(mx, my, hx, hy, hw, hh); }
    private void setHover(int x, int y, int w, int h) { hx = x; hy = y; hw = w; hh = h; }

    private static int mix(int c1, int c2, float f) {
        int r = (int) (((c1 >> 16) & 255) * (1 - f) + ((c2 >> 16) & 255) * f);
        int g = (int) (((c1 >> 8) & 255) * (1 - f) + ((c2 >> 8) & 255) * f);
        int b = (int) ((c1 & 255) * (1 - f) + (c2 & 255) * f);
        return (r << 16) | (g << 8) | b;
    }

    private float anim(String key, boolean on) {
        Float cur0 = anim.get(key);
        float cur = cur0 == null ? (on ? 1f : 0f) : cur0;
        float tgt = on ? 1f : 0f;
        cur += (tgt - cur) * 0.26f;
        if (Math.abs(tgt - cur) < 0.01f) cur = tgt;
        anim.put(key, cur);
        return cur;
    }

    private void scissor(int x, int y, int w, int h) { GL11.glScissor(x * sf, (sh - (y + h)) * sf, Math.max(0, w) * sf, Math.max(0, h) * sf); }

    private void drawSwitch(int x, int y, boolean on, String key) {
        float a = anim(key, on);
        UI.rrect(x, y, 32, 16, 8, c(mix(OFF, gold(), a), 255));
        UI.rrect(x + 2 + Math.round(16 * a), y + 2, 12, 12, 6, c(mix(0xD8D0BC, 0xFFFFFF, a), 255));
    }

    private void drawTrack(int x, int y, int w, float frac) {
        frac = Math.max(0f, Math.min(1f, frac));
        int fw = (int) (w * frac);
        UI.rrect(x, y, w, 4, 2, c(OFF, 255));
        UI.rrect(x, y, Math.max(fw, 4), 4, 2, c(gold(), 255));
        UI.rrect(x + fw - 5, y - 3, 10, 10, 5, c(0xFFFFFF, 255));
    }

    private static String abbr(String name) {
        String[] w = name.replace("&", " ").trim().split("\\s+");
        StringBuilder sb = new StringBuilder();
        if (w.length > 1) { for (String s : w) if (!s.isEmpty() && sb.length() < 3) sb.append(Character.toUpperCase(s.charAt(0))); }
        else sb.append(name.substring(0, Math.min(3, name.length())).toUpperCase());
        return sb.toString();
    }

    // ------------------------------------------------------------ option rows (used in the drawer and settings)
    private abstract class Item {
        abstract int step();
        abstract void draw(int x, int y, int w, int mx, int my);
        void click(int x, int y, int w, int mx, int my) {}
        void drag(int mx) {}
    }

    private class BoolRow extends Item {
        final String key, label, desc; final BooleanSupplier get; final Runnable flip;
        BoolRow(String key, String label, String desc, BooleanSupplier get, Runnable flip) { this.key = key; this.label = label; this.desc = desc; this.get = get; this.flip = flip; }
        int step() { return 38; }
        void draw(int x, int y, int w, int mx, int my) {
            float a = anim("hv:" + key, hov(mx, my) && in(mx, my, x, y, w, 34));
            UI.rrect(x, y, w, 34, 8, c(mix(CARD, CARD_H, a), 190));
            t(label, x + 14, y + 5, 10f, TEXT, true);
            t(desc, x + 14, y + 19, 8f, SUB, false);
            drawSwitch(x + w - 46, y + 9, get.getAsBoolean(), key);
        }
        void click(int x, int y, int w, int mx, int my) { flip.run(); Config.save(); }
    }

    private class SliderRow extends Item {
        final String label, suffix; final int min, max; final IntSupplier get; final IntConsumer set;
        SliderRow(String label, String suffix, int min, int max, IntSupplier get, IntConsumer set) { this.label = label; this.suffix = suffix; this.min = min; this.max = max; this.get = get; this.set = set; }
        int step() { return 44; }
        void draw(int x, int y, int w, int mx, int my) {
            UI.rrect(x, y, w, 40, 8, c(CARD, 190));
            t(label, x + 14, y + 6, 10f, TEXT, true);
            String v = get.getAsInt() + suffix;
            t(v, x + w - 14 - tw(v, 10f, true), y + 6, 10f, gold(), true);
            drawTrack(x + 14, y + 28, w - 28, (get.getAsInt() - min) / (float) (max - min));
        }
        void click(int x, int y, int w, int mx, int my) { dragging = this; dragX = x; dragW = w; drag(mx); }
        void drag(int mx) {
            float p = (mx - (dragX + 14)) / (float) (dragW - 28);
            p = Math.max(0f, Math.min(1f, p));
            set.accept(Math.round(min + p * (max - min)));
        }
    }

    private class BtnRow extends Item {
        final java.util.function.Supplier<String> label; final Runnable action;
        BtnRow(java.util.function.Supplier<String> label, Runnable action) { this.label = label; this.action = action; }
        int step() { return 34; }
        void draw(int x, int y, int w, int mx, int my) {
            String s = label.get();
            float a = anim("hb:" + s, hov(mx, my) && in(mx, my, x, y, w, 30));
            UI.rrect(x, y, w, 30, 8, c(gold(), 110 + (int) (110 * a)));
            UI.rrect(x + 1, y + 1, w - 2, 28, 7, c(mix(CARD, CARD_H, a), 235));
            tc(s, x + w / 2f, y + 8, 10f, gold(), true);
        }
        void click(int x, int y, int w, int mx, int my) { action.run(); Config.save(); }
    }

    // ------------------------------------------------------------ entries (mods)
    private class Entry {
        final String name, desc, abbr, cat; final BooleanSupplier on; final Runnable toggle; final List<Item> opts = new ArrayList<Item>();
        Entry(String name, String desc, String cat, BooleanSupplier on, Runnable toggle) {
            this.name = name; this.desc = desc; this.abbr = abbr(name); this.cat = cat; this.on = on; this.toggle = toggle;
        }
    }

    private void toggleFeature(Feature f) {
        f.enabled = !f.enabled;
        if (f.gfx) GfxTuner.apply();
        if (f == Feature.ENTITY_SCALE) Events.refreshEntityWeights();
        Config.save();
    }

    private void buildEntries() {
        for (HudMod m : HudMods.ALL) {
            final HudMod mm = m;
            Entry e = new Entry(m.name, m.desc, "HUD", () -> mm.enabled, () -> { mm.enabled = !mm.enabled; Config.save(); });
            e.opts.add(new SliderRow("Scale", "%", 50, 200, () -> mm.scale, v -> mm.scale = 5 * Math.round(v / 5f)));
            e.opts.add(new BoolRow("hb:" + m.id, "Background", "Draw a box behind this element", () -> mm.bg, () -> mm.bg = !mm.bg));
            entries.add(e);
        }
        for (Feature f : Feature.values()) {
            final Feature ff = f;
            String cat = f.category == Feature.Category.PVP ? "PVP" : (f.category == Feature.Category.FPS ? "FPS" : "GRAPHICS");
            Entry e = new Entry(f.label, f.desc, cat, () -> ff.enabled, () -> toggleFeature(ff));
            switch (f) {
                case ENTITY_CULLING: e.opts.add(new SliderRow("Cull distance", "", 16, 128, () -> Config.cullDistance, v -> Config.cullDistance = v)); break;
                case ENTITY_SCALE: e.opts.add(new SliderRow("Entity render distance", "%", 25, 100, () -> Config.entityScale, v -> { Config.entityScale = v; Events.refreshEntityWeights(); })); break;
                case NAMETAG_CULLING: e.opts.add(new SliderRow("Nametag distance", "", 8, 64, () -> Config.nametagDistance, v -> Config.nametagDistance = v)); break;
                case TILE_CULLING: e.opts.add(new SliderRow("Tile entity distance", "", 8, 64, () -> Config.tileDistance, v -> Config.tileDistance = v)); break;
                case PARTICLE_DIST: case PARTICLE_SPAWN: e.opts.add(new SliderRow("Particle distance", "", 8, 64, () -> Config.particleDistance, v -> Config.particleDistance = v)); break;
                case PARTICLE_CAP: e.opts.add(new SliderRow("Particle cap", "", 50, 1000, () -> Config.particleCap, v -> Config.particleCap = v)); break;
                case ARMOR_CULL: e.opts.add(new SliderRow("Armor draw distance", "", 8, 64, () -> Config.armorDistance, v -> Config.armorDistance = v)); break;
                case LAYER_CULL: e.opts.add(new SliderRow("Layer draw distance", "", 8, 64, () -> Config.layerDistance, v -> Config.layerDistance = v)); break;
                case SIGN_CULL: e.opts.add(new SliderRow("Sign draw distance", "", 6, 48, () -> Config.signDistance, v -> Config.signDistance = v)); break;
                case ENTITY_BUDGET: e.opts.add(new SliderRow("Entities per frame", "", 20, 250, () -> Config.entityBudget, v -> Config.entityBudget = v)); break;
                case ADAPTIVE_RD:
                    e.opts.add(new SliderRow("Target FPS", "", 60, 300, () -> Config.adaptiveTarget, v -> Config.adaptiveTarget = v));
                    e.opts.add(new SliderRow("Max render distance", "", 2, 16, () -> mc.gameSettings.renderDistanceChunks, v -> { Config.renderDistance = v; GfxTuner.apply(); }));
                    break;
                case TIME_CHANGER: e.opts.add(new SliderRow("Time of day", "", 0, 24000, () -> Config.timeValue, v -> Config.timeValue = v)); break;
                case CROSSHAIR: e.opts.add(new BtnRow(() -> "Style: " + new String[]{"Cross", "Dot", "Plus"}[Math.floorMod(Config.crosshairStyle, 3)], () -> Config.crosshairStyle = (Config.crosshairStyle + 1) % 3)); break;
                default: break;
            }
            entries.add(e);
        }
    }

    private List<Entry> visMods() {
        List<Entry> l = new ArrayList<Entry>();
        String q = search.toLowerCase();
        for (Entry e : entries) {
            if (modCat != 0 && !e.cat.equals(MOD_CATS[modCat])) continue;
            if (!q.isEmpty() && !e.name.toLowerCase().contains(q)) continue;
            l.add(e);
        }
        return l;
    }

    // ------------------------------------------------------------ cosmetics
    private String[] cosNames(int cat) {
        return cat == 0 ? CapeTextures.NAMES : (cat == 1 ? WingTextures.NAMES : (cat == 2 ? BandanaTextures.NAMES : HeadItems.NAMES));
    }
    private int cosIdx(int cat) { return cat == 0 ? Config.capeIdx : (cat == 1 ? Config.wingIdx : (cat == 2 ? Config.bandanaIdx : Config.headIdx)); }
    private void cosSet(int cat, int i) {
        if (cat == 0) Config.capeIdx = i; else if (cat == 1) Config.wingIdx = i; else if (cat == 2) Config.bandanaIdx = i; else Config.headIdx = i;
        Config.save();
    }

    private List<Integer> visCos() {
        List<Integer> l = new ArrayList<Integer>();
        String[] names = cosNames(cosCat);
        String q = search.toLowerCase();
        for (int i = 0; i < names.length; i++) if (q.isEmpty() || names[i].toLowerCase().contains(q)) l.add(i);
        return l;
    }

    // ------------------------------------------------------------ grid pass (draw + click share the same layout)
    private boolean gridPass(boolean draw, int mx, int my, boolean click) {
        boolean mods = top == Top.MODS;
        List<Entry> vm = mods ? visMods() : null;
        List<Integer> vc = mods ? null : visCos();
        int n = mods ? vm.size() : vc.size();
        int cardH = mods ? 130 : 122, gap = 10;
        int cols = Math.max(1, (gridW + gap) / (152 + gap));
        int cardW = (gridW - gap * (cols - 1)) / cols;
        int rows = (n + cols - 1) / cols;
        int total = rows * (cardH + gap);
        if (draw) {
            maxScroll = Math.max(0, total - gridH);
            scrollTarget = Math.max(0, Math.min(maxScroll, scrollTarget));
            scrollPos += (scrollTarget - scrollPos) * 0.26f;
        }
        int sc = Math.round(scrollPos);
        for (int i = 0; i < n; i++) {
            int x = gridX + (i % cols) * (cardW + gap), y = gridY + (i / cols) * (cardH + gap) - sc;
            if (y + cardH < gridY || y > gridY + gridH) continue;
            boolean handled = mods ? modCard(vm.get(i), x, y, cardW, cardH, mx, my, draw, click)
                                   : cosCard(vc.get(i), x, y, cardW, cardH, mx, my, draw, click);
            if (handled) return true;
        }
        return false;
    }

    private boolean modCard(Entry e, int x, int y, int w, int h, int mx, int my, boolean draw, boolean click) {
        int ox = x + 8, oy = y + 86, ow = w - 16;
        int tx = x + 8, ty = y + 107;
        boolean inGrid = in(mx, my, gridX, gridY, gridW, gridH) && drawer == null;
        if (click) {
            if (!inGrid) return false;
            if (in(mx, my, ox, oy, ow, 17) && !e.opts.isEmpty()) { drawer = e; return true; }
            if (in(mx, my, tx, ty, ow, 17)) { e.toggle.run(); return true; }
            return false;
        }
        boolean hover = inGrid && in(mx, my, x, y, w, h);
        float a = anim("card:" + e.name, hover);
        float on = anim("on:" + e.name, e.on.getAsBoolean());
        UI.rrect(x - 1, y - 1, w + 2, h + 2, 11, c(gold(), (int) (40 + 120 * a)));
        UI.rrect(x, y, w, h, 10, c(mix(CARD, CARD_H, a), 175));
        UI.rrect(x + 10, y + 10, w - 20, 54, 8, c(DARK, 150));
        tc(e.abbr, x + w / 2f, y + 24, 18f, gold(), true);
        tc(e.name, x + w / 2f, y + 68, e.name.length() > 18 ? 8.5f : 10f, TEXT, true);
        boolean hasOpt = !e.opts.isEmpty();
        boolean oh = inGrid && in(mx, my, ox, oy, ow, 17);
        UI.rrect(ox, oy, ow, 17, 6, c(mix(0x24200F, 0x3A2F13, oh && hasOpt ? 1f : 0f), 235));
        tc("OPTIONS", x + w / 2f, oy + 4, 8f, hasOpt ? TEXT : OFF, true);
        boolean th = inGrid && in(mx, my, tx, ty, ow, 17);
        int col = mix(mix(0x2A2412, 0x3A3118, th ? 1f : 0f), gold(), on);
        UI.rrect(tx, ty, ow, 17, 6, c(col, 245));
        tc(on > 0.5f ? "ENABLED" : "DISABLED", x + w / 2f, ty + 4, 8f, on > 0.5f ? DARK : SUB, true);
        return false;
    }

    private boolean cosCard(int idx, int x, int y, int w, int h, int mx, int my, boolean draw, boolean click) {
        int bx = x + 8, by = y + h - 25, bw = w - 16;
        boolean inGrid = in(mx, my, gridX, gridY, gridW, gridH);
        if (click) {
            if (inGrid && in(mx, my, x, y, w, h)) { cosSet(cosCat, idx); return true; }
            return false;
        }
        boolean sel = cosIdx(cosCat) == idx;
        boolean hover = inGrid && in(mx, my, x, y, w, h);
        float a = anim("cos:" + cosCat + ":" + idx, hover);
        float s = anim("csel:" + cosCat + ":" + idx, sel);
        UI.rrect(x - 1, y - 1, w + 2, h + 2, 11, c(gold(), (int) (40 + 150 * Math.max(a * 0.6f, s))));
        UI.rrect(x, y, w, h, 10, c(mix(CARD, CARD_H, a), 175));
        UI.rrect(x + 10, y + 10, w - 20, 62, 8, c(DARK, 150));
        int tx = x + w / 2, ty = y + 11;
        if (idx == 0) {
            tc("-", tx, y + 28, 18f, SUB, true);
        } else if (cosCat == 0) {
            ResourceLocation tex = CapeTextures.preview(idx);
            if (tex != null) UI.drawTex(tex, tx - 17, ty + 3, 34, 54, CapeTextures.U0, CapeTextures.V0, CapeTextures.U1, CapeTextures.V1, alpha, false);
        } else if (cosCat == 1) {
            ResourceLocation tex = WingTextures.get(idx);
            if (tex != null) UI.drawTex(tex, tx - 26, ty + 4, 52, 52, 0f, 0f, 1f, 1f, alpha, true);
        } else if (cosCat == 2) {
            ResourceLocation tex = BandanaTextures.get(idx);
            if (tex != null) UI.drawTex(tex, tx - 32, ty + 18, 64, 16, 0f, 0f, 1f, 1f, alpha, false);
        } else {
            tc(HeadItems.ABBR[idx], tx, y + 28, 18f, gold(), true);
        }
        String nm = cosNames(cosCat)[idx];
        tc(nm, x + w / 2f, y + 76, nm.length() > 16 ? 8.5f : 10f, TEXT, true);
        int col = mix(mix(0x2A2412, 0x3A3118, a), gold(), s);
        UI.rrect(bx, by, bw, 17, 6, c(col, 245));
        tc(sel ? "EQUIPPED" : "EQUIP", x + w / 2f, by + 4, 8f, sel ? DARK : TEXT, true);
        return false;
    }

    // ------------------------------------------------------------ screen
    @Override
    public void initGui() {
        pw = Math.min(width - 16, 680);
        ph = Math.min(height - 16, 400);
        px = (width - pw) / 2;
        py = (height - ph) / 2;
        leftX = px + 10; leftY = py + TOPH + 6; leftW = 124; leftH = ph - TOPH - 16;
        mainX = leftX + leftW + 12; mainW = px + pw - 12 - mainX;
        chipY = py + TOPH + 8;
        gridX = mainX; gridY = chipY + 26; gridW = mainW; gridH = py + ph - 12 - gridY;
        if (entries.isEmpty()) buildEntries();
    }

    @Override
    public void drawScreen(int mx, int my, float pt) {
        alpha = Math.max(0.12f, Math.min(1f, (System.currentTimeMillis() - openTime) / 240f));
        ScaledResolution sr = new ScaledResolution(mc);
        sf = sr.getScaleFactor(); sh = sr.getScaledHeight();
        CapeTextures.budget = 3;
        int smx = drawer != null ? -1000 : mx, smy = drawer != null ? -1000 : my;
        drawRect(0, 0, width, height, ((int) (alpha * 150)) << 24);

        GlStateManager.pushMatrix();
        GlStateManager.translate(0f, (1f - alpha) * 10f, 0f);

        UI.glow(px, py, pw, ph, 14, gold(), (int) (alpha * 55));
        UI.rrect(px - 1, py - 1, pw + 2, ph + 2, 15, c(gold(), 120));
        UI.rrect(px, py, pw, ph, 14, c(BG, 215));
        UI.rrect(px, py, pw, TOPH, 14, c(PANEL, 200));
        drawRect(px, py + TOPH - 14, px + pw, py + TOPH, c(PANEL, 200));
        drawRect(px + 14, py + TOPH, px + pw - 14, py + TOPH + 1, c(gold(), 70));

        // logo
        UI.cursive("Jonny Client", px + 16, py + 6, 24f, c(gold(), 255), true);

        // top tabs
        Top[] tops = Top.values();
        int tabX = mainX + 20;
        for (int i = 0; i < tops.length; i++) {
            int tw0 = (int) tw(tops[i].title, 9f, true) + 28;
            boolean sel = tops[i] == top;
            boolean h = in(smx, smy, tabX, py + 13, tw0, 22);
            float a = anim("top:" + i, sel);
            UI.rrect(tabX, py + 13, tw0, 22, 8, c(mix(mix(0x241F10, 0x33291A, h ? 1f : 0f), gold(), a), 235));
            tc(tops[i].title, tabX + tw0 / 2f, py + 19, 9f, sel ? DARK : TEXT, true);
            tabX += tw0 + 8;
        }
        boolean xh = in(smx, smy, px + pw - 36, py + 13, 22, 22);
        UI.rrect(px + pw - 36, py + 13, 22, 22, 8, c(mix(0x241F10, 0xC03A3A, anim("xbtn", xh)), 235));
        tc("x", px + pw - 25, py + 17, 11f, TEXT, true);

        drawLeft(smx, smy);

        if (top == Top.SETTINGS) {
            setHover(gridX, chipY, gridW, py + ph - chipY);
            drawSettings(smx, smy);
        } else {
            drawChips(smx, smy);
            GL11.glEnable(GL11.GL_SCISSOR_TEST);
            scissor(gridX - 2, gridY, gridW + 4, gridH);
            setHover(gridX, gridY, gridW, gridH);
            gridPass(true, smx, smy, false);
            GL11.glDisable(GL11.GL_SCISSOR_TEST);
            if (maxScroll > 0) {
                int barH = Math.max(26, gridH * gridH / (gridH + maxScroll));
                int barY = gridY + (int) ((gridH - barH) * (Math.round(scrollPos) / (float) maxScroll));
                UI.rrect(px + pw - 9, barY, 3, barH, 1, c(gold(), 200));
            }
        }

        if (drawer != null) drawDrawer(mx, my);
        if (System.currentTimeMillis() < flashUntil) {
            float fw = tw(flash, 9f, true) + 24;
            UI.rrect((int) (px + (pw - fw) / 2), py + ph - 34, (int) fw, 22, 8, c(gold(), 240));
            tc(flash, px + pw / 2f, py + ph - 29, 9f, DARK, true);
        }
        GlStateManager.popMatrix();
        super.drawScreen(mx, my, pt);
    }

    private void drawLeft(int mx, int my) {
        UI.rrect(leftX, leftY, leftW, leftH, 10, c(PANEL, 170));
        t("PROFILES", leftX + 12, leftY + 9, 8f, SUB, true);
        for (int i = 0; i < Config.PROFILE_NAMES.length; i++) {
            int ry = leftY + 26 + i * 24;
            boolean sel = Config.profile == i;
            float a = anim("prof:" + i, sel);
            boolean h = in(mx, my, leftX + 8, ry, leftW - 16, 20);
            UI.rrect(leftX + 8, ry, leftW - 16, 20, 7, c(mix(mix(0x241F10, 0x33291A, h ? 1f : 0f), gold(), a), 235));
            t(Config.PROFILE_NAMES[i], leftX + 18, ry + 5, 9f, sel ? DARK : TEXT, true);
        }
        int by = leftY + leftH - 28;
        boolean mh = in(mx, my, leftX + 8, by - 52, leftW - 16, 22);
        UI.rrect(leftX + 8, by - 52, leftW - 16, 22, 7, c(gold(), mh ? 255 : 210));
        tc("MAX FPS PRESET", leftX + leftW / 2f, by - 46, 8f, DARK, true);
        boolean sh2 = in(mx, my, leftX + 8, by - 26, leftW - 16, 20);
        UI.rrect(leftX + 8, by - 26, leftW - 16, 20, 7, c(mix(0x241F10, 0x3A3118, sh2 ? 1f : 0f), 240));
        tc("SAVE PROFILE", leftX + leftW / 2f, by - 21, 8f, TEXT, true);
        boolean eh = in(mx, my, leftX + 8, by, leftW - 16, 20);
        UI.rrect(leftX + 8, by, leftW - 16, 20, 7, c(mix(0x241F10, 0x3A3118, eh ? 1f : 0f), 240));
        tc("EDIT HUD LAYOUT", leftX + leftW / 2f, by + 5, 8f, TEXT, true);
    }

    private void drawChips(int mx, int my) {
        String[] cats = top == Top.MODS ? MOD_CATS : COS_CATS;
        int cur = top == Top.MODS ? modCat : cosCat;
        int x = mainX;
        for (int i = 0; i < cats.length; i++) {
            int cw = (int) tw(cats[i], 8f, true) + 22;
            boolean sel = i == cur, h = in(mx, my, x, chipY, cw, 18);
            float a = anim("chip:" + top + i, sel);
            UI.rrect(x, chipY, cw, 18, 7, c(mix(mix(0x241F10, 0x33291A, h ? 1f : 0f), gold(), a), 235));
            tc(cats[i], x + cw / 2f, chipY + 5, 8f, sel ? DARK : TEXT, true);
            x += cw + 6;
        }
        int sx = mainX + mainW - 150;
        UI.rrect(sx, chipY, 150, 18, 7, c(searchFocus ? 0x3A3118 : 0x241F10, 240));
        String shown = search.isEmpty() && !searchFocus ? "Search..." : search + ((System.currentTimeMillis() / 500) % 2 == 0 && searchFocus ? "_" : "");
        t(shown, sx + 8, chipY + 4, 9f, search.isEmpty() && !searchFocus ? SUB : TEXT, false);
    }

    private final List<Item> settingsItems = new ArrayList<Item>();

    private void drawSettings(int mx, int my) {
        if (settingsItems.isEmpty()) {
            settingsItems.add(new BoolRow("s:font", "Modern HUD font", "Smooth Segoe UI text on the HUD", () -> Config.modernFont, () -> Config.modernFont = !Config.modernFont));
            settingsItems.add(new BtnRow(() -> "Accent color: " + UI.ACCENT_NAMES[Math.floorMod(Config.accentIdx, UI.ACCENTS.length)], () -> Config.accentIdx = (Config.accentIdx + 1) % UI.ACCENTS.length));
            settingsItems.add(new BtnRow(() -> "Reset HUD positions and options", HudMods::resetAll));
            settingsItems.add(new BtnRow(() -> "Reset everything to default", () -> { HudMods.resetAll(); GfxTuner.resetAll(); Events.refreshEntityWeights(); }));
        }
        int y = chipY;
        for (Item it : settingsItems) { it.draw(mainX, y, mainW - 8, mx, my); y += it.step(); }
    }

    private void drawDrawer(int mx, int my) {
        drawRect(px, py, px + pw, py + ph, ((int) (alpha * 130)) << 24);
        int dw = 330, total = 0;
        for (Item it : drawer.opts) total += it.step();
        int dh = 92 + total + 40;
        int dx = px + (pw - dw) / 2, dy = py + (ph - dh) / 2;
        UI.glow(dx, dy, dw, dh, 12, gold(), (int) (alpha * 70));
        UI.rrect(dx - 1, dy - 1, dw + 2, dh + 2, 13, c(gold(), 150));
        UI.rrect(dx, dy, dw, dh, 12, c(BG, 245));
        tc(drawer.name.toUpperCase() + " OPTIONS", dx + dw / 2f, dy + 14, 11f, gold(), true);
        tc(drawer.desc, dx + dw / 2f, dy + 32, 8.5f, SUB, false);
        setHover(dx, dy, dw, dh);
        int y = dy + 58;
        for (Item it : drawer.opts) { it.draw(dx + 14, y, dw - 28, mx, my); y += it.step(); }
        int by = dy + dh - 34;
        boolean h = in(mx, my, dx + dw / 2 - 50, by, 100, 22);
        UI.rrect(dx + dw / 2 - 50, by, 100, 22, 8, c(gold(), h ? 255 : 220));
        tc("DONE", dx + dw / 2f, by + 6, 9f, DARK, true);
    }

    // ------------------------------------------------------------ input
    @Override
    protected void mouseClicked(int mx, int my, int btn) throws IOException {
        super.mouseClicked(mx, my, btn);
        if (btn != 0) return;
        searchFocus = false;

        if (drawer != null) {
            int dw = 330, total = 0;
            for (Item it : drawer.opts) total += it.step();
            int dh = 92 + total + 40;
            int dx = px + (pw - dw) / 2, dy = py + (ph - dh) / 2;
            if (in(mx, my, dx + dw / 2 - 50, dy + dh - 34, 100, 22) || !in(mx, my, dx, dy, dw, dh)) { drawer = null; Config.save(); return; }
            int y = dy + 58;
            for (Item it : drawer.opts) {
                if (in(mx, my, dx + 14, y, dw - 28, it.step() - 4)) { it.click(dx + 14, y, dw - 28, mx, my); return; }
                y += it.step();
            }
            return;
        }

        if (in(mx, my, px + pw - 36, py + 13, 22, 22)) { mc.displayGuiScreen(null); return; }
        Top[] tops = Top.values();
        int tabX = mainX + 20;
        for (int i = 0; i < tops.length; i++) {
            int tw0 = (int) tw(tops[i].title, 9f, true) + 28;
            if (in(mx, my, tabX, py + 13, tw0, 22)) { top = tops[i]; lastTop = top; scrollTarget = 0; scrollPos = 0; search = ""; return; }
            tabX += tw0 + 8;
        }
        // left panel
        for (int i = 0; i < Config.PROFILE_NAMES.length; i++) {
            if (in(mx, my, leftX + 8, leftY + 26 + i * 24, leftW - 16, 20)) {
                if (Config.profile != i) { Config.switchProfile(i); GfxTuner.apply(); Events.refreshEntityWeights(); flash("Loaded profile: " + Config.PROFILE_NAMES[i]); }
                return;
            }
        }
        int by = leftY + leftH - 28;
        if (in(mx, my, leftX + 8, by - 52, leftW - 16, 22)) { GfxTuner.applyMaxFpsPreset(); Events.refreshEntityWeights(); flash("Max FPS preset applied"); return; }
        if (in(mx, my, leftX + 8, by - 26, leftW - 16, 20)) { Config.save(); flash("Saved profile: " + Config.PROFILE_NAMES[Config.profile]); return; }
        if (in(mx, my, leftX + 8, by, leftW - 16, 20)) { mc.displayGuiScreen(new HudEditor()); return; }

        if (top == Top.SETTINGS) {
            int y = chipY;
            for (Item it : settingsItems) {
                if (in(mx, my, mainX, y, mainW - 8, it.step() - 4)) { it.click(mainX, y, mainW - 8, mx, my); return; }
                y += it.step();
            }
            return;
        }
        // chips + search
        String[] cats = top == Top.MODS ? MOD_CATS : COS_CATS;
        int x = mainX;
        for (int i = 0; i < cats.length; i++) {
            int cw = (int) tw(cats[i], 8f, true) + 22;
            if (in(mx, my, x, chipY, cw, 18)) {
                if (top == Top.MODS) { modCat = i; lastModCat = i; } else { cosCat = i; lastCosCat = i; }
                scrollTarget = 0; scrollPos = 0;
                return;
            }
            x += cw + 6;
        }
        if (in(mx, my, mainX + mainW - 150, chipY, 150, 18)) { searchFocus = true; return; }
        gridPass(false, mx, my, true);
    }

    private void flash(String s) { flash = s; flashUntil = System.currentTimeMillis() + 1800; }

    @Override
    protected void mouseClickMove(int mx, int my, int btn, long time) { if (dragging != null) dragging.drag(mx); }

    @Override
    protected void mouseReleased(int mx, int my, int state) {
        super.mouseReleased(mx, my, state);
        dragging = null;
        Config.save();
    }

    @Override
    protected void keyTyped(char ch, int code) throws IOException {
        if (searchFocus) {
            if (code == Keyboard.KEY_ESCAPE) { searchFocus = false; return; }
            if (code == Keyboard.KEY_BACK) { if (!search.isEmpty()) search = search.substring(0, search.length() - 1); scrollTarget = 0; return; }
            if (ChatAllowedCharacters.isAllowedCharacter(ch) && search.length() < 24) { search += ch; scrollTarget = 0; }
            return;
        }
        if (code == Keyboard.KEY_ESCAPE && drawer != null) { drawer = null; return; }
        super.keyTyped(ch, code);
    }

    @Override
    public void handleMouseInput() throws IOException {
        super.handleMouseInput();
        int d = Mouse.getEventDWheel();
        if (d != 0 && drawer == null) scrollTarget = Math.max(0, Math.min(maxScroll, scrollTarget - Integer.signum(d) * 44));
    }

    @Override
    public void onGuiClosed() { Config.save(); }

    @Override
    public boolean doesGuiPauseGame() { return false; }
}
