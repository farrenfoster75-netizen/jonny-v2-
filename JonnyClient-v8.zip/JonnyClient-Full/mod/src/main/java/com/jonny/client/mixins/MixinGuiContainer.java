package com.jonny.client.mixins;

import com.jonny.client.InvLogo;
import net.minecraft.client.gui.inventory.GuiContainer;
import net.minecraft.client.gui.inventory.GuiContainerCreative;
import net.minecraft.client.gui.inventory.GuiInventory;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(GuiContainer.class)
public class MixinGuiContainer {
    @Inject(method = "drawScreen", at = @At("TAIL"), require = 0)
    private void jonny$logo(int mx, int my, float pt, CallbackInfo ci) {
        Object self = this;
        if (self instanceof GuiInventory || self instanceof GuiContainerCreative) InvLogo.draw(self);
    }
}
