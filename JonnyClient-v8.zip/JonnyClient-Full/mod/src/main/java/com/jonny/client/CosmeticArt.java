package com.jonny.client;

import java.util.Random;

/** Pixel-art painters used by capes and bandanas. */
public class CosmeticArt {
    public static final int TEXT = 0, STARS = 1, STRIPES = 2, DIAG = 3, CHECK = 4, WAVES = 5, FLAMES = 6, ZIGZAG = 7,
            GRID = 8, RAIN = 9, HEARTS = 10, SKULL = 11, CREEPER = 12, BOLT = 13, CROWN = 14, SUN = 15, RAINBOW = 16,
            CAMO = 17, TIGER = 18, DIAMONDS = 19, SNOW = 20, DOTS = 21, PETALS = 22, CRACKS = 23, AURORA = 24, RINGS = 25;

    private static int op(int rgb) { return 0xFF000000 | rgb; }

    public static void paint(Pix p, int design, int c1, int c2, int c3, long seed) {
        Random r = new Random(seed);
        c1 = op(c1); c2 = op(c2); c3 = op(c3);
        int w = p.w, h = p.h;
        switch (design) {
            case STARS: {
                p.vgrad(c1, c2);
                for (int i = 0; i < w * h / 9; i++) {
                    int x = r.nextInt(w), y = r.nextInt(h);
                    p.set(x, y, c3);
                    if (r.nextInt(6) == 0) { p.set(x + 1, y, Pix.lerp(c3, c2, .5f)); p.set(x - 1, y, Pix.lerp(c3, c2, .5f)); p.set(x, y + 1, Pix.lerp(c3, c2, .5f)); p.set(x, y - 1, Pix.lerp(c3, c2, .5f)); }
                }
                break;
            }
            case STRIPES: {
                for (int x = 0; x < w; x++) { int c = (x / 3) % 2 == 0 ? c1 : c2; for (int y = 0; y < h; y++) p.set(x, y, c); }
                for (int x = 1; x < w; x += 6) for (int y = 0; y < h; y++) p.set(x, y, c3);
                break;
            }
            case DIAG: {
                for (int y = 0; y < h; y++) for (int x = 0; x < w; x++) p.set(x, y, ((x + y) / 3) % 2 == 0 ? c1 : c2);
                for (int y = 0; y < h; y++) for (int x = 0; x < w; x++) if ((x + y) % 12 == 0) p.set(x, y, c3);
                break;
            }
            case CHECK: {
                for (int y = 0; y < h; y++) for (int x = 0; x < w; x++) p.set(x, y, ((x / 2) + (y / 2)) % 2 == 0 ? c1 : c2);
                break;
            }
            case WAVES: {
                p.vgrad(c1, c2);
                for (int y = 0; y < h; y++) for (int x = 0; x < w; x++) {
                    int off = (int) Math.round(2 * Math.sin(x * 0.7));
                    if (Math.floorMod(y + off, 6) == 0) p.set(x, y, c3);
                }
                break;
            }
            case FLAMES: {
                p.vgrad(c1, Pix.lerp(c1, c2, .35f));
                for (int x = 0; x < w; x++) {
                    int fh = (int) (h * 0.35 + (h * 0.30) * Math.abs(Math.sin(x * 0.85 + r.nextFloat() * 0.6)));
                    for (int k = 0; k < fh; k++) {
                        int y = h - 1 - k;
                        float t = k / (float) fh;
                        p.set(x, y, t < 0.45f ? c3 : Pix.lerp(c3, c2, (t - 0.45f) / 0.55f));
                    }
                }
                break;
            }
            case ZIGZAG: {
                p.vgrad(c1, c2);
                for (int row = 2; row < h; row += 6)
                    for (int x = 0; x < w; x++) { int zz = (x % 4 < 2) ? x % 4 : 3 - x % 4; p.set(x, row + zz, c3); p.set(x, row + zz + 1, c3); }
                break;
            }
            case GRID: {
                p.fill(c1);
                for (int y = 0; y < h; y++) for (int x = 0; x < w; x++) if (x % 4 == 0 || y % 4 == 0) p.set(x, y, Pix.lerp(c1, c3, .55f));
                for (int x = 0; x < w; x++) { p.set(x, 0, c3); p.set(x, h - 1, c3); }
                for (int y = 0; y < h; y++) { p.set(0, y, c3); p.set(w - 1, y, c3); }
                break;
            }
            case RAIN: {
                p.fill(c1);
                for (int x = 0; x < w; x += 2) {
                    int len = 4 + r.nextInt(10), top = r.nextInt(h);
                    for (int k = 0; k < len; k++) p.set(x, Math.floorMod(top + k, h), k == len - 1 ? c3 : Pix.lerp(c2, c1, 1f - k / (float) len));
                }
                break;
            }
            case HEARTS: {
                p.vgrad(c1, c2);
                String[] hh = {"01010", "11111", "11111", "01110", "00100"};
                for (int gy = 1; gy < h - 5; gy += 8)
                    for (int gx = ((gy / 8) % 2 == 0 ? 1 : 4); gx < w - 5; gx += 8)
                        for (int j = 0; j < 5; j++) for (int i = 0; i < 5; i++) if (hh[j].charAt(i) == '1') p.set(gx + i, gy + j, c3);
                break;
            }
            case SKULL: {
                p.vgrad(c1, c2);
                int ox = (w - 12) / 2, oy = (h - 14) / 2;
                p.rect(ox + 1, oy, 10, 9, c3); p.rect(ox, oy + 2, 12, 5, c3);
                p.rect(ox + 3, oy + 9, 6, 4, c3);
                p.rect(ox + 2, oy + 3, 3, 3, c1); p.rect(ox + 7, oy + 3, 3, 3, c1);
                p.set(ox + 5, oy + 7, c1); p.set(ox + 6, oy + 7, c1);
                for (int i = 0; i < 3; i++) p.set(ox + 4 + i * 2, oy + 11, c1);
                break;
            }
            case CREEPER: {
                for (int y = 0; y < h; y++) for (int x = 0; x < w; x++) p.set(x, y, ((x * 7 + y * 13) % 5 < 2) ? c1 : c2);
                int ox = (w - 12) / 2, oy = (h - 14) / 2;
                p.rect(ox + 1, oy + 1, 3, 3, c3); p.rect(ox + 8, oy + 1, 3, 3, c3);
                p.rect(ox + 5, oy + 4, 2, 4, c3); p.rect(ox + 3, oy + 7, 6, 3, c3);
                p.rect(ox + 3, oy + 10, 2, 3, c3); p.rect(ox + 7, oy + 10, 2, 3, c3);
                break;
            }
            case BOLT: {
                p.vgrad(c1, c2);
                int x = w - 4;
                for (int y = 0; y < h; y++) {
                    p.rect(x, y, 3, 1, c3);
                    x += (y % 5 < 2) ? -2 : 1;
                    if (x < 2) x = w - 5;
                }
                break;
            }
            case CROWN: {
                p.vgrad(c1, c2);
                int ox = (w - 14) / 2, oy = (h - 9) / 2;
                p.rect(ox, oy + 4, 14, 5, c3);
                for (int i = 0; i < 4; i++) p.rect(ox + i * 4, oy, 2, 5, c3);
                p.rect(ox + 1, oy + 5, 12, 1, Pix.lerp(c3, 0xFFFFFFFF, .5f));
                p.set(ox + 3, oy + 6, 0xFFE53935); p.set(ox + 7, oy + 6, 0xFF3D5AFE); p.set(ox + 11, oy + 6, 0xFFE53935);
                break;
            }
            case SUN: {
                p.vgrad(c1, c2);
                int cx = w / 2, cy = h / 2 - 2;
                for (int y = 0; y < h; y++) for (int x = 0; x < w; x++) {
                    double d = Math.hypot(x - cx, y - cy);
                    if (d <= 5.5) p.set(x, y, c3);
                    else if (d <= 8.5 && ((int) (Math.atan2(y - cy, x - cx) * 4 / Math.PI + 8)) % 2 == 0) p.set(x, y, Pix.lerp(c3, c2, .35f));
                }
                for (int y = h - 5; y < h; y++) for (int x = 0; x < w; x++) p.set(x, y, (y % 2 == 0) ? Pix.lerp(c1, c2, .3f) : Pix.lerp(c1, 0xFF000000, .3f));
                break;
            }
            case RAINBOW: {
                int[] cols = {0xE53935, 0xFB8C00, 0xFDD835, 0x43A047, 0x1E88E5, 0x8E24AA};
                for (int y = 0; y < h; y++) { int c = op(cols[Math.min(5, y * 6 / h)]); for (int x = 0; x < w; x++) p.set(x, y, c); }
                break;
            }
            case CAMO: {
                p.fill(c1);
                int[] cs = {c2, c3, Pix.lerp(c1, 0xFF000000, .25f)};
                for (int i = 0; i < w * h / 14; i++) {
                    int cx = r.nextInt(w), cy = r.nextInt(h), rx = 1 + r.nextInt(3), ry = 1 + r.nextInt(3);
                    int c = cs[r.nextInt(3)];
                    for (int y = -ry; y <= ry; y++) for (int x = -rx; x <= rx; x++) if (x * x * ry * ry + y * y * rx * rx <= rx * rx * ry * ry) p.set(cx + x, cy + y, c);
                }
                break;
            }
            case TIGER: {
                p.fill(c1);
                for (int row = 1; row < h; row += 4)
                    for (int x = 0; x < w; x++) { int th = 1 + (int) Math.abs(2 * Math.sin(x * 0.9 + row)); for (int k = 0; k < th; k++) p.set(x, row + k, c2); }
                break;
            }
            case DIAMONDS: {
                p.fill(c1);
                for (int cy = 0; cy < h + 6; cy += 6) for (int cx = ((cy / 6) % 2 == 0 ? 0 : 3); cx < w + 6; cx += 6)
                    for (int y = -3; y <= 3; y++) for (int x = -3; x <= 3; x++) {
                        int d = Math.abs(x) + Math.abs(y);
                        if (d == 3) p.set(cx + x, cy + y, c3); else if (d < 3) p.set(cx + x, cy + y, d == 0 ? c3 : c2);
                    }
                break;
            }
            case SNOW: {
                p.vgrad(c1, c2);
                for (int i = 0; i < 7; i++) {
                    int cx = 2 + r.nextInt(Math.max(1, w - 4)), cy = 2 + r.nextInt(Math.max(1, h - 4));
                    p.set(cx, cy, c3); p.set(cx - 1, cy, c3); p.set(cx + 1, cy, c3); p.set(cx, cy - 1, c3); p.set(cx, cy + 1, c3);
                    p.set(cx - 1, cy - 1, Pix.lerp(c3, c2, .5f)); p.set(cx + 1, cy + 1, Pix.lerp(c3, c2, .5f));
                    p.set(cx + 1, cy - 1, Pix.lerp(c3, c2, .5f)); p.set(cx - 1, cy + 1, Pix.lerp(c3, c2, .5f));
                }
                break;
            }
            case DOTS: {
                p.vgrad(c1, c2);
                for (int y = 1; y < h; y += 4) for (int x = ((y / 4) % 2 == 0 ? 1 : 3); x < w; x += 4) { p.set(x, y, c3); p.set(x + 1, y, Pix.lerp(c3, c2, .4f)); }
                break;
            }
            case PETALS: {
                p.vgrad(c1, c2);
                for (int i = 0; i < w * h / 20; i++) {
                    int x = r.nextInt(w), y = r.nextInt(h);
                    p.set(x, y, c3); p.set(x + 1, y, Pix.lerp(c3, c2, .3f)); p.set(x, y + 1, Pix.lerp(c3, c2, .3f));
                }
                break;
            }
            case CRACKS: {
                p.vgrad(c1, c2);
                for (int k = 0; k < 4; k++) {
                    int x = r.nextInt(w), y = 0;
                    while (y < h) { p.set(x, y, c3); if (r.nextInt(3) == 0) x += r.nextInt(3) - 1; y++; if (r.nextInt(7) == 0) p.set(x + 1, y, Pix.lerp(c3, c1, .4f)); }
                }
                break;
            }
            case AURORA: {
                p.vgrad(c1, Pix.lerp(c1, c2, .3f));
                for (int x = 0; x < w; x++) {
                    int base = (int) (h * 0.35 + 4 * Math.sin(x * 0.55));
                    for (int k = 0; k < 11; k++) { int y = base + k; if (y >= 0 && y < h) p.set(x, y, Pix.lerp(c2, c3, k / 10f * (0.5f + 0.5f * (float) Math.sin(x * 0.3)))); }
                }
                for (int i = 0; i < 12; i++) p.set(r.nextInt(w), r.nextInt(h / 3), 0xFFFFFFFF);
                break;
            }
            case RINGS: {
                int cx = w / 2, cy = h / 2;
                for (int y = 0; y < h; y++) for (int x = 0; x < w; x++) {
                    int d = Math.max(Math.abs(x - cx), Math.abs(y - cy) * w / h);
                    p.set(x, y, (d / 2) % 3 == 0 ? c1 : ((d / 2) % 3 == 1 ? c2 : c3));
                }
                break;
            }
            default: p.vgrad(c1, c2);
        }
    }
}
