package com.jonny.client.mixins;

import com.jonny.client.Config;
import com.jonny.client.Feature;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.entity.RendererLivingEntity;
import net.minecraft.entity.EntityLivingBase;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Skips every extra layer (armor, held item, cape, head items) on far entities. */
@Mixin(RendererLivingEntity.class)
public class MixinRendererLivingEntity {
    @Inject(method = "renderLayers(Lnet/minecraft/entity/EntityLivingBase;FFFFFFF)V", at = @At("HEAD"), cancellable = true, require = 0)
    private void jonny$farLayers(EntityLivingBase e, float a, float b, float c, float d, float f, float g, float h, CallbackInfo ci) {
        if (!Feature.LAYER_CULL.enabled) return;
        Minecraft mc = Minecraft.getMinecraft();
        if (mc.thePlayer == null || e == mc.thePlayer) return;
        if (mc.thePlayer.getDistanceToEntity(e) > Config.layerDistance) ci.cancel();
    }
}
