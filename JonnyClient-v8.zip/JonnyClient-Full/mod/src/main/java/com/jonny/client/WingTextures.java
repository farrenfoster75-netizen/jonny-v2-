package com.jonny.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.util.ResourceLocation;

import java.awt.Color;
import java.awt.GradientPaint;
import java.awt.Graphics2D;
import java.awt.RadialGradientPaint;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;
import java.util.Random;

/** 13 wing styles: 10 dragon/bat wings (matching the reference) and 3 feathered wings. */
public class WingTextures {
    // name, feathered?, top, bottom, blob1, blob2, bone color, skeleton?
    private static final Object[][] DEFS = {
        {"No wings", false, 0, 0, 0, 0, 0, false},
        {"Nebula Dragon", false, 0x1B0830, 0x3A1070, 0xC23CFF, 0xFF6BD6, 0x12041F, false},
        {"Golden Dragon", false, 0x5A3B00, 0xFFD54A, 0xFFE9A0, 0xFFB300, 0x3A2400, false},
        {"White Dragon", false, 0xFFFFFF, 0xE3E9F5, 0xFFFFFF, 0xC9D3EA, 0xAAB4CC, false},
        {"Crimson Dragon", false, 0x2A0000, 0xD0101A, 0xFF3B30, 0xFF8A65, 0x1A0000, false},
        {"Skeleton", false, 0x202020, 0x303030, 0x404040, 0x505050, 0xEFE9D2, true},
        {"Shadow Dragon", false, 0x08080B, 0x1A1A22, 0x34343F, 0x22222B, 0x050507, false},
        {"Ocean Dragon", false, 0x001B3D, 0x00B4D8, 0x90E0EF, 0x0077B6, 0x001020, false},
        {"Toxic Dragon", false, 0x0B2A0B, 0x39FF14, 0xB6FF8A, 0x1FA010, 0x051505, false},
        {"Sakura Dragon", false, 0xFF9EC7, 0xFFD6E8, 0xFFFFFF, 0xFF6FA5, 0x8A3A5A, false},
        {"Frost Dragon", false, 0x1E3C72, 0xBFE9FF, 0xFFFFFF, 0x6FB8FF, 0x0F2A4A, false},
        {"Angel", true, 0xFFFFFF, 0xDDE6F5, 0xFFFFFF, 0xC9D3EA, 0, false},
        {"Black & White", true, 0x08080A, 0xF2F2F5, 0x777788, 0xFFFFFF, 0, false},
        {"Phoenix", true, 0xFF3B00, 0xFFD000, 0xFF8A00, 0xFF1A1A, 0, false},
    };
    public static final String[] NAMES = new String[DEFS.length];
    static { for (int i = 0; i < DEFS.length; i++) NAMES[i] = (String) DEFS[i][0]; }
    private static final ResourceLocation[] LOCS = new ResourceLocation[DEFS.length];

    public static boolean feathered(int idx) { return idx > 0 && idx < DEFS.length && (Boolean) DEFS[idx][1]; }
    public static boolean skeleton(int idx) { return idx > 0 && idx < DEFS.length && (Boolean) DEFS[idx][7]; }
    public static int boneColor(int idx) { return idx > 0 && idx < DEFS.length ? (Integer) DEFS[idx][6] : 0; }

    public static ResourceLocation get(int idx) {
        if (idx <= 0 || idx >= DEFS.length) return null;
        if (LOCS[idx] == null) LOCS[idx] = make(idx);
        return LOCS[idx];
    }

    private static ResourceLocation make(int idx) {
        Object[] d = DEFS[idx];
        int n = 128;
        BufferedImage img = new BufferedImage(n, n, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g = img.createGraphics();
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        Random rnd = new Random(1337L + idx);
        Color top = new Color((Integer) d[2]), bottom = new Color((Integer) d[3]);
        Color[] blobs = {new Color((Integer) d[4]), new Color((Integer) d[5])};
        g.setPaint(new GradientPaint(0, 0, top, 0, n, bottom));
        g.fillRect(0, 0, n, n);
        for (int i = 0; i < 30; i++) {
            float cx = rnd.nextFloat() * n, cy = rnd.nextFloat() * n, r = 12 + rnd.nextFloat() * 30;
            Color c = blobs[rnd.nextInt(2)];
            Color c0 = new Color(c.getRed(), c.getGreen(), c.getBlue(), idx == 1 ? 130 : 80);
            Color c1 = new Color(c.getRed(), c.getGreen(), c.getBlue(), 0);
            g.setPaint(new RadialGradientPaint(cx, cy, r, new float[]{0f, 1f}, new Color[]{c0, c1}));
            g.fillOval((int) (cx - r), (int) (cy - r), (int) (r * 2), (int) (r * 2));
        }
        int stars = (idx == 1 || idx == 6 || idx == 7) ? 90 : 40;
        for (int i = 0; i < stars; i++) {
            int x = rnd.nextInt(n), y = rnd.nextInt(n), a = 130 + rnd.nextInt(125);
            img.setRGB(x, y, new Color(255, 245, 255, a).getRGB());
            if (rnd.nextInt(8) == 0) { img.setRGB(Math.min(n - 1, x + 1), y, new Color(255, 245, 255, a / 2).getRGB()); img.setRGB(x, Math.min(n - 1, y + 1), new Color(255, 245, 255, a / 2).getRGB()); }
        }
        g.dispose();
        return Minecraft.getMinecraft().getTextureManager().getDynamicTextureLocation("jonny_wings_" + idx, new DynamicTexture(img));
    }
}
