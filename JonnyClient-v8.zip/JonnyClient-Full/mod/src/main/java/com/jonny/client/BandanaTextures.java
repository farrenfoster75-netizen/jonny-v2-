package com.jonny.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.util.ResourceLocation;

public class BandanaTextures {
    private static final Object[][] DEFS = {
        {"No bandana", -1, 0, 0, 0},
        {"Red Paisley", CosmeticArt.DOTS, 0xB3121B, 0xD62E36, 0xFFFFFF},
        {"Blue Paisley", CosmeticArt.DOTS, 0x0B3C8C, 0x2368D9, 0xFFFFFF},
        {"Black", CosmeticArt.DIAG, 0x0A0A0A, 0x151515, 0x2A2A2A},
        {"White", CosmeticArt.DIAG, 0xF5F5F5, 0xE6E6E6, 0xFFFFFF},
        {"Gold", CosmeticArt.DIAMONDS, 0x6B4A00, 0xC9951A, 0xFFE08A},
        {"Camo", CosmeticArt.CAMO, 0x3B4A2B, 0x6B7F3A, 0x2A331E},
        {"Pink Hearts", CosmeticArt.HEARTS, 0xFF758C, 0xFF9EB5, 0xFFFFFF},
        {"Neon Green", CosmeticArt.GRID, 0x061A06, 0x061A06, 0x39FF14},
        {"Galaxy", CosmeticArt.STARS, 0x0F0C29, 0x5B1FA8, 0xFFFFFF},
        {"Tie-Dye", CosmeticArt.RAINBOW, 0, 0, 0},
        {"Checker", CosmeticArt.CHECK, 0x111111, 0xF2F2F2, 0xFFFFFF},
        {"Flames", CosmeticArt.FLAMES, 0x2B0000, 0xFF4500, 0xFFD000},
    };
    public static final String[] NAMES = new String[DEFS.length];
    static { for (int i = 0; i < DEFS.length; i++) NAMES[i] = (String) DEFS[i][0]; }
    private static final ResourceLocation[] LOCS = new ResourceLocation[DEFS.length];

    public static ResourceLocation get(int idx) {
        if (idx <= 0 || idx >= DEFS.length) return null;
        if (LOCS[idx] == null) {
            Object[] d = DEFS[idx];
            Pix p = new Pix(32, 8);
            CosmeticArt.paint(p, (Integer) d[1], (Integer) d[2], (Integer) d[3], (Integer) d[4], 77L + idx);
            LOCS[idx] = Minecraft.getMinecraft().getTextureManager().getDynamicTextureLocation("jonny_bandana_" + idx, new DynamicTexture(p.toImage(4)));
        }
        return LOCS[idx];
    }
}
