package com.jonny.client.mixins;

import com.jonny.client.Config;
import com.jonny.client.Feature;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.tileentity.TileEntitySignRenderer;
import net.minecraft.tileentity.TileEntitySign;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(TileEntitySignRenderer.class)
public class MixinTileEntitySignRenderer {
    @Inject(method = "renderTileEntityAt(Lnet/minecraft/tileentity/TileEntitySign;DDDFI)V", at = @At("HEAD"), cancellable = true, require = 0)
    private void jonny$cullSigns(TileEntitySign te, double x, double y, double z, float pt, int stage, CallbackInfo ci) {
        if (!Feature.SIGN_CULL.enabled || te == null) return;
        Minecraft mc = Minecraft.getMinecraft();
        if (mc.thePlayer == null) return;
        double max = Config.signDistance;
        if (mc.thePlayer.getDistanceSq(te.getPos()) > max * max) ci.cancel();
    }
}
