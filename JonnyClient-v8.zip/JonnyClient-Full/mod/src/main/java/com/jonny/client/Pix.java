package com.jonny.client;

import java.awt.image.BufferedImage;

/** Tiny pixel-art canvas with a 3x5 pixel font. */
public class Pix {
    public final int w, h;
    public final int[] px;
    private static final String[] FONT = new String[128];
    static {
        String[][] f = {
            {"A","111101111101101"},{"B","110101110101110"},{"C","111100100100111"},{"D","110101101101110"},
            {"E","111100111100111"},{"F","111100111100100"},{"G","111100101101111"},{"H","101101111101101"},
            {"I","111010010010111"},{"J","001001001101111"},{"K","101101110101101"},{"L","100100100100111"},
            {"M","101111111101101"},{"N","111101101101101"},{"O","111101101101111"},{"P","111101111100100"},
            {"Q","111101101111001"},{"R","111101110101101"},{"S","111100111001111"},{"T","111010010010010"},
            {"U","101101101101111"},{"V","101101101101010"},{"W","101101111111101"},{"X","101101010101101"},
            {"Y","101101010010010"},{"Z","111001010100111"}
        };
        for (String[] e : f) FONT[e[0].charAt(0)] = e[1];
    }

    public Pix(int w, int h) { this.w = w; this.h = h; this.px = new int[w * h]; }

    public void set(int x, int y, int c) { if (x >= 0 && y >= 0 && x < w && y < h) px[y * w + x] = c; }

    public int get(int x, int y) { return (x >= 0 && y >= 0 && x < w && y < h) ? px[y * w + x] : 0; }

    public void fill(int c) { for (int i = 0; i < px.length; i++) px[i] = c; }

    public static int lerp(int a, int b, float t) {
        t = Math.max(0f, Math.min(1f, t));
        int r = (int) (((a >> 16) & 255) * (1 - t) + ((b >> 16) & 255) * t);
        int g = (int) (((a >> 8) & 255) * (1 - t) + ((b >> 8) & 255) * t);
        int bl = (int) ((a & 255) * (1 - t) + (b & 255) * t);
        return 0xFF000000 | (r << 16) | (g << 8) | bl;
    }

    public void vgrad(int c1, int c2) {
        for (int y = 0; y < h; y++) { int c = lerp(c1, c2, y / (float) (h - 1)); for (int x = 0; x < w; x++) set(x, y, c); }
    }

    public void rect(int x, int y, int rw, int rh, int c) {
        for (int j = 0; j < rh; j++) for (int i = 0; i < rw; i++) set(x + i, y + j, c);
    }

    public int textWidth(String s, int scale) { return s.length() * 4 * scale - scale; }

    public void text(String s, int x, int y, int c, int scale) {
        for (int i = 0; i < s.length(); i++) {
            String g = FONT[Math.min(127, s.charAt(i))];
            if (g != null)
                for (int r = 0; r < 5; r++)
                    for (int col = 0; col < 3; col++)
                        if (g.charAt(r * 3 + col) == '1') rect(x + (i * 4 + col) * scale, y + r * scale, scale, scale, c);
        }
    }

    public void textCentered(String s, int y, int c, int scale) { text(s, (w - textWidth(s, scale)) / 2, y, c, scale); }

    public BufferedImage toImage(int scale) {
        BufferedImage img = new BufferedImage(w * scale, h * scale, BufferedImage.TYPE_INT_ARGB);
        for (int y = 0; y < h; y++)
            for (int x = 0; x < w; x++) {
                int c = px[y * w + x];
                for (int j = 0; j < scale; j++) for (int i = 0; i < scale; i++) img.setRGB(x * scale + i, y * scale + j, c);
            }
        return img;
    }
}
