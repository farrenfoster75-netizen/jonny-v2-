package com.jonny.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.gui.inventory.GuiContainerCreative;

/** Cursive gold "Jonny Client" logo drawn above the inventory. */
public class InvLogo {
    public static void draw(Object gui) {
        Minecraft mc = Minecraft.getMinecraft();
        ScaledResolution sr = new ScaledResolution(mc);
        int w = sr.getScaledWidth(), h = sr.getScaledHeight();
        int ySize = gui instanceof GuiContainerCreative ? 136 : 166;
        int top = (h - ySize) / 2;
        float size = 30f;
        String s = "Jonny Client";
        float tw = UI.cursiveWidth(s, size);
        float th = ModernFont.CURSIVE.height(size);
        float x = (w - tw) / 2f;
        float y = Math.max(3f, top - th - 4f);
        int gold = UI.accent();
        float[][] off = {{-1.6f, 0}, {1.6f, 0}, {0, -1.6f}, {0, 1.6f}, {-1.1f, -1.1f}, {1.1f, 1.1f}};
        for (float[] o : off) UI.cursive(s, x + o[0], y + o[1], size, UI.withAlpha(gold, 55), false);
        UI.cursive(s, x + 1.4f, y + 1.6f, size, 0xB0000000, false);
        UI.cursive(s, x, y, size, 0xFF000000 | gold, false);
        UI.cursive(s, x - 0.5f, y - 0.6f, size, UI.withAlpha(0xFFF4C0, 140), false);
        UI.rrect(Math.round(x), Math.round(y + th - 2), Math.round(tw), 2, 1, UI.withAlpha(gold, 190));
    }
}
