package com.jonny.client;

import java.io.*;
import java.util.Properties;

public class Config {
    public static final String[] PROFILE_NAMES = {"Default", "Bedwars", "Duels", "Max FPS"};
    public static int cullDistance = 64;
    public static int nametagDistance = 32;
    public static int renderDistance = 0;   // 0 = leave vanilla setting alone
    public static int entityScale = 75;     // percent of vanilla entity render distance
    public static int particleCap = 300;
    public static int tileDistance = 32;
    public static int particleDistance = 24;
    public static int armorDistance = 24;
    public static int adaptiveTarget = 144;
    public static int entityBudget = 70;
    public static int layerDistance = 24;
    public static int signDistance = 16;
    public static int timeValue = 6000;
    public static int crosshairStyle = 0;
    public static int accentIdx = 0;
    public static boolean modernFont = true;
    public static int capeIdx = 0, wingIdx = 0, bandanaIdx = 0, headIdx = 0;
    public static int profile = 0;
    private static File baseDir;

    private static int geti(Properties p, String k, int d) {
        try { return Integer.parseInt(p.getProperty(k, String.valueOf(d))); } catch (Exception e) { return d; }
    }

    private static boolean getb(Properties p, String k, boolean d) {
        return Boolean.parseBoolean(p.getProperty(k, String.valueOf(d)));
    }

    public static File profileFile(int i) {
        return new File(baseDir, i == 0 ? "jonnyclient.cfg" : "jonnyclient_p" + i + ".cfg");
    }

    private static File slotFile() { return new File(baseDir, "jonnyclient_slot.txt"); }

    /** Called once at startup with the main config path. */
    public static void load(File mainCfg) {
        baseDir = mainCfg.getParentFile();
        int slot = 0;
        try (BufferedReader r = new BufferedReader(new FileReader(slotFile()))) {
            slot = Math.max(0, Math.min(PROFILE_NAMES.length - 1, Integer.parseInt(r.readLine().trim())));
        } catch (Exception ignored) {}
        profile = slot;
        loadFrom(profileFile(profile));
    }

    /** Switch to another profile; a brand-new profile starts from your current settings. */
    public static void switchProfile(int i) {
        save();
        profile = Math.max(0, Math.min(PROFILE_NAMES.length - 1, i));
        try {
            baseDir.mkdirs();
            try (FileWriter w = new FileWriter(slotFile())) { w.write(String.valueOf(profile)); }
        } catch (Exception ignored) {}
        File f = profileFile(profile);
        if (f.exists()) loadFrom(f); else save();
    }

    private static void loadFrom(File f) {
        Properties p = new Properties();
        try (FileInputStream in = new FileInputStream(f)) {
            p.load(in);
        } catch (Exception ignored) { return; }
        for (Feature ft : Feature.values()) ft.enabled = getb(p, ft.name(), ft.def);
        cullDistance = geti(p, "cullDistance", 64);
        nametagDistance = geti(p, "nametagDistance", 32);
        renderDistance = geti(p, "renderDistance", 0);
        entityScale = geti(p, "entityScale", 75);
        particleCap = geti(p, "particleCap", 300);
        tileDistance = geti(p, "tileDistance", 32);
        particleDistance = geti(p, "particleDistance", 24);
        armorDistance = geti(p, "armorDistance", 24);
        adaptiveTarget = geti(p, "adaptiveTarget", 144);
        entityBudget = geti(p, "entityBudget", 70);
        layerDistance = geti(p, "layerDistance", 24);
        signDistance = geti(p, "signDistance", 16);
        timeValue = geti(p, "timeValue", 6000);
        crosshairStyle = geti(p, "crosshairStyle", 0);
        accentIdx = geti(p, "accentIdx", 0);
        modernFont = getb(p, "modernFont", true);
        capeIdx = geti(p, "capeIdx", 0);
        wingIdx = geti(p, "wingIdx", 0);
        bandanaIdx = geti(p, "bandanaIdx", 0);
        headIdx = geti(p, "headIdx", 0);
        for (HudMod m : HudMods.ALL) {
            String k = "hud." + m.id + ".";
            m.enabled = getb(p, k + "enabled", m.defEnabled);
            m.bg = getb(p, k + "bg", true);
            m.x = geti(p, k + "x", m.defX);
            m.y = geti(p, k + "y", m.defY);
            m.scale = Math.max(50, Math.min(200, geti(p, k + "scale", 100)));
        }
    }

    public static void save() {
        if (baseDir == null) return;
        Properties p = new Properties();
        for (Feature ft : Feature.values()) p.setProperty(ft.name(), String.valueOf(ft.enabled));
        p.setProperty("cullDistance", String.valueOf(cullDistance));
        p.setProperty("nametagDistance", String.valueOf(nametagDistance));
        p.setProperty("renderDistance", String.valueOf(renderDistance));
        p.setProperty("entityScale", String.valueOf(entityScale));
        p.setProperty("particleCap", String.valueOf(particleCap));
        p.setProperty("tileDistance", String.valueOf(tileDistance));
        p.setProperty("particleDistance", String.valueOf(particleDistance));
        p.setProperty("armorDistance", String.valueOf(armorDistance));
        p.setProperty("adaptiveTarget", String.valueOf(adaptiveTarget));
        p.setProperty("entityBudget", String.valueOf(entityBudget));
        p.setProperty("layerDistance", String.valueOf(layerDistance));
        p.setProperty("signDistance", String.valueOf(signDistance));
        p.setProperty("timeValue", String.valueOf(timeValue));
        p.setProperty("crosshairStyle", String.valueOf(crosshairStyle));
        p.setProperty("accentIdx", String.valueOf(accentIdx));
        p.setProperty("modernFont", String.valueOf(modernFont));
        p.setProperty("capeIdx", String.valueOf(capeIdx));
        p.setProperty("wingIdx", String.valueOf(wingIdx));
        p.setProperty("bandanaIdx", String.valueOf(bandanaIdx));
        p.setProperty("headIdx", String.valueOf(headIdx));
        for (HudMod m : HudMods.ALL) {
            String k = "hud." + m.id + ".";
            p.setProperty(k + "enabled", String.valueOf(m.enabled));
            p.setProperty(k + "bg", String.valueOf(m.bg));
            p.setProperty(k + "x", String.valueOf(m.x));
            p.setProperty(k + "y", String.valueOf(m.y));
            p.setProperty(k + "scale", String.valueOf(m.scale));
        }
        try {
            baseDir.mkdirs();
            try (FileOutputStream out = new FileOutputStream(profileFile(profile))) { p.store(out, "Jonny Client profile " + profile); }
        } catch (Exception ignored) {}
    }
}
