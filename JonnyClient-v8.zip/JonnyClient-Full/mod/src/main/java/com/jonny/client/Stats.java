package com.jonny.client;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/** Shared live stats used by HUD mods. */
public class Stats {
    private static final List<Long> LEFT = new ArrayList<Long>();
    private static final List<Long> RIGHT = new ArrayList<Long>();
    public static int combo;
    public static double reach;
    public static long lastHit;
    public static double speed;
    public static float partial;

    private static final long[] FRAMES = new long[300];
    private static int frameCount = 0, frameHead = 0;
    private static long lastFrame = 0, lastCalc = 0;
    private static double avgFps = 0, lowFps = 0, avgMs = 0;

    /** Call once per rendered frame. */
    public static void frame() {
        long now = System.nanoTime();
        if (lastFrame != 0) {
            FRAMES[frameHead] = now - lastFrame;
            frameHead = (frameHead + 1) % FRAMES.length;
            if (frameCount < FRAMES.length) frameCount++;
        }
        lastFrame = now;
        if (now - lastCalc > 500_000_000L && frameCount > 20) { lastCalc = now; recalc(); }
    }

    private static void recalc() {
        long[] copy = new long[frameCount];
        long sum = 0;
        for (int i = 0; i < frameCount; i++) { copy[i] = FRAMES[i]; sum += copy[i]; }
        java.util.Arrays.sort(copy);
        avgMs = sum / (double) frameCount / 1_000_000.0;
        avgFps = 1000.0 / avgMs;
        int worst = Math.max(1, frameCount / 100);
        long ws = 0;
        for (int i = frameCount - worst; i < frameCount; i++) ws += copy[i];
        lowFps = 1_000_000_000.0 / (ws / (double) worst);
    }

    public static double avgFps() { return avgFps; }
    public static double lowFps() { return lowFps; }
    public static double avgMs() { return avgMs; }

    public static void click(int button) {
        if (button == 0) LEFT.add(System.currentTimeMillis());
        else if (button == 1) RIGHT.add(System.currentTimeMillis());
    }

    private static int count(List<Long> l) {
        long now = System.currentTimeMillis();
        Iterator<Long> it = l.iterator();
        while (it.hasNext()) if (now - it.next() > 1000) it.remove();
        return l.size();
    }

    public static int left() { return count(LEFT); }
    public static int right() { return count(RIGHT); }
}
