package com.jonny.client.mixins;

import com.jonny.client.CosmeticRenderer;
import net.minecraft.client.entity.AbstractClientPlayer;
import net.minecraft.client.renderer.entity.RenderPlayer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Draws cosmetics after the player model, in the world and in the inventory preview. */
@Mixin(RenderPlayer.class)
public class MixinRenderPlayer {
    @Inject(method = "doRender(Lnet/minecraft/client/entity/AbstractClientPlayer;DDDFF)V", at = @At("TAIL"), require = 0)
    private void jonny$cosmetics(AbstractClientPlayer p, double x, double y, double z, float yaw, float pt, CallbackInfo ci) {
        CosmeticRenderer.render(p, x, y, z, pt);
    }
}
