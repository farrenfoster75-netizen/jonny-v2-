package com.jonny.client;

public class HeadItems {
    public static final String[] NAMES = {"None", "Gold Crown", "Halo", "Shades", "Headphones", "Cat Ears", "Devil Horns", "Top Hat", "Party Hat"};
    public static final String[] ABBR = {"-", "CRN", "HLO", "SHD", "HP", "EAR", "HRN", "HAT", "PTY"};
}
