package com.jonny.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.util.ResourceLocation;

import java.awt.Graphics2D;
import java.awt.image.BufferedImage;

/** 50 pixel-art Jonny capes, painted at runtime as HD (8x) cape textures. */
public class CapeTextures {
    private static final Object[][] DEFS = {
        // name, design, c1, c2, c3, text lines (for TEXT), scale
        {"No cape", -1, 0, 0, 0, null, 1},
        {"Jonny", CosmeticArt.TEXT, 0x1B2A6B, 0x6B3DD9, 0xFFFFFF, new String[]{"JONNY"}, 1},
        {"Geeked", CosmeticArt.TEXT, 0x0E5A4A, 0x2FD6A0, 0xFFFFFF, new String[]{"GEE", "KED"}, 2},
        {"Kai is Zesty", CosmeticArt.TEXT, 0xD9306E, 0xFF9A3D, 0xFFFFFF, new String[]{"KAI", "IS", "ZESTY"}, 1},
        {"GG", CosmeticArt.TEXT, 0x111111, 0xFFC933, 0xFFC933, new String[]{"GG"}, 3},
        {"VX", CosmeticArt.TEXT, 0x2B0A55, 0xF2B632, 0xF2B632, new String[]{"VX"}, 3},
        {"FPS", CosmeticArt.TEXT, 0x001F3F, 0x00E5FF, 0x00E5FF, new String[]{"FPS"}, 1},
        {"Clutch", CosmeticArt.TEXT, 0x3A0000, 0xFF3B3B, 0xFFFFFF, new String[]{"CLU", "TCH"}, 2},
        {"Bedwars", CosmeticArt.TEXT, 0x1D2B53, 0x4DA3FF, 0xFFFFFF, new String[]{"BED", "WARS"}, 1},
        {"Galaxy", CosmeticArt.STARS, 0x0F0C29, 0x5B1FA8, 0xFFFFFF, null, 1},
        {"Nebula", CosmeticArt.STARS, 0x2A0845, 0xC2349A, 0xFFB3F5, null, 1},
        {"Midnight Stars", CosmeticArt.STARS, 0x050A1F, 0x1E3C72, 0xBFD9FF, null, 1},
        {"Sunset Stripes", CosmeticArt.STRIPES, 0xFF5E62, 0xFF9966, 0xFFE29A, null, 1},
        {"Ocean Waves", CosmeticArt.WAVES, 0x0072FF, 0x00C6FF, 0xFFFFFF, null, 1},
        {"Mint Waves", CosmeticArt.WAVES, 0x1FA2A6, 0xA8FFCE, 0xFFFFFF, null, 1},
        {"Lava Flames", CosmeticArt.FLAMES, 0x2B0000, 0xFF4500, 0xFFD000, null, 1},
        {"Ice Flames", CosmeticArt.FLAMES, 0x001133, 0x1E90FF, 0xBFF3FF, null, 1},
        {"Inferno", CosmeticArt.FLAMES, 0x330000, 0xCC1100, 0xFF8800, null, 1},
        {"Toxic Zigzag", CosmeticArt.ZIGZAG, 0x0B3D0B, 0x1A8F1A, 0x9CFF3A, null, 1},
        {"Matrix Rain", CosmeticArt.RAIN, 0x000000, 0x006B1B, 0x00FF41, null, 1},
        {"Neon Grid", CosmeticArt.GRID, 0x0A0A14, 0x0A0A14, 0x00F0FF, null, 1},
        {"Checker B&W", CosmeticArt.CHECK, 0x111111, 0xF2F2F2, 0xFFFFFF, null, 1},
        {"Checker Red", CosmeticArt.CHECK, 0x1A0000, 0xE01B24, 0xFFFFFF, null, 1},
        {"Pink Hearts", CosmeticArt.HEARTS, 0xFF758C, 0xFF9EB5, 0xFFFFFF, null, 1},
        {"Red Hearts", CosmeticArt.HEARTS, 0x5A0A14, 0x9B1B2B, 0xFF5C6C, null, 1},
        {"Skull", CosmeticArt.SKULL, 0x0A0A0F, 0x1E1E2A, 0xF2F2F2, null, 1},
        {"Creeper", CosmeticArt.CREEPER, 0x2E7D32, 0x66BB6A, 0x0A0A0A, null, 1},
        {"Lightning", CosmeticArt.BOLT, 0x081338, 0x1E3C8C, 0xFFE94D, null, 1},
        {"Crown", CosmeticArt.CROWN, 0x2E0854, 0x6A1FB0, 0xFFC933, null, 1},
        {"Pixel Sun", CosmeticArt.SUN, 0x2B6CB0, 0xFFB347, 0xFFE066, null, 1},
        {"Rainbow", CosmeticArt.RAINBOW, 0, 0, 0, null, 1},
        {"Camo", CosmeticArt.CAMO, 0x3B4A2B, 0x6B7F3A, 0x2A331E, null, 1},
        {"Tiger", CosmeticArt.TIGER, 0xE98A15, 0x1A1208, 0xFFFFFF, null, 1},
        {"Diamond Grid", CosmeticArt.DIAMONDS, 0x0B2A5B, 0x1F6FD1, 0x8CC4FF, null, 1},
        {"Gold Diamonds", CosmeticArt.DIAMONDS, 0x4A3200, 0xC9951A, 0xFFE08A, null, 1},
        {"Emerald", CosmeticArt.DIAMONDS, 0x053B1F, 0x10A050, 0x7DFFB3, null, 1},
        {"Ruby", CosmeticArt.DIAMONDS, 0x3B0610, 0xC0182E, 0xFF8A98, null, 1},
        {"Amethyst", CosmeticArt.DIAMONDS, 0x2A0845, 0x8B3FD1, 0xE0B3FF, null, 1},
        {"Candy", CosmeticArt.DIAG, 0xFF9A9E, 0xFECFEF, 0xFFFFFF, null, 1},
        {"Royal", CosmeticArt.ZIGZAG, 0x1B0F4A, 0x4B2BB0, 0xF2B632, null, 1},
        {"Snowfall", CosmeticArt.SNOW, 0x1B3A6B, 0x6FA8DC, 0xFFFFFF, null, 1},
        {"Slime", CosmeticArt.DOTS, 0x1B5E20, 0x43A047, 0xB9F6CA, null, 1},
        {"Honey", CosmeticArt.DOTS, 0x5A3A00, 0xFFB300, 0xFFE082, null, 1},
        {"Cherry Blossom", CosmeticArt.PETALS, 0x6B1B3A, 0xFFB7D5, 0xFFFFFF, null, 1},
        {"Aurora", CosmeticArt.AURORA, 0x050A2A, 0x0B6B5A, 0x7BFFB0, null, 1},
        {"Obsidian", CosmeticArt.CRACKS, 0x07040D, 0x1A0F2B, 0xA855F7, null, 1},
        {"Magma", CosmeticArt.CRACKS, 0x120805, 0x2A1208, 0xFF6A1A, null, 1},
        {"Cosmic", CosmeticArt.RINGS, 0x14002B, 0x5B00B5, 0xFF79C6, null, 1},
        {"Void", CosmeticArt.STARS, 0x000000, 0x12001F, 0xB46BFF, null, 1},
        {"Cotton Candy", CosmeticArt.WAVES, 0xFF9AD5, 0x9AD5FF, 0xFFFFFF, null, 1},
        {"Gold Rush", CosmeticArt.STRIPES, 0x6B4A00, 0xF2B632, 0xFFF0B3, null, 1},
    };

    public static final String[] NAMES = new String[DEFS.length];
    static { for (int i = 0; i < DEFS.length; i++) NAMES[i] = (String) DEFS[i][0]; }

    private static final ResourceLocation[] LOCS = new ResourceLocation[DEFS.length];
    public static int budget = 3;   // preview textures allowed to be generated this frame

    public static final int S = 8;
    // outer face of the cape on a 64x32 layout: x 1..11, y 1..17
    public static final float U0 = 1f / 64f, U1 = 11f / 64f, V0 = 1f / 32f, V1 = 17f / 32f;

    /** Used when actually wearing a cape. */
    public static ResourceLocation get(int idx) {
        if (idx <= 0 || idx >= DEFS.length) return null;
        if (LOCS[idx] == null) LOCS[idx] = make(idx);
        return LOCS[idx];
    }

    /** Used for menu previews; generates only a few per frame to avoid hitches. */
    public static ResourceLocation preview(int idx) {
        if (idx <= 0 || idx >= DEFS.length) return null;
        if (LOCS[idx] == null) {
            if (budget <= 0) return null;
            budget--;
            LOCS[idx] = make(idx);
        }
        return LOCS[idx];
    }

    private static ResourceLocation make(int idx) {
        Object[] d = DEFS[idx];
        int design = (Integer) d[1], c1 = (Integer) d[2], c2 = (Integer) d[3], c3 = (Integer) d[4];
        String[] lines = (String[]) d[5];
        int scale = (Integer) d[6];

        Pix face = new Pix(20, 32);
        CosmeticArt.paint(face, design == CosmeticArt.TEXT ? CosmeticArt.DIAG : design, c1, c2, c3, 1000L + idx);
        if (design == CosmeticArt.TEXT) {
            face.vgrad(0xFF000000 | c1, 0xFF000000 | c2);
            // pixel border
            for (int x = 0; x < 20; x++) { face.set(x, 0, 0x66FFFFFF); face.set(x, 31, 0x66FFFFFF); }
            for (int y = 0; y < 32; y++) { face.set(0, y, 0x66FFFFFF); face.set(19, y, 0x66FFFFFF); }
            int lineH = 5 * scale, gap = 2 * scale;
            int total = lines.length * lineH + (lines.length - 1) * gap;
            int y = (32 - total) / 2;
            for (String ln : lines) {
                face.textCentered(ln, y + 1, 0xFF000000 | 0x000000 | 0x202020, scale);
                face.textCentered(ln, y, 0xFF000000 | c3, scale);
                y += lineH + gap;
            }
        }

        int w = 64 * S, h = 32 * S;
        BufferedImage img = new BufferedImage(w, h, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g = img.createGraphics();
        // whole texture: dark base from the palette so cape edges match
        g.setColor(new java.awt.Color(Pix.lerp(0xFF000000 | c1, 0xFF000000, .35f), true));
        g.fillRect(0, 0, w, h);
        // outer face (x 1..11, y 1..17) = 10x16 cape pixels; our grid is 20x32, so each grid cell = 4 texels
        BufferedImage faceImg = face.toImage(4);
        g.drawImage(faceImg, 1 * S, 1 * S, null);
        // inner face (x 12..22): darker copy
        g.setColor(new java.awt.Color(0, 0, 0, 90));
        g.drawImage(faceImg, 12 * S, 1 * S, null);
        g.fillRect(12 * S, 1 * S, 10 * S, 16 * S);
        g.dispose();
        return Minecraft.getMinecraft().getTextureManager().getDynamicTextureLocation("jonny_cape_" + idx, new DynamicTexture(img));
    }
}
