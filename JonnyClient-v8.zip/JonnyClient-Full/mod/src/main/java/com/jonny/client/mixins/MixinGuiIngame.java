package com.jonny.client.mixins;

import com.jonny.client.Feature;
import net.minecraft.client.gui.GuiIngame;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(GuiIngame.class)
public class MixinGuiIngame {
    @Inject(method = "renderVignette", at = @At("HEAD"), cancellable = true, require = 0)
    private void jonny$noVignette(CallbackInfo ci) {
        if (Feature.NO_VIGNETTE.enabled) ci.cancel();
    }

    @Inject(method = "renderScoreboard", at = @At("HEAD"), cancellable = true, require = 0)
    private void jonny$noScoreboard(CallbackInfo ci) {
        if (Feature.NO_SCOREBOARD.enabled) ci.cancel();
    }
}
