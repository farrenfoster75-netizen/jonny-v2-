package com.jonny.client;

/** Menu color themes. */
public class Theme {
    public static final String[] NAMES = {"Gold", "Midnight", "Royal", "Emerald", "Crimson", "Rose", "Ice", "Mono"};
    public static final int[] ACCENT = {0xF2B632, 0x4DA3FF, 0xA66BFF, 0x3DDC84, 0xFF4D5E, 0xFF6BC1, 0x7FE7FF, 0xE6E6E6};
    public static final int[] BG = {0x0B0905, 0x070B14, 0x0C0814, 0x06100B, 0x120709, 0x140A10, 0x07121A, 0x0B0B0B};
    public static final int[] PANEL = {0x16120A, 0x0E1424, 0x151024, 0x0C1C14, 0x1E0D11, 0x201019, 0x0C1E2A, 0x161616};
    public static final int[] CARD = {0x1E190D, 0x131C30, 0x1D1632, 0x12271B, 0x2A1217, 0x2C1622, 0x112A3A, 0x1F1F1F};
    public static final int[] CARD_H = {0x30270F, 0x1D2B4A, 0x2C2250, 0x1B3B28, 0x40191F, 0x43212F, 0x193F55, 0x2E2E2E};

    public static int idx() { return Math.floorMod(Config.themeIdx, NAMES.length); }
    public static int accent() { return ACCENT[idx()]; }
    public static int bg() { return BG[idx()]; }
    public static int panel() { return PANEL[idx()]; }
    public static int card() { return CARD[idx()]; }
    public static int cardH() { return CARD_H[idx()]; }
    public static int dark() { return 0x050505; }
}
