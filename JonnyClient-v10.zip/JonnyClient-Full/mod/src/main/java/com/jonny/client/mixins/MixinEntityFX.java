package com.jonny.client.mixins;

import com.jonny.client.Config;
import com.jonny.client.Feature;
import net.minecraft.client.particle.EntityFX;
import net.minecraft.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(EntityFX.class)
public class MixinEntityFX {
    @Inject(method = "renderParticle", at = @At("HEAD"), cancellable = true, require = 0)
    private void jonny$cullParticles(CallbackInfo ci) {
        if (!Feature.PARTICLE_DIST.enabled) return;
        net.minecraft.client.Minecraft mc = net.minecraft.client.Minecraft.getMinecraft();
        Entity viewer = mc.getRenderViewEntity();
        if (viewer == null) return;
        Entity self = (Entity) (Object) this;
        double max = Config.qd(Config.particleDistance);
        if (self.getDistanceSqToEntity(viewer) > max * max) ci.cancel();
    }
}
