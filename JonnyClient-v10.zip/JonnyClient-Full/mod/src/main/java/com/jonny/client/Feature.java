package com.jonny.client;

public enum Feature {
    // ---- PvP & utility ----
    TOGGLE_SPRINT(Category.PVP, "Toggle Sprint", "Auto-sprint while moving forward", true, false),
    BLOCK_HIT(Category.PVP, "1.7 Block Hit Animation", "Swing while blocking, like 1.7 (Mixin)", true, false),
    NO_HURTCAM(Category.PVP, "No Hurt Camera", "Removes the damage camera shake (Mixin)", false, false),
    CLEAR_CHAT(Category.PVP, "See-through Chat", "Makes the chat background transparent (Mixin)", false, false),
    CLEAR_GUI(Category.PVP, "See-through Inventory & Chests", "Translucent inventory, chests, crafting, furnace (Mixin)", false, false),
    NO_SCOREBOARD(Category.PVP, "Hide Scoreboard", "Removes the sidebar scoreboard (Mixin)", false, false),
    CHAT_TIMESTAMPS(Category.PVP, "Chat Timestamps", "Adds [HH:mm] to every chat message", false, false),
    NICK_HIDER(Category.PVP, "Nick Hider", "Replaces your username in chat with Jonny", false, false),
    TOGGLE_SNEAK(Category.PVP, "Toggle Sneak", "Tap a key to sneak (bind it in Controls)", false, false),
    FULLBRIGHT(Category.PVP, "Fullbright", "Maximum brightness everywhere", false, false),
    ZOOM(Category.PVP, "Zoom", "Hold C to zoom in", true, false),
    BLOCK_OUTLINE(Category.PVP, "Block Outline", "Colored outline using your accent color", true, false),
    CROSSHAIR(Category.PVP, "Custom Crosshair", "Replaces the vanilla crosshair", false, false),
    TIME_CHANGER(Category.PVP, "Time Changer", "Client-side time of day", false, false),
    HITBOXES(Category.PVP, "Show Hitboxes", "Entity hitboxes (costs FPS)", false, false),

    // ---- FPS boost ----
    ENTITY_CULLING(Category.FPS, "Entity Distance Culling", "Stop drawing far-away entities", true, false),
    ENTITY_SCALE(Category.FPS, "Short Entity Render Distance", "Items, arrows and mobs render closer", true, false),
    NAMETAG_CULLING(Category.FPS, "Nametag Culling", "Hide far-away nametags", true, false),
    PARTICLE_CAP(Category.FPS, "Particle Cap", "Hard limit on live particles", true, false),
    OCCLUSION_CULLING(Category.FPS, "Occlusion Culling (Beta)", "Skip entities hidden behind walls", false, false),
    ARMOR_STAND_CULL(Category.FPS, "Hide Armor Stands", "Also hides hologram text", false, false),
    TILE_CULLING(Category.FPS, "Tile Entity Culling", "Skip far chests, beds, banners, signs (Mixin)", true, false),
    PARTICLE_DIST(Category.FPS, "Particle Distance Culling", "Skip drawing far particles (Mixin)", true, false),
    NO_ANIM_TEXTURES(Category.FPS, "Freeze Animated Textures", "Water, lava and fire stop animating (Mixin)", false, false),
    NO_GLINT(Category.FPS, "Disable Enchant Glint", "Removes glint on armor and items (Mixin)", false, false),
    ADAPTIVE_RD(Category.FPS, "Adaptive Render Distance", "Raises/lowers chunks to hold your target FPS", false, false),
    PARTICLE_SPAWN(Category.FPS, "Particle Spawn Culling", "Never create far-away particles (Mixin)", true, false),
    NO_VIGNETTE(Category.FPS, "No Vignette", "Removes screen-edge darkening (Mixin)", false, false),
    ENTITY_BUDGET(Category.FPS, "Entity Render Budget", "Caps entities drawn per frame, far ones first", true, false),
    GOVERNOR(Category.FPS, "Smart FPS Governor", "Auto-lowers every distance and budget to hold your target FPS", true, false),
    NO_POTION_SWIRLS(Category.FPS, "Hide Potion Swirls", "Never creates potion effect particles (Mixin)", true, false),
    NO_CRITS(Category.FPS, "Hide Crit Particles", "Never creates crit particles (Mixin)", false, false),
    ITEM_LOD(Category.FPS, "Dropped Item Budget", "Cap and distance-limit dropped items (Mixin)", true, false),
    SOUND_CULL(Category.FPS, "Sound Culling", "Skips far-away positional sounds (Mixin)", true, false),
    LOD_SKIN(Category.FPS, "Far Skin Layers Off", "Hides jacket, sleeves, pants and hat layers on far players (Mixin)", true, false),
    TIGHT_FAR(Category.FPS, "Tight Far Plane", "Clips the farthest chunk corners (experimental, Mixin)", false, false),
    LAYER_CULL(Category.FPS, "Far Layer Culling", "Skip armor, held item and cape draws on far players (Mixin)", true, false),
    SIGN_CULL(Category.FPS, "Sign Culling", "Skip drawing far-away signs and their text (Mixin)", true, false),
    ARMOR_CULL(Category.FPS, "Far Armor Culling", "Skip armor layers on far players (Mixin)", true, false),
    NO_WEATHER(Category.FPS, "Disable Weather", "No rain or thunder", true, false),
    LOW_FIRE(Category.FPS, "Low Fire Overlay", "Removes the fire screen overlay", true, false),
    UNFOCUSED_LIMIT(Category.FPS, "Unfocused FPS Limit", "30 FPS while tabbed out", true, false),

    // ---- Graphics ----
    GFX_FAST(Category.GRAPHICS, "Fast Graphics", "Turns off fancy graphics", true, true),
    GFX_NO_CLOUDS(Category.GRAPHICS, "No Clouds", "Removes clouds", true, true),
    LOW_PARTICLES(Category.GRAPHICS, "Minimal Particles", "Fewer particles from the game", true, true),
    GFX_UNCAP(Category.GRAPHICS, "Uncap FPS / No VSync", "Removes the frame cap", true, true),
    GFX_VBO(Category.GRAPHICS, "VBO Chunk Renderer", "Can raise FPS on modern GPUs (reloads chunks)", false, true),
    GFX_NO_AO(Category.GRAPHICS, "Flat Lighting", "Turns off smooth lighting", false, true),
    GFX_NO_SHADOWS(Category.GRAPHICS, "No Entity Shadows", "Removes the blob shadows", false, true);

    public enum Category {
        PVP("PVP & UTILITY"), FPS("FPS BOOST"), GRAPHICS("GRAPHICS");
        public final String title;
        Category(String title) { this.title = title; }
    }

    public final Category category;
    public final String label;
    public final String desc;
    public final boolean def;
    public final boolean gfx;
    public boolean enabled;

    Feature(Category category, String label, String desc, boolean def, boolean gfx) {
        this.category = category;
        this.label = label;
        this.desc = desc;
        this.def = def;
        this.gfx = gfx;
        this.enabled = def;
    }
}
