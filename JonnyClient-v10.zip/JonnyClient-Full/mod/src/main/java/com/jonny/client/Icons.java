package com.jonny.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.util.ResourceLocation;

import java.awt.AlphaComposite;
import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Path2D;
import java.awt.geom.RoundRectangle2D;
import java.awt.image.BufferedImage;

/** Vector-style icons drawn at runtime into one atlas (4x4 cells of 64px). */
public class Icons {
    public static final int LIST = 0, BARS = 1, BULB = 2, BUBBLE = 3, BOLT = 4, SUN = 5, EYE = 6, CUBE = 7,
            CROSS = 8, CLOCK = 9, HEART = 10, SHIELD = 11, STAR = 12, GEAR = 13, BAT = 14, ARROWS = 15;
    private static ResourceLocation atlas;

    private static void poly(Graphics2D g, int ox, int oy, double... p) {
        Path2D.Double path = new Path2D.Double();
        path.moveTo(ox + p[0], oy + p[1]);
        for (int i = 2; i < p.length; i += 2) path.lineTo(ox + p[i], oy + p[i + 1]);
        path.closePath();
        g.fill(path);
    }

    private static void line(Graphics2D g, int ox, int oy, double x1, double y1, double x2, double y2) {
        g.draw(new java.awt.geom.Line2D.Double(ox + x1, oy + y1, ox + x2, oy + y2));
    }

    private static void init() {
        BufferedImage img = new BufferedImage(256, 256, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g = img.createGraphics();
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g.setRenderingHint(RenderingHints.KEY_STROKE_CONTROL, RenderingHints.VALUE_STROKE_PURE);
        g.setColor(Color.WHITE);
        g.setStroke(new BasicStroke(5f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
        for (int id = 0; id < 16; id++) {
            int ox = (id % 4) * 64, oy = (id / 4) * 64;
            switch (id) {
                case LIST:
                    for (int r = 0; r < 3; r++) {
                        g.fill(new RoundRectangle2D.Double(ox + 9, oy + 11 + r * 16, 11, 11, 4, 4));
                        g.fill(new RoundRectangle2D.Double(ox + 26, oy + 13 + r * 16, 29, 7, 4, 4));
                    }
                    break;
                case BARS:
                    g.fill(new RoundRectangle2D.Double(ox + 10, oy + 38, 12, 16, 4, 4));
                    g.fill(new RoundRectangle2D.Double(ox + 26, oy + 24, 12, 30, 4, 4));
                    g.fill(new RoundRectangle2D.Double(ox + 42, oy + 8, 12, 46, 4, 4));
                    break;
                case BULB:
                    g.fill(new Ellipse2D.Double(ox + 17, oy + 7, 30, 30));
                    g.fill(new RoundRectangle2D.Double(ox + 24, oy + 34, 16, 11, 5, 5));
                    g.fill(new RoundRectangle2D.Double(ox + 25, oy + 47, 14, 6, 3, 3));
                    break;
                case BUBBLE:
                    g.fill(new RoundRectangle2D.Double(ox + 6, oy + 9, 52, 34, 14, 14));
                    poly(g, ox, oy, 16, 40, 14, 56, 32, 42);
                    g.setComposite(AlphaComposite.Clear);
                    for (int i = 0; i < 3; i++) g.fill(new Ellipse2D.Double(ox + 18 + i * 12, oy + 22, 7, 7));
                    g.setComposite(AlphaComposite.SrcOver);
                    break;
                case BOLT: poly(g, ox, oy, 37, 4, 14, 36, 29, 36, 23, 60, 51, 25, 35, 25); break;
                case SUN:
                    g.fill(new Ellipse2D.Double(ox + 19, oy + 19, 26, 26));
                    for (int i = 0; i < 8; i++) {
                        double a = Math.PI * i / 4;
                        line(g, ox, oy, 32 + Math.cos(a) * 19, 32 + Math.sin(a) * 19, 32 + Math.cos(a) * 28, 32 + Math.sin(a) * 28);
                    }
                    break;
                case EYE:
                    g.fill(new Ellipse2D.Double(ox + 4, oy + 16, 56, 32));
                    g.setComposite(AlphaComposite.Clear);
                    g.fill(new Ellipse2D.Double(ox + 22, oy + 20, 20, 24));
                    g.setComposite(AlphaComposite.SrcOver);
                    g.fill(new Ellipse2D.Double(ox + 27, oy + 27, 10, 10));
                    break;
                case CUBE:
                    g.draw(new Path2D.Double() {{ moveTo(ox + 32, oy + 6); lineTo(ox + 56, oy + 19); lineTo(ox + 56, oy + 45); lineTo(ox + 32, oy + 58); lineTo(ox + 8, oy + 45); lineTo(ox + 8, oy + 19); closePath(); }});
                    line(g, ox, oy, 32, 32, 32, 58); line(g, ox, oy, 32, 32, 8, 19); line(g, ox, oy, 32, 32, 56, 19);
                    break;
                case CROSS:
                    g.draw(new Ellipse2D.Double(ox + 14, oy + 14, 36, 36));
                    line(g, ox, oy, 32, 4, 32, 20); line(g, ox, oy, 32, 44, 32, 60);
                    line(g, ox, oy, 4, 32, 20, 32); line(g, ox, oy, 44, 32, 60, 32);
                    g.fill(new Ellipse2D.Double(ox + 28, oy + 28, 8, 8));
                    break;
                case CLOCK:
                    g.draw(new Ellipse2D.Double(ox + 8, oy + 8, 48, 48));
                    line(g, ox, oy, 32, 32, 32, 16); line(g, ox, oy, 32, 32, 45, 39);
                    break;
                case HEART:
                    g.fill(new Ellipse2D.Double(ox + 6, oy + 10, 28, 28));
                    g.fill(new Ellipse2D.Double(ox + 30, oy + 10, 28, 28));
                    poly(g, ox, oy, 8, 30, 56, 30, 32, 58);
                    break;
                case SHIELD: poly(g, ox, oy, 32, 5, 55, 13, 53, 38, 32, 60, 11, 38, 9, 13); break;
                case STAR: {
                    double[] p = new double[20];
                    for (int i = 0; i < 10; i++) {
                        double a = -Math.PI / 2 + Math.PI * i / 5, r = i % 2 == 0 ? 28 : 12;
                        p[i * 2] = 32 + Math.cos(a) * r; p[i * 2 + 1] = 33 + Math.sin(a) * r;
                    }
                    poly(g, ox, oy, p);
                    break;
                }
                case GEAR:
                    g.draw(new Ellipse2D.Double(ox + 14, oy + 14, 36, 36));
                    for (int i = 0; i < 8; i++) {
                        double a = Math.PI * i / 4;
                        line(g, ox, oy, 32 + Math.cos(a) * 18, 32 + Math.sin(a) * 18, 32 + Math.cos(a) * 27, 32 + Math.sin(a) * 27);
                    }
                    g.fill(new Ellipse2D.Double(ox + 26, oy + 26, 12, 12));
                    break;
                case BAT: poly(g, ox, oy, 32, 22, 24, 10, 20, 24, 8, 16, 2, 20, 8, 38, 20, 44, 26, 36, 32, 46, 38, 36, 44, 44, 56, 38, 62, 20, 56, 16, 44, 24, 40, 10); break;
                default:
                    g.draw(new Path2D.Double() {{ moveTo(ox + 12, oy + 12); lineTo(ox + 30, oy + 32); lineTo(ox + 12, oy + 52); }});
                    g.draw(new Path2D.Double() {{ moveTo(ox + 34, oy + 12); lineTo(ox + 52, oy + 32); lineTo(ox + 34, oy + 52); }});
            }
        }
        g.dispose();
        atlas = Minecraft.getMinecraft().getTextureManager().getDynamicTextureLocation("jonny_icons", new DynamicTexture(img));
    }

    public static void draw(int id, float x, float y, float size, int argb) {
        if (atlas == null) init();
        float u = (id % 4) * 0.25f, v = (id / 4) * 0.25f;
        UI.drawTexTint(atlas, x, y, size, size, u, v, u + 0.25f, v + 0.25f, argb);
    }

    /** Picks an icon from the mod name / category. */
    public static int forName(String name, String cat) {
        String n = name.toLowerCase();
        if (n.contains("light") || n.contains("bright")) return BULB;
        if (n.contains("chat") || n.contains("nick") || n.contains("timestamp")) return BUBBLE;
        if (n.contains("sprint") || n.contains("sneak") || n.contains("speed")) return ARROWS;
        if (n.contains("clock") || n.contains("time") || n.contains("day")) return CLOCK;
        if (n.contains("health") || n.contains("hunger") || n.contains("heart") || n.contains("potion") || n.contains("pot ")) return HEART;
        if (n.contains("armor") || n.contains("scoreboard") || n.contains("shield")) return SHIELD;
        if (n.contains("zoom") || n.contains("crosshair") || n.contains("reach") || n.contains("combo") || n.contains("cps") || n.contains("hitbox") || n.contains("outline")) return CROSS;
        if (n.contains("particle") || n.contains("weather") || n.contains("cloud") || n.contains("vignette") || n.contains("shadow") || n.contains("fire")) return SUN;
        if (n.contains("entity") || n.contains("nametag") || n.contains("layer") || n.contains("sign") || n.contains("tile") || n.contains("cull") || n.contains("budget") || n.contains("skin")) return EYE;
        if (n.contains("texture") || n.contains("vbo") || n.contains("chunk") || n.contains("render") || n.contains("far plane") || n.contains("graphics")) return CUBE;
        if (n.contains("fps") || n.contains("frame") || n.contains("governor") || n.contains("adaptive")) return BOLT;
        if (n.contains("ping") || n.contains("memory") || n.contains("entities")) return BARS;
        if (n.contains("jonny")) return BAT;
        if (n.contains("sound")) return STAR;
        if ("HUD".equals(cat)) return LIST;
        if ("PVP".equals(cat)) return SHIELD;
        if ("FPS".equals(cat)) return BOLT;
        return SUN;
    }
}
