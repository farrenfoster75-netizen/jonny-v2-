package com.jonny.client;

public class HeadItems {
    public static final String[] NAMES = {"None", "Gold Crown", "Halo", "Shades", "Headphones", "Cat Ears", "Devil Horns", "Top Hat", "Party Hat", "Pink Bow", "Gold Bow", "Wizard Hat"};
    public static final String[] ABBR = {"-", "CRN", "HLO", "SHD", "HP", "EAR", "HRN", "HAT", "PTY", "BOW", "BWG", "WIZ"};
    public static final String[] PETS = {"None", "Mini Bat", "Slime", "Orb", "Goldfish"};
    public static final String[] PACKS = {"None", "Black Pack", "Gold Pack", "Camo Pack"};
}
