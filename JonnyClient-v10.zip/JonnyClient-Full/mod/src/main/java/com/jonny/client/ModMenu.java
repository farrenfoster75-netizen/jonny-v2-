package com.jonny.client;

import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.GuiScreenResourcePacks;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.util.ChatAllowedCharacters;
import net.minecraft.util.ResourceLocation;
import org.lwjgl.input.Keyboard;
import org.lwjgl.input.Mouse;
import org.lwjgl.opengl.GL11;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.BooleanSupplier;
import java.util.function.IntConsumer;
import java.util.function.IntSupplier;

/** Jonny Client vX menu: themed translucent card grid with icons, blur, profiles, cosmetics, option drawers. */
public class ModMenu extends GuiScreen {
    private enum Top {
        MODS("MODS"), COSMETICS("COSMETICS"), SETTINGS("SETTINGS");
        final String title;
        Top(String t) { title = t; }
    }

    private static final String[] MOD_CATS = {"ALL", "HUD", "PVP", "FPS", "GRAPHICS"};
    private static final String[] COS_CATS = {"CLOAKS", "CAPES", "WINGS", "BANDANAS", "HEAD", "PETS", "PACKS"};
    private static final int TEXT = 0xF7F0DE, SUB = 0xAA9E83;
    private static final int TOPH = 52;
    private static Top lastTop = Top.MODS;
    private static int lastModCat = 0, lastCosCat = 0;

    private Top top = lastTop;
    private int modCat = lastModCat, cosCat = lastCosCat;
    private String search = "";
    private boolean searchFocus;
    private float scrollPos, scrollTarget;
    private int maxScroll;
    private final long openTime = System.currentTimeMillis();
    private float alpha = 1f;
    private int px, py, pw, ph, sf, sh;
    private int leftX, leftY, leftW, leftH, mainX, mainW, gridX, gridY, gridW, gridH, chipY;
    private int hx, hy, hw, hh;
    private Item dragging;
    private int dragX, dragW;
    private Entry drawer;
    private String flash = "";
    private long flashUntil;
    private final Map<String, Float> anim = new HashMap<String, Float>();
    private final List<Entry> entries = new ArrayList<Entry>();
    private final List<Item> settingsItems = new ArrayList<Item>();

    // ------------------------------------------------------------ helpers
    private int BG() { return Theme.bg(); }
    private int PANEL() { return Theme.panel(); }
    private int CARD() { return Theme.card(); }
    private int CARDH() { return Theme.cardH(); }
    private int OFF() { return mix(Theme.cardH(), 0xFFFFFF, 0.14f); }
    private int gold() { return Theme.accent(); }
    private int c(int rgb, int a) { return (((int) (alpha * a)) << 24) | (rgb & 0xFFFFFF); }
    private void t(String s, float x, float y, float size, int rgb, boolean bold) { UI.text(s, x, y, size, c(rgb, 255), bold, false); }
    private void tc(String s, float cx, float y, float size, int rgb, boolean bold) { t(s, cx - UI.width(s, size, bold) / 2f, y, size, rgb, bold); }
    private float tw(String s, float size, boolean bold) { return UI.width(s, size, bold); }
    private static boolean in(int mx, int my, int x, int y, int w, int h) { return mx >= x && mx < x + w && my >= y && my < y + h; }
    private boolean hov(int mx, int my) { return in(mx, my, hx, hy, hw, hh); }
    private void setHover(int x, int y, int w, int h) { hx = x; hy = y; hw = w; hh = h; }
    private void flash(String s) { flash = s; flashUntil = System.currentTimeMillis() + 2200; }

    private static int mix(int c1, int c2, float f) {
        int r = (int) (((c1 >> 16) & 255) * (1 - f) + ((c2 >> 16) & 255) * f);
        int g = (int) (((c1 >> 8) & 255) * (1 - f) + ((c2 >> 8) & 255) * f);
        int b = (int) ((c1 & 255) * (1 - f) + (c2 & 255) * f);
        return (r << 16) | (g << 8) | b;
    }

    private float anim(String key, boolean on) {
        Float cur0 = anim.get(key);
        float cur = cur0 == null ? (on ? 1f : 0f) : cur0;
        float tgt = on ? 1f : 0f;
        cur += (tgt - cur) * 0.26f;
        if (Math.abs(tgt - cur) < 0.01f) cur = tgt;
        anim.put(key, cur);
        return cur;
    }

    private void scissor(int x, int y, int w, int h) { GL11.glScissor(x * sf, (sh - (y + h)) * sf, Math.max(0, w) * sf, Math.max(0, h) * sf); }

    private void drawSwitch(int x, int y, boolean on, String key) {
        float a = anim(key, on);
        UI.rrect(x, y, 32, 16, 8, c(mix(OFF(), gold(), a), 255));
        UI.rrect(x + 2 + Math.round(16 * a), y + 2, 12, 12, 6, c(mix(0xD8D0BC, 0xFFFFFF, a), 255));
    }

    private void drawTrack(int x, int y, int w, float frac) {
        frac = Math.max(0f, Math.min(1f, frac));
        int fw = (int) (w * frac);
        UI.rrect(x, y, w, 4, 2, c(OFF(), 255));
        UI.rrect(x, y, Math.max(fw, 4), 4, 2, c(gold(), 255));
        UI.rrect(x + fw - 5, y - 3, 10, 10, 5, c(0xFFFFFF, 255));
    }

    private static String abbr(String name) {
        String[] w = name.replace("&", " ").trim().split("\\s+");
        StringBuilder sb = new StringBuilder();
        if (w.length > 1) { for (String s : w) if (!s.isEmpty() && sb.length() < 3) sb.append(Character.toUpperCase(s.charAt(0))); }
        else sb.append(name.substring(0, Math.min(3, name.length())).toUpperCase());
        return sb.toString();
    }

    // ------------------------------------------------------------ option rows (drawer + settings)
    private abstract class Item {
        abstract int step();
        abstract void draw(int x, int y, int w, int mx, int my);
        void click(int x, int y, int w, int mx, int my) {}
        void drag(int mx) {}
    }

    private class BoolRow extends Item {
        final String key, label, desc; final BooleanSupplier get; final Runnable flip;
        BoolRow(String key, String label, String desc, BooleanSupplier get, Runnable flip) { this.key = key; this.label = label; this.desc = desc; this.get = get; this.flip = flip; }
        int step() { return 38; }
        void draw(int x, int y, int w, int mx, int my) {
            float a = anim("hv:" + key, hov(mx, my) && in(mx, my, x, y, w, 34));
            UI.rrect(x, y, w, 34, 8, c(mix(CARD(), CARDH(), a), 200));
            t(label, x + 14, y + 5, 10f, TEXT, true);
            t(desc, x + 14, y + 19, 8f, SUB, false);
            drawSwitch(x + w - 46, y + 9, get.getAsBoolean(), key);
        }
        void click(int x, int y, int w, int mx, int my) { flip.run(); Config.save(); }
    }

    private class SliderRow extends Item {
        final String label, suffix; final int min, max; final IntSupplier get; final IntConsumer set;
        SliderRow(String label, String suffix, int min, int max, IntSupplier get, IntConsumer set) { this.label = label; this.suffix = suffix; this.min = min; this.max = max; this.get = get; this.set = set; }
        int step() { return 44; }
        void draw(int x, int y, int w, int mx, int my) {
            UI.rrect(x, y, w, 40, 8, c(CARD(), 200));
            t(label, x + 14, y + 6, 10f, TEXT, true);
            String v = get.getAsInt() + suffix;
            t(v, x + w - 14 - tw(v, 10f, true), y + 6, 10f, gold(), true);
            drawTrack(x + 14, y + 28, w - 28, (get.getAsInt() - min) / (float) (max - min));
        }
        void click(int x, int y, int w, int mx, int my) { dragging = this; dragX = x; dragW = w; drag(mx); }
        void drag(int mx) {
            float p = (mx - (dragX + 14)) / (float) (dragW - 28);
            p = Math.max(0f, Math.min(1f, p));
            set.accept(Math.round(min + p * (max - min)));
        }
    }

    private class BtnRow extends Item {
        final java.util.function.Supplier<String> label; final Runnable action;
        BtnRow(java.util.function.Supplier<String> label, Runnable action) { this.label = label; this.action = action; }
        int step() { return 34; }
        void draw(int x, int y, int w, int mx, int my) {
            String s = label.get();
            float a = anim("hb:" + s, hov(mx, my) && in(mx, my, x, y, w, 30));
            UI.rrect(x, y, w, 30, 8, c(gold(), 110 + (int) (110 * a)));
            UI.rrect(x + 1, y + 1, w - 2, 28, 7, c(mix(CARD(), CARDH(), a), 240));
            tc(s, x + w / 2f, y + 8, 10f, gold(), true);
        }
        void click(int x, int y, int w, int mx, int my) { action.run(); Config.save(); }
    }

    private class ThemeRow extends Item {
        int step() { return 62; }
        void draw(int x, int y, int w, int mx, int my) {
            UI.rrect(x, y, w, 58, 8, c(CARD(), 200));
            t("Theme  -  " + Theme.NAMES[Theme.idx()], x + 14, y + 6, 10f, TEXT, true);
            int n = Theme.NAMES.length, gap = Math.min(40, (w - 28) / n);
            for (int i = 0; i < n; i++) {
                int cx = x + 14 + i * gap + 12, cy = y + 40;
                boolean sel = i == Theme.idx();
                float a = anim("th:" + i, sel || (hov(mx, my) && in(mx, my, cx - 12, cy - 12, 24, 24)));
                if (sel) UI.rrect(cx - 14, cy - 14, 28, 28, 14, c(0xFFFFFF, 230));
                UI.rrect(cx - 11 - (int) (a * 1), cy - 11, 22, 22, 11, c(Theme.ACCENT[i], 255));
            }
        }
        void click(int x, int y, int w, int mx, int my) {
            int n = Theme.NAMES.length, gap = Math.min(40, (w - 28) / n);
            for (int i = 0; i < n; i++) if (in(mx, my, x + 14 + i * gap, y + 26, 24, 28)) { Config.themeIdx = i; Config.save(); return; }
        }
    }

    // ------------------------------------------------------------ entries (mods)
    private class Entry {
        final String name, desc, cat; final int icon; final BooleanSupplier on; final Runnable toggle; final List<Item> opts = new ArrayList<Item>();
        Entry(String name, String desc, String cat, BooleanSupplier on, Runnable toggle) {
            this.name = name; this.desc = desc; this.cat = cat; this.icon = Icons.forName(name, cat); this.on = on; this.toggle = toggle;
        }
    }

    private void toggleFeature(Feature f) {
        f.enabled = !f.enabled;
        if (f.gfx) GfxTuner.apply();
        if (f == Feature.ENTITY_SCALE) Events.refreshEntityWeights();
        Config.save();
    }

    private void buildEntries() {
        for (HudMod m : HudMods.ALL) {
            final HudMod mm = m;
            Entry e = new Entry(m.name, m.desc, "HUD", () -> mm.enabled, () -> { mm.enabled = !mm.enabled; Config.save(); });
            e.opts.add(new SliderRow("Scale", "%", 50, 200, () -> mm.scale, v -> mm.scale = 5 * Math.round(v / 5f)));
            e.opts.add(new BoolRow("hb:" + m.id, "Background", "Draw a box behind this element", () -> mm.bg, () -> mm.bg = !mm.bg));
            entries.add(e);
        }
        for (Feature f : Feature.values()) {
            final Feature ff = f;
            String cat = f.category == Feature.Category.PVP ? "PVP" : (f.category == Feature.Category.FPS ? "FPS" : "GRAPHICS");
            Entry e = new Entry(f.label, f.desc, cat, () -> ff.enabled, () -> toggleFeature(ff));
            switch (f) {
                case ENTITY_CULLING: e.opts.add(new SliderRow("Cull distance", "", 16, 128, () -> Config.cullDistance, v -> Config.cullDistance = v)); break;
                case ENTITY_SCALE: e.opts.add(new SliderRow("Entity render distance", "%", 25, 100, () -> Config.entityScale, v -> { Config.entityScale = v; Events.refreshEntityWeights(); })); break;
                case NAMETAG_CULLING: e.opts.add(new SliderRow("Nametag distance", "", 8, 64, () -> Config.nametagDistance, v -> Config.nametagDistance = v)); break;
                case TILE_CULLING: e.opts.add(new SliderRow("Tile entity distance", "", 8, 64, () -> Config.tileDistance, v -> Config.tileDistance = v)); break;
                case PARTICLE_DIST: case PARTICLE_SPAWN: e.opts.add(new SliderRow("Particle distance", "", 8, 64, () -> Config.particleDistance, v -> Config.particleDistance = v)); break;
                case PARTICLE_CAP: e.opts.add(new SliderRow("Particle cap", "", 50, 1000, () -> Config.particleCap, v -> Config.particleCap = v)); break;
                case ARMOR_CULL: e.opts.add(new SliderRow("Armor draw distance", "", 8, 64, () -> Config.armorDistance, v -> Config.armorDistance = v)); break;
                case LAYER_CULL: case LOD_SKIN: e.opts.add(new SliderRow("Layer draw distance", "", 8, 64, () -> Config.layerDistance, v -> Config.layerDistance = v)); break;
                case SIGN_CULL: e.opts.add(new SliderRow("Sign draw distance", "", 6, 48, () -> Config.signDistance, v -> Config.signDistance = v)); break;
                case ENTITY_BUDGET: e.opts.add(new SliderRow("Entities per frame", "", 20, 250, () -> Config.entityBudget, v -> Config.entityBudget = v)); break;
                case ITEM_LOD:
                    e.opts.add(new SliderRow("Item distance", "", 6, 64, () -> Config.itemDistance, v -> Config.itemDistance = v));
                    e.opts.add(new SliderRow("Items per frame", "", 5, 200, () -> Config.itemBudget, v -> Config.itemBudget = v));
                    break;
                case SOUND_CULL: e.opts.add(new SliderRow("Sound distance", "", 8, 96, () -> Config.soundDistance, v -> Config.soundDistance = v)); break;
                case GOVERNOR: e.opts.add(new SliderRow("Target FPS", "", 60, 360, () -> Config.adaptiveTarget, v -> Config.adaptiveTarget = v)); break;
                case ADAPTIVE_RD:
                    e.opts.add(new SliderRow("Target FPS", "", 60, 360, () -> Config.adaptiveTarget, v -> Config.adaptiveTarget = v));
                    e.opts.add(new SliderRow("Max render distance", "", 2, 16, () -> mc.gameSettings.renderDistanceChunks, v -> { Config.renderDistance = v; GfxTuner.apply(); }));
                    break;
                case TIME_CHANGER: e.opts.add(new SliderRow("Time of day", "", 0, 24000, () -> Config.timeValue, v -> Config.timeValue = v)); break;
                case CLEAR_CHAT: e.opts.add(new SliderRow("Chat background", "%", 0, 100, () -> Config.chatBg, v -> Config.chatBg = v)); break;
                case CLEAR_GUI:
                    e.opts.add(new SliderRow("Window opacity", "%", 20, 100, () -> Config.guiAlpha, v -> Config.guiAlpha = v));
                    e.opts.add(new SliderRow("Background dimming", "%", 0, 100, () -> Config.guiDim, v -> Config.guiDim = v));
                    break;
                case CROSSHAIR: e.opts.add(new BtnRow(() -> "Style: " + new String[]{"Cross", "Dot", "Plus"}[Math.floorMod(Config.crosshairStyle, 3)], () -> Config.crosshairStyle = (Config.crosshairStyle + 1) % 3)); break;
                default: break;
            }
            entries.add(e);
        }
    }

    private List<Entry> visMods() {
        List<Entry> l = new ArrayList<Entry>();
        String q = search.toLowerCase();
        for (Entry e : entries) {
            if (modCat != 0 && !e.cat.equals(MOD_CATS[modCat])) continue;
            if (!q.isEmpty() && !e.name.toLowerCase().contains(q)) continue;
            l.add(e);
        }
        return l;
    }

    // ------------------------------------------------------------ cosmetics
    private String[] cosNames(int cat) {
        switch (cat) {
            case 0: return CloakTextures.NAMES;
            case 1: return CapeTextures.NAMES;
            case 2: return WingTextures.NAMES;
            case 3: return BandanaTextures.NAMES;
            case 4: return HeadItems.NAMES;
            case 5: return HeadItems.PETS;
            default: return HeadItems.PACKS;
        }
    }

    private int cosIdx(int cat) {
        switch (cat) {
            case 0: return Config.cloakIdx;
            case 1: return Config.capeIdx;
            case 2: return Config.wingIdx;
            case 3: return Config.bandanaIdx;
            case 4: return Config.headIdx;
            case 5: return Config.petIdx;
            default: return Config.packIdx;
        }
    }

    private void cosSet(int cat, int i) {
        switch (cat) {
            case 0: Config.cloakIdx = i; if (i > 0) Config.capeIdx = 0; break;
            case 1: Config.capeIdx = i; if (i > 0) Config.cloakIdx = 0; break;
            case 2: Config.wingIdx = i; break;
            case 3: Config.bandanaIdx = i; break;
            case 4: Config.headIdx = i; break;
            case 5: Config.petIdx = i; break;
            default: Config.packIdx = i;
        }
        Config.save();
    }

    private List<Integer> visCos() {
        List<Integer> l = new ArrayList<Integer>();
        String[] names = cosNames(cosCat);
        String q = search.toLowerCase();
        for (int i = 0; i < names.length; i++) if (q.isEmpty() || names[i].toLowerCase().contains(q)) l.add(i);
        return l;
    }

    // ------------------------------------------------------------ grid pass (draw + click share the same layout)
    private boolean gridPass(boolean draw, int mx, int my, boolean click) {
        boolean mods = top == Top.MODS;
        List<Entry> vm = mods ? visMods() : null;
        List<Integer> vc = mods ? null : visCos();
        int n = mods ? vm.size() : vc.size();
        int cardH = mods ? 132 : 126, gap = 10;
        int cols = Math.max(1, (gridW + gap) / (152 + gap));
        int cardW = (gridW - gap * (cols - 1)) / cols;
        int rows = (n + cols - 1) / cols;
        int total = rows * (cardH + gap);
        if (draw) {
            maxScroll = Math.max(0, total - gridH);
            scrollTarget = Math.max(0, Math.min(maxScroll, scrollTarget));
            scrollPos += (scrollTarget - scrollPos) * 0.26f;
        }
        int sc = Math.round(scrollPos);
        for (int i = 0; i < n; i++) {
            int x = gridX + (i % cols) * (cardW + gap), y = gridY + (i / cols) * (cardH + gap) - sc;
            if (y + cardH < gridY - 4 || y > gridY + gridH) continue;
            boolean handled = mods ? modCard(vm.get(i), x, y, cardW, cardH, mx, my, click)
                                   : cosCard(vc.get(i), x, y, cardW, cardH, mx, my, click);
            if (handled) return true;
        }
        return false;
    }

    private boolean modCard(Entry e, int x, int y, int w, int h, int mx, int my, boolean click) {
        int ox = x + 8, oy = y + 88, ow = w - 16;
        int tx = x + 8, ty = y + 109;
        boolean inGrid = in(mx, my, gridX, gridY, gridW, gridH) && drawer == null;
        if (click) {
            if (!inGrid) return false;
            if (in(mx, my, ox, oy, ow, 17) && !e.opts.isEmpty()) { drawer = e; return true; }
            if (in(mx, my, tx, ty, ow, 17)) { e.toggle.run(); return true; }
            return false;
        }
        boolean hover = inGrid && in(mx, my, x, y, w, h);
        float a = anim("card:" + e.name, hover);
        float on = anim("on:" + e.name, e.on.getAsBoolean());
        int lift = -Math.round(a * 2);
        y += lift;
        UI.rrect(x - 1, y - 1, w + 2, h + 2, 11, c(gold(), (int) (45 + 120 * a + 60 * on)));
        UI.rrect(x, y, w, h, 10, c(mix(CARD(), CARDH(), a), 185));
        UI.rrect(x + 1, y + 1, w - 2, 30, 9, c(0xFFFFFF, (int) (7 + 8 * a)));
        UI.rrect(x + 10, y + 10, w - 20, 56, 8, c(Theme.dark(), 150));
        if (on > 0.01f) UI.glow(x + w / 2 - 14, y + 22, 28, 28, 10, gold(), (int) (40 * on));
        Icons.draw(e.icon, x + w / 2f - 16, y + 18, 32, c(mix(0x8A8068, gold(), Math.max(on, a * 0.6f)), 255));
        tc(e.name, x + w / 2f, y + 70, e.name.length() > 18 ? 8.5f : 10f, TEXT, true);
        boolean hasOpt = !e.opts.isEmpty();
        boolean oh = inGrid && in(mx, my, ox, oy, ow, 17);
        UI.rrect(ox, oy, ow, 17, 6, c(mix(mix(CARD(), 0x000000, 0.35f), CARDH(), oh && hasOpt ? 1f : 0f), 235));
        tc("OPTIONS", x + w / 2f, oy + 4, 8f, hasOpt ? TEXT : OFF(), true);
        boolean th = inGrid && in(mx, my, tx, ty, ow, 17);
        int col = mix(mix(mix(CARD(), 0x000000, 0.2f), CARDH(), th ? 1f : 0f), gold(), on);
        UI.rrect(tx, ty, ow, 17, 6, c(col, 245));
        tc(on > 0.5f ? "ENABLED" : "DISABLED", x + w / 2f, ty + 4, 8f, on > 0.5f ? Theme.dark() : SUB, true);
        return false;
    }

    private boolean cosCard(int idx, int x, int y, int w, int h, int mx, int my, boolean click) {
        boolean inGrid = in(mx, my, gridX, gridY, gridW, gridH);
        if (click) {
            if (inGrid && in(mx, my, x, y, w, h)) { cosSet(cosCat, idx); return true; }
            return false;
        }
        boolean sel = cosIdx(cosCat) == idx;
        boolean hover = inGrid && in(mx, my, x, y, w, h);
        float a = anim("cos:" + cosCat + ":" + idx, hover);
        float s = anim("csel:" + cosCat + ":" + idx, sel);
        y -= Math.round(a * 2);
        UI.rrect(x - 1, y - 1, w + 2, h + 2, 11, c(gold(), (int) (45 + 150 * Math.max(a * 0.6f, s))));
        UI.rrect(x, y, w, h, 10, c(mix(CARD(), CARDH(), a), 185));
        UI.rrect(x + 10, y + 10, w - 20, 66, 8, c(Theme.dark(), 160));
        int tx = x + w / 2, ty = y + 11;
        drawCosPreview(idx, tx, ty, y);
        String nm = cosNames(cosCat)[idx];
        tc(nm, x + w / 2f, y + 80, nm.length() > 16 ? 8.5f : 10f, TEXT, true);
        int by = y + h - 24;
        int col = mix(mix(mix(CARD(), 0x000000, 0.2f), CARDH(), a), gold(), s);
        UI.rrect(x + 8, by, w - 16, 17, 6, c(col, 245));
        tc(sel ? "EQUIPPED" : "EQUIP", x + w / 2f, by + 4, 8f, sel ? Theme.dark() : TEXT, true);
        return false;
    }

    private void drawCosPreview(int idx, int tx, int ty, int y) {
        if (idx == 0) { tc("-", tx, y + 30, 18f, SUB, true); return; }
        switch (cosCat) {
            case 0: {
                ResourceLocation tex = CloakTextures.preview(idx);
                if (tex != null) UI.drawTex(tex, tx - 20, ty + 3, 40, 62, CapeTextures.U0, CapeTextures.V0, CapeTextures.U1, CapeTextures.V1, alpha, true);
                break;
            }
            case 1: {
                ResourceLocation tex = CapeTextures.preview(idx);
                if (tex != null) UI.drawTex(tex, tx - 20, ty + 3, 40, 62, CapeTextures.U0, CapeTextures.V0, CapeTextures.U1, CapeTextures.V1, alpha, false);
                break;
            }
            case 2: {
                ResourceLocation tex = WingTextures.get(idx);
                if (tex != null) UI.drawTex(tex, tx - 29, ty + 4, 58, 58, 0f, 0f, 1f, 1f, alpha, true);
                break;
            }
            case 3: {
                ResourceLocation tex = BandanaTextures.get(idx);
                if (tex != null) UI.drawTex(tex, tx - 34, ty + 20, 68, 17, 0f, 0f, 1f, 1f, alpha, false);
                break;
            }
            case 4: tc(HeadItems.ABBR[idx], tx, y + 30, 18f, gold(), true); break;
            case 5: {
                if (idx == 1) Bat.draw(tx - 22, ty + 8, 44, alpha);
                else {
                    int[] cols = {0, 0, 0x4CFF6B, 0xB46BFF, 0xFF9A1F};
                    UI.glow(tx - 12, ty + 22, 24, 24, 12, cols[idx], (int) (alpha * 90));
                    UI.rrect(tx - 14, ty + 20, 28, 28, idx == 2 ? 6 : 14, c(cols[idx], 255));
                }
                break;
            }
            default: {
                int[] cols = {0, 0x15151B, 0xC9951A, 0x4A5D2A};
                UI.rrect(tx - 18, ty + 8, 36, 46, 8, c(cols[idx], 255));
                UI.rrect(tx - 12, ty + 32, 24, 14, 4, c(idx == 2 ? 0x15151B : gold(), 255));
            }
        }
    }

    // ------------------------------------------------------------ screen
    @Override
    public void initGui() {
        pw = Math.min(width - 16, 700);
        ph = Math.min(height - 16, 410);
        px = (width - pw) / 2;
        py = (height - ph) / 2;
        leftX = px + 10; leftY = py + TOPH + 6; leftW = 128; leftH = ph - TOPH - 16;
        mainX = leftX + leftW + 12; mainW = px + pw - 14 - mainX;
        chipY = py + TOPH + 8;
        gridX = mainX; gridY = chipY + 26; gridW = mainW; gridH = py + ph - 12 - gridY;
        if (entries.isEmpty()) buildEntries();
        MenuBlur.enable();
    }

    @Override
    public void drawScreen(int mx, int my, float pt) {
        alpha = Math.max(0.12f, Math.min(1f, (System.currentTimeMillis() - openTime) / 240f));
        ScaledResolution sr = new ScaledResolution(mc);
        sf = sr.getScaleFactor(); sh = sr.getScaledHeight();
        CapeTextures.budget = 3;
        CloakTextures.budget = 2;
        int smx = drawer != null ? -1000 : mx, smy = drawer != null ? -1000 : my;
        drawRect(0, 0, width, height, ((int) (alpha * 110)) << 24);

        GlStateManager.pushMatrix();
        GlStateManager.translate(0f, (1f - alpha) * 10f, 0f);

        UI.glow(px, py, pw, ph, 14, gold(), (int) (alpha * 50));
        UI.rrect(px - 1, py - 1, pw + 2, ph + 2, 15, c(gold(), 130));
        UI.rrect(px, py, pw, ph, 14, c(BG(), 205));
        UI.rrect(px, py, pw, TOPH, 14, c(PANEL(), 215));
        drawRect(px, py + TOPH - 14, px + pw, py + TOPH, c(PANEL(), 215));
        drawRect(px + 14, py + TOPH, px + pw - 14, py + TOPH + 1, c(gold(), 80));

        Bat.draw(px + 12, py + 7, 38, alpha);
        UI.cursive("Jonny Client", px + 56, py + 3, 30f, c(gold(), 255), true);

        Top[] tops = Top.values();
        int tabX = mainX + 70;
        for (int i = 0; i < tops.length; i++) {
            int tw0 = (int) tw(tops[i].title, 9f, true) + 28;
            boolean sel = tops[i] == top;
            boolean h = in(smx, smy, tabX, py + 15, tw0, 22);
            float a = anim("top:" + i, sel);
            UI.rrect(tabX, py + 15, tw0, 22, 8, c(mix(mix(CARD(), CARDH(), h ? 1f : 0f), gold(), a), 240));
            tc(tops[i].title, tabX + tw0 / 2f, py + 21, 9f, sel ? Theme.dark() : TEXT, true);
            tabX += tw0 + 8;
        }
        boolean xh = in(smx, smy, px + pw - 36, py + 15, 22, 22);
        UI.rrect(px + pw - 36, py + 15, 22, 22, 8, c(mix(CARD(), 0xC03A3A, anim("xbtn", xh)), 240));
        tc("x", px + pw - 25, py + 19, 11f, TEXT, true);

        drawLeft(smx, smy);

        if (top == Top.SETTINGS) {
            setHover(mainX, chipY, mainW, py + ph - chipY);
            drawSettings(smx, smy);
        } else {
            drawChips(smx, smy);
            GL11.glEnable(GL11.GL_SCISSOR_TEST);
            scissor(gridX - 3, gridY - 2, gridW + 6, gridH + 2);
            setHover(gridX, gridY, gridW, gridH);
            gridPass(true, smx, smy, false);
            GL11.glDisable(GL11.GL_SCISSOR_TEST);
            if (maxScroll > 0) {
                int barH = Math.max(26, gridH * gridH / (gridH + maxScroll));
                int barY = gridY + (int) ((gridH - barH) * (Math.round(scrollPos) / (float) maxScroll));
                UI.rrect(px + pw - 9, barY, 3, barH, 1, c(gold(), 200));
            }
        }

        if (drawer != null) drawDrawer(mx, my);
        if (System.currentTimeMillis() < flashUntil) {
            float fw = tw(flash, 9f, true) + 28;
            UI.rrect((int) (px + (pw - fw) / 2), py + ph - 36, (int) fw, 24, 9, c(gold(), 245));
            tc(flash, px + pw / 2f, py + ph - 30, 9f, Theme.dark(), true);
        }
        GlStateManager.popMatrix();
        super.drawScreen(mx, my, pt);
    }

    private void leftBtn(String label, int y, int mx, int my, boolean primary) {
        boolean h = in(mx, my, leftX + 8, y, leftW - 16, 22);
        float a = anim("lb:" + label, h);
        int col = primary ? mix(gold(), 0xFFFFFF, a * 0.25f) : mix(mix(CARD(), 0x000000, 0.15f), CARDH(), a);
        UI.rrect(leftX + 8, y, leftW - 16, 22, 8, c(col, 245));
        tc(label, leftX + leftW / 2f, y + 7, 8f, primary ? Theme.dark() : TEXT, true);
    }

    private int leftBtnY(int i) { return leftY + leftH - 8 - (4 - i) * 26; }

    private void drawLeft(int mx, int my) {
        UI.rrect(leftX, leftY, leftW, leftH, 10, c(PANEL(), 175));
        t("PROFILES", leftX + 12, leftY + 9, 8f, SUB, true);
        for (int i = 0; i < Config.PROFILE_NAMES.length; i++) {
            int ry = leftY + 26 + i * 24;
            boolean sel = Config.profile == i;
            float a = anim("prof:" + i, sel);
            boolean h = in(mx, my, leftX + 8, ry, leftW - 16, 20);
            UI.rrect(leftX + 8, ry, leftW - 16, 20, 7, c(mix(mix(CARD(), CARDH(), h ? 1f : 0f), gold(), a), 240));
            t(Config.PROFILE_NAMES[i], leftX + 18, ry + 5, 9f, sel ? Theme.dark() : TEXT, true);
        }
        leftBtn("MAX FPS PRESET", leftBtnY(0), mx, my, true);
        leftBtn("RESOURCE PACKS", leftBtnY(1), mx, my, false);
        leftBtn("SAVE PROFILE", leftBtnY(2), mx, my, false);
        leftBtn("EDIT HUD LAYOUT", leftBtnY(3), mx, my, false);
    }

    private void drawChips(int mx, int my) {
        String[] cats = top == Top.MODS ? MOD_CATS : COS_CATS;
        int cur = top == Top.MODS ? modCat : cosCat;
        int x = mainX;
        for (int i = 0; i < cats.length; i++) {
            int cw = (int) tw(cats[i], 8f, true) + 20;
            boolean sel = i == cur, h = in(mx, my, x, chipY, cw, 18);
            float a = anim("chip:" + top + i, sel);
            UI.rrect(x, chipY, cw, 18, 7, c(mix(mix(CARD(), CARDH(), h ? 1f : 0f), gold(), a), 240));
            tc(cats[i], x + cw / 2f, chipY + 5, 8f, sel ? Theme.dark() : TEXT, true);
            x += cw + 5;
        }
        int sx = mainX + mainW - 130;
        UI.rrect(sx, chipY, 130, 18, 7, c(mix(CARD(), CARDH(), searchFocus ? 1f : 0f), 240));
        String shown = search.isEmpty() && !searchFocus ? "Search..." : search + ((System.currentTimeMillis() / 500) % 2 == 0 && searchFocus ? "_" : "");
        t(shown, sx + 8, chipY + 4, 9f, search.isEmpty() && !searchFocus ? SUB : TEXT, false);
    }

    private void drawSettings(int mx, int my) {
        if (settingsItems.isEmpty()) {
            settingsItems.add(new ThemeRow());
            settingsItems.add(new BoolRow("s:blur", "Menu blur", "Blurs the world behind this menu", () -> Config.menuBlur, () -> { Config.menuBlur = !Config.menuBlur; if (Config.menuBlur) MenuBlur.enable(); else MenuBlur.disable(); }));
            settingsItems.add(new BoolRow("s:script", "Script menu text", "Use the cursive font for all menu text", () -> Config.scriptMenu, () -> Config.scriptMenu = !Config.scriptMenu));
            settingsItems.add(new BoolRow("s:font", "Modern HUD font", "Smooth Segoe UI text on the HUD", () -> Config.modernFont, () -> Config.modernFont = !Config.modernFont));
            settingsItems.add(new BtnRow(() -> "Run 30s benchmark (singleplayer)", () -> { mc.displayGuiScreen(null); String r = Events.startBenchmark(); if (mc.thePlayer != null) mc.thePlayer.addChatMessage(new net.minecraft.util.ChatComponentText("\u00a76[Jonny] \u00a7f" + r)); }));
            settingsItems.add(new BtnRow(() -> "Reset HUD positions and options", HudMods::resetAll));
            settingsItems.add(new BtnRow(() -> "Reset everything to default", () -> { HudMods.resetAll(); GfxTuner.resetAll(); Events.refreshEntityWeights(); }));
        }
        GL11.glEnable(GL11.GL_SCISSOR_TEST);
        scissor(mainX - 3, chipY - 2, mainW + 6, py + ph - 10 - chipY);
        int total = 0;
        for (Item it : settingsItems) total += it.step();
        int viewH = py + ph - 12 - chipY;
        maxScroll = Math.max(0, total - viewH);
        scrollTarget = Math.max(0, Math.min(maxScroll, scrollTarget));
        scrollPos += (scrollTarget - scrollPos) * 0.26f;
        int y = chipY - Math.round(scrollPos);
        for (Item it : settingsItems) { it.draw(mainX, y, mainW - 10, mx, my); y += it.step(); }
        GL11.glDisable(GL11.GL_SCISSOR_TEST);
    }

    private void drawDrawer(int mx, int my) {
        drawRect(px, py, px + pw, py + ph, ((int) (alpha * 130)) << 24);
        int dw = 340, total = 0;
        for (Item it : drawer.opts) total += it.step();
        int dh = 96 + total + 40;
        int dx = px + (pw - dw) / 2, dy = py + (ph - dh) / 2;
        UI.glow(dx, dy, dw, dh, 12, gold(), (int) (alpha * 70));
        UI.rrect(dx - 1, dy - 1, dw + 2, dh + 2, 13, c(gold(), 150));
        UI.rrect(dx, dy, dw, dh, 12, c(BG(), 248));
        Icons.draw(drawer.icon, dx + dw / 2f - 14, dy + 10, 28, c(gold(), 255));
        tc(drawer.name.toUpperCase() + " OPTIONS", dx + dw / 2f, dy + 42, 11f, gold(), true);
        tc(drawer.desc, dx + dw / 2f, dy + 60, 8.5f, SUB, false);
        setHover(dx, dy, dw, dh);
        int y = dy + 80;
        for (Item it : drawer.opts) { it.draw(dx + 14, y, dw - 28, mx, my); y += it.step(); }
        int by = dy + dh - 34;
        boolean h = in(mx, my, dx + dw / 2 - 50, by, 100, 22);
        UI.rrect(dx + dw / 2 - 50, by, 100, 22, 8, c(gold(), h ? 255 : 225));
        tc("DONE", dx + dw / 2f, by + 6, 9f, Theme.dark(), true);
    }

    // ------------------------------------------------------------ input
    @Override
    protected void mouseClicked(int mx, int my, int btn) throws IOException {
        super.mouseClicked(mx, my, btn);
        if (btn != 0) return;
        searchFocus = false;

        if (drawer != null) {
            int dw = 340, total = 0;
            for (Item it : drawer.opts) total += it.step();
            int dh = 96 + total + 40;
            int dx = px + (pw - dw) / 2, dy = py + (ph - dh) / 2;
            if (in(mx, my, dx + dw / 2 - 50, dy + dh - 34, 100, 22) || !in(mx, my, dx, dy, dw, dh)) { drawer = null; Config.save(); return; }
            int y = dy + 80;
            for (Item it : drawer.opts) {
                if (in(mx, my, dx + 14, y, dw - 28, it.step() - 4)) { it.click(dx + 14, y, dw - 28, mx, my); return; }
                y += it.step();
            }
            return;
        }

        if (in(mx, my, px + pw - 36, py + 15, 22, 22)) { mc.displayGuiScreen(null); return; }
        Top[] tops = Top.values();
        int tabX = mainX + 70;
        for (int i = 0; i < tops.length; i++) {
            int tw0 = (int) tw(tops[i].title, 9f, true) + 28;
            if (in(mx, my, tabX, py + 15, tw0, 22)) { top = tops[i]; lastTop = top; scrollTarget = 0; scrollPos = 0; search = ""; return; }
            tabX += tw0 + 8;
        }
        for (int i = 0; i < Config.PROFILE_NAMES.length; i++) {
            if (in(mx, my, leftX + 8, leftY + 26 + i * 24, leftW - 16, 20)) {
                if (Config.profile != i) { Config.switchProfile(i); GfxTuner.apply(); Events.refreshEntityWeights(); flash("Loaded profile: " + Config.PROFILE_NAMES[i]); }
                return;
            }
        }
        if (in(mx, my, leftX + 8, leftBtnY(0), leftW - 16, 22)) { GfxTuner.applyMaxFpsPreset(); Events.refreshEntityWeights(); flash("Max FPS preset applied"); return; }
        if (in(mx, my, leftX + 8, leftBtnY(1), leftW - 16, 22)) { mc.displayGuiScreen(new GuiScreenResourcePacks(this)); return; }
        if (in(mx, my, leftX + 8, leftBtnY(2), leftW - 16, 22)) { Config.save(); flash("Saved profile: " + Config.PROFILE_NAMES[Config.profile]); return; }
        if (in(mx, my, leftX + 8, leftBtnY(3), leftW - 16, 22)) { mc.displayGuiScreen(new HudEditor()); return; }

        if (top == Top.SETTINGS) {
            int y = chipY - Math.round(scrollPos);
            for (Item it : settingsItems) {
                if (in(mx, my, mainX, y, mainW - 10, it.step() - 4)) { it.click(mainX, y, mainW - 10, mx, my); return; }
                y += it.step();
            }
            return;
        }
        String[] cats = top == Top.MODS ? MOD_CATS : COS_CATS;
        int x = mainX;
        for (int i = 0; i < cats.length; i++) {
            int cw = (int) tw(cats[i], 8f, true) + 20;
            if (in(mx, my, x, chipY, cw, 18)) {
                if (top == Top.MODS) { modCat = i; lastModCat = i; } else { cosCat = i; lastCosCat = i; }
                scrollTarget = 0; scrollPos = 0;
                return;
            }
            x += cw + 5;
        }
        if (in(mx, my, mainX + mainW - 130, chipY, 130, 18)) { searchFocus = true; return; }
        gridPass(false, mx, my, true);
    }

    @Override
    protected void mouseClickMove(int mx, int my, int btn, long time) { if (dragging != null) dragging.drag(mx); }

    @Override
    protected void mouseReleased(int mx, int my, int state) {
        super.mouseReleased(mx, my, state);
        dragging = null;
        Config.save();
    }

    @Override
    protected void keyTyped(char ch, int code) throws IOException {
        if (searchFocus) {
            if (code == Keyboard.KEY_ESCAPE) { searchFocus = false; return; }
            if (code == Keyboard.KEY_BACK) { if (!search.isEmpty()) search = search.substring(0, search.length() - 1); scrollTarget = 0; return; }
            if (ChatAllowedCharacters.isAllowedCharacter(ch) && search.length() < 24) { search += ch; scrollTarget = 0; }
            return;
        }
        if (code == Keyboard.KEY_ESCAPE && drawer != null) { drawer = null; return; }
        super.keyTyped(ch, code);
    }

    @Override
    public void handleMouseInput() throws IOException {
        super.handleMouseInput();
        int d = Mouse.getEventDWheel();
        if (d != 0 && drawer == null) scrollTarget = Math.max(0, Math.min(maxScroll, scrollTarget - Integer.signum(d) * 44));
    }

    @Override
    public void onGuiClosed() { Config.save(); MenuBlur.disable(); }

    @Override
    public boolean doesGuiPauseGame() { return false; }
}
