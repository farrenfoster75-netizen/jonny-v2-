package com.jonny.client.mixins;

import com.jonny.client.Config;
import com.jonny.client.Feature;
import net.minecraft.client.Minecraft;
import net.minecraft.client.particle.EffectRenderer;
import net.minecraft.client.particle.EntityCrit2FX;
import net.minecraft.client.particle.EntityFX;
import net.minecraft.client.particle.EntitySpellParticleFX;
import net.minecraft.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Never even create particles we would not draw. */
@Mixin(EffectRenderer.class)
public class MixinEffectRenderer {
    @Inject(method = "addEffect", at = @At("HEAD"), cancellable = true, require = 0)
    private void jonny$cullSpawn(EntityFX effect, CallbackInfo ci) {
        if (effect == null) return;
        if (Feature.NO_POTION_SWIRLS.enabled && effect instanceof EntitySpellParticleFX) { ci.cancel(); return; }
        if (Feature.NO_CRITS.enabled && effect instanceof EntityCrit2FX) { ci.cancel(); return; }
        if (!Feature.PARTICLE_SPAWN.enabled) return;
        Entity viewer = Minecraft.getMinecraft().getRenderViewEntity();
        if (viewer == null) return;
        double max = Config.qd(Config.particleDistance) + 8.0;
        if (effect.getDistanceSqToEntity(viewer) > max * max) ci.cancel();
    }
}
