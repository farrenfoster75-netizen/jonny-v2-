package com.jonny.client.mixins;

import com.jonny.client.Config;
import com.jonny.client.Feature;
import net.minecraft.client.Minecraft;
import net.minecraft.client.audio.ISound;
import net.minecraft.client.audio.SoundHandler;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(SoundHandler.class)
public class MixinSoundHandler {
    @Inject(method = "playSound(Lnet/minecraft/client/audio/ISound;)V", at = @At("HEAD"), cancellable = true, require = 0)
    private void jonny$cull(ISound s, CallbackInfo ci) {
        if (!Feature.SOUND_CULL.enabled || s == null) return;
        if (s.getAttenuationType() == ISound.AttenuationType.NONE) return;
        Minecraft mc = Minecraft.getMinecraft();
        if (mc.thePlayer == null) return;
        double dx = s.getXPosF() - mc.thePlayer.posX, dy = s.getYPosF() - mc.thePlayer.posY, dz = s.getZPosF() - mc.thePlayer.posZ;
        double max = Config.qd(Config.soundDistance);
        if (dx * dx + dy * dy + dz * dz > max * max) ci.cancel();
    }
}
