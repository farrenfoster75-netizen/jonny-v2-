package com.jonny.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.util.ResourceLocation;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.InputStream;

/** The Jonny Client bat logo, loaded from the mod jar. */
public class Bat {
    private static ResourceLocation loc;
    private static boolean failed;
    private static BufferedImage image;

    public static BufferedImage image() {
        if (image == null && !failed) {
            try (InputStream in = Bat.class.getResourceAsStream("/assets/jonnyclient/bat.png")) {
                image = ImageIO.read(in);
            } catch (Throwable t) { failed = true; }
        }
        return image;
    }

    public static ResourceLocation get() {
        if (loc == null && !failed) {
            BufferedImage img = image();
            if (img != null) loc = Minecraft.getMinecraft().getTextureManager().getDynamicTextureLocation("jonny_bat", new DynamicTexture(img));
        }
        return loc;
    }

    /** Draws the bat at the given size. */
    public static void draw(float x, float y, float size, float alpha) {
        ResourceLocation l = get();
        if (l != null) UI.drawTex(l, x, y, size, size, 0f, 0f, 1f, 1f, alpha, true);
    }
}
