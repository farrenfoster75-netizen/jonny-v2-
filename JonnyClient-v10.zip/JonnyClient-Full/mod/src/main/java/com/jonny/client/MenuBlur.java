package com.jonny.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.EntityRenderer;
import net.minecraft.client.renderer.OpenGlHelper;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.fml.relauncher.ReflectionHelper;

import java.lang.reflect.Method;

/** Blurs the world behind the menu using the game's built-in blur shader. */
public class MenuBlur {
    private static boolean on;

    public static void enable() {
        Minecraft mc = Minecraft.getMinecraft();
        if (!Config.menuBlur || on || mc.theWorld == null || !OpenGlHelper.shadersSupported) return;
        try {
            Method m = ReflectionHelper.findMethod(EntityRenderer.class, mc.entityRenderer, new String[]{"loadShader", "func_175069_a"}, ResourceLocation.class);
            m.invoke(mc.entityRenderer, new ResourceLocation("shaders/post/blur.json"));
            on = true;
        } catch (Throwable ignored) {}
    }

    public static void disable() {
        if (!on) return;
        on = false;
        try { Minecraft.getMinecraft().entityRenderer.stopUseShader(); } catch (Throwable ignored) {}
    }
}
