package com.jonny.client;

import java.io.*;
import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.util.Properties;

/** Settings + profiles. Every public static int/boolean field is saved automatically. */
public class Config {
    public static final String[] PROFILE_NAMES = {"Default", "Bedwars", "Duels", "Max FPS"};
    // distances / budgets
    public static int cullDistance = 64, nametagDistance = 32, renderDistance = 0, entityScale = 75, particleCap = 300;
    public static int tileDistance = 32, particleDistance = 24, armorDistance = 24, adaptiveTarget = 144, entityBudget = 70;
    public static int layerDistance = 24, signDistance = 16, itemDistance = 20, itemBudget = 40, soundDistance = 40;
    // visuals
    public static int timeValue = 6000, crosshairStyle = 0, themeIdx = 0;
    public static int chatBg = 40, guiAlpha = 70, guiDim = 55;
    public static boolean modernFont = true, scriptMenu = false, menuBlur = true;
    // cosmetics
    public static int capeIdx = 0, cloakIdx = 0, wingIdx = 0, bandanaIdx = 0, headIdx = 0, petIdx = 0, packIdx = 0;
    // runtime only
    public static int profile = 0;
    public static float q = 1f;
    private static File baseDir;
    private static final String[] SKIP = {"profile"};

    /** Quality-scaled value: shrinks while the FPS governor is lowering quality. */
    public static int qd(int v) { return Feature.GOVERNOR.enabled ? Math.max(1, Math.round(v * q)) : v; }

    private static boolean skip(String n) { for (String s : SKIP) if (s.equals(n)) return true; return false; }

    public static File profileFile(int i) { return new File(baseDir, i == 0 ? "jonnyclient.cfg" : "jonnyclient_p" + i + ".cfg"); }
    private static File slotFile() { return new File(baseDir, "jonnyclient_slot.txt"); }

    public static void load(File mainCfg) {
        baseDir = mainCfg.getParentFile();
        int slot = 0;
        try (BufferedReader r = new BufferedReader(new FileReader(slotFile()))) {
            slot = Math.max(0, Math.min(PROFILE_NAMES.length - 1, Integer.parseInt(r.readLine().trim())));
        } catch (Exception ignored) {}
        profile = slot;
        loadFrom(profileFile(profile));
    }

    public static void switchProfile(int i) {
        save();
        profile = Math.max(0, Math.min(PROFILE_NAMES.length - 1, i));
        try {
            baseDir.mkdirs();
            try (FileWriter w = new FileWriter(slotFile())) { w.write(String.valueOf(profile)); }
        } catch (Exception ignored) {}
        File f = profileFile(profile);
        if (f.exists()) loadFrom(f); else save();
    }

    private static void loadFrom(File f) {
        Properties p = new Properties();
        try (FileInputStream in = new FileInputStream(f)) { p.load(in); } catch (Exception ignored) { return; }
        for (Feature ft : Feature.values()) ft.enabled = Boolean.parseBoolean(p.getProperty(ft.name(), String.valueOf(ft.def)));
        for (Field fl : Config.class.getDeclaredFields()) {
            int m = fl.getModifiers();
            if (!Modifier.isStatic(m) || !Modifier.isPublic(m) || Modifier.isFinal(m) || skip(fl.getName())) continue;
            String v = p.getProperty(fl.getName());
            if (v == null) continue;
            try {
                if (fl.getType() == int.class) fl.setInt(null, Integer.parseInt(v));
                else if (fl.getType() == boolean.class) fl.setBoolean(null, Boolean.parseBoolean(v));
            } catch (Exception ignored) {}
        }
        for (HudMod hm : HudMods.ALL) {
            String k = "hud." + hm.id + ".";
            hm.enabled = Boolean.parseBoolean(p.getProperty(k + "enabled", String.valueOf(hm.defEnabled)));
            hm.bg = Boolean.parseBoolean(p.getProperty(k + "bg", "true"));
            try {
                hm.x = Integer.parseInt(p.getProperty(k + "x", String.valueOf(hm.defX)));
                hm.y = Integer.parseInt(p.getProperty(k + "y", String.valueOf(hm.defY)));
                hm.scale = Math.max(50, Math.min(200, Integer.parseInt(p.getProperty(k + "scale", "100"))));
            } catch (Exception ignored) {}
        }
    }

    public static void save() {
        if (baseDir == null) return;
        Properties p = new Properties();
        for (Feature ft : Feature.values()) p.setProperty(ft.name(), String.valueOf(ft.enabled));
        for (Field fl : Config.class.getDeclaredFields()) {
            int m = fl.getModifiers();
            if (!Modifier.isStatic(m) || !Modifier.isPublic(m) || Modifier.isFinal(m) || skip(fl.getName())) continue;
            try {
                if (fl.getType() == int.class) p.setProperty(fl.getName(), String.valueOf(fl.getInt(null)));
                else if (fl.getType() == boolean.class) p.setProperty(fl.getName(), String.valueOf(fl.getBoolean(null)));
            } catch (Exception ignored) {}
        }
        for (HudMod hm : HudMods.ALL) {
            String k = "hud." + hm.id + ".";
            p.setProperty(k + "enabled", String.valueOf(hm.enabled));
            p.setProperty(k + "bg", String.valueOf(hm.bg));
            p.setProperty(k + "x", String.valueOf(hm.x));
            p.setProperty(k + "y", String.valueOf(hm.y));
            p.setProperty(k + "scale", String.valueOf(hm.scale));
        }
        try {
            baseDir.mkdirs();
            try (FileOutputStream out = new FileOutputStream(profileFile(profile))) { p.store(out, "Jonny Client profile " + profile); }
        } catch (Exception ignored) {}
    }
}
