package com.jonny.client.mixins;

import com.jonny.client.Feature;
import net.minecraft.client.renderer.EntityRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyArg;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(EntityRenderer.class)
public class MixinEntityRenderer {
    @Inject(method = "hurtCameraEffect", at = @At("HEAD"), cancellable = true, require = 0)
    private void jonny$noHurtCam(CallbackInfo ci) {
        if (Feature.NO_HURTCAM.enabled) ci.cancel();
    }

    @ModifyArg(method = "setupCameraTransform", at = @At(value = "INVOKE", target = "Lorg/lwjgl/util/glu/Project;gluPerspective(FFFF)V"), index = 3, require = 0)
    private float jonny$farPlane(float far) {
        return Feature.TIGHT_FAR.enabled ? far * 0.82f : far;
    }
}
