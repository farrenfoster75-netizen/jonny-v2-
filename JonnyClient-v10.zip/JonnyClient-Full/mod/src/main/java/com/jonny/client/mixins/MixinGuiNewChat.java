package com.jonny.client.mixins;

import com.jonny.client.Config;
import com.jonny.client.Feature;
import net.minecraft.client.gui.GuiNewChat;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyArg;

/** See-through chat: scales the alpha of every chat line background. */
@Mixin(GuiNewChat.class)
public class MixinGuiNewChat {
    @ModifyArg(method = "drawChat", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/GuiNewChat;drawRect(IIIII)V"), index = 4, require = 0)
    private int jonny$bgA(int color) { return scale(color); }

    @ModifyArg(method = "drawChat", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/Gui;drawRect(IIIII)V"), index = 4, require = 0)
    private int jonny$bgB(int color) { return scale(color); }

    private static int scale(int color) {
        if (!Feature.CLEAR_CHAT.enabled) return color;
        int a = ((color >>> 24) & 255) * Config.chatBg / 100;
        return (a << 24) | (color & 0xFFFFFF);
    }
}
