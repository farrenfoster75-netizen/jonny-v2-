package com.jonny.client.mixins;

import com.jonny.client.Config;
import com.jonny.client.Feature;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.entity.layers.LayerArmorBase;
import net.minecraft.entity.EntityLivingBase;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(LayerArmorBase.class)
public class MixinLayerArmorBase {
    @Inject(method = "renderGlint", at = @At("HEAD"), cancellable = true, require = 0)
    private void jonny$noArmorGlint(CallbackInfo ci) {
        if (Feature.NO_GLINT.enabled) ci.cancel();
    }

    @Inject(method = "doRenderLayer", at = @At("HEAD"), cancellable = true, require = 0)
    private void jonny$farArmor(EntityLivingBase e, float a, float b, float c, float d, float f, float g, float h, CallbackInfo ci) {
        if (!Feature.ARMOR_CULL.enabled) return;
        Minecraft mc = Minecraft.getMinecraft();
        if (mc.thePlayer == null || e == mc.thePlayer) return;
        if (mc.thePlayer.getDistanceToEntity(e) > Config.qd(Config.armorDistance)) ci.cancel();
    }
}
