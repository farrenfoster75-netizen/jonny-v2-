package com.jonny.client.mixins;

import com.jonny.client.Config;
import com.jonny.client.CosmeticRenderer;
import com.jonny.client.Feature;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.AbstractClientPlayer;
import net.minecraft.client.model.ModelPlayer;
import net.minecraft.client.renderer.entity.RenderPlayer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Cosmetics after the player model, and skin overlay layers off for far players. */
@Mixin(RenderPlayer.class)
public class MixinRenderPlayer {
    @Inject(method = "doRender(Lnet/minecraft/client/entity/AbstractClientPlayer;DDDFF)V", at = @At("TAIL"), require = 0)
    private void jonny$cosmetics(AbstractClientPlayer p, double x, double y, double z, float yaw, float pt, CallbackInfo ci) {
        CosmeticRenderer.render(p, x, y, z, pt);
    }

    @Inject(method = "setModelVisibilities(Lnet/minecraft/client/entity/AbstractClientPlayer;)V", at = @At("TAIL"), require = 0)
    private void jonny$lod(AbstractClientPlayer p, CallbackInfo ci) {
        if (!Feature.LOD_SKIN.enabled) return;
        Minecraft mc = Minecraft.getMinecraft();
        if (mc.thePlayer == null || p == mc.thePlayer) return;
        if (mc.thePlayer.getDistanceToEntity(p) > Config.qd(Config.layerDistance)) {
            ModelPlayer m = ((RenderPlayer) (Object) this).getMainModel();
            m.bipedBodyWear.showModel = false;
            m.bipedLeftArmwear.showModel = false;
            m.bipedRightArmwear.showModel = false;
            m.bipedLeftLegwear.showModel = false;
            m.bipedRightLegwear.showModel = false;
            m.bipedHeadwear.showModel = false;
        }
    }
}
