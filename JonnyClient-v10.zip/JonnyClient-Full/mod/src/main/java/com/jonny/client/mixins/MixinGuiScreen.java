package com.jonny.client.mixins;

import com.jonny.client.Config;
import com.jonny.client.Feature;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.ScaledResolution;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Lighter dimming behind inventories and menus. */
@Mixin(GuiScreen.class)
public class MixinGuiScreen {
    @Inject(method = "drawWorldBackground", at = @At("HEAD"), cancellable = true, require = 0)
    private void jonny$dim(int tint, CallbackInfo ci) {
        if (!Feature.CLEAR_GUI.enabled) return;
        Minecraft mc = Minecraft.getMinecraft();
        if (mc.theWorld == null) return;
        ScaledResolution sr = new ScaledResolution(mc);
        int a = (int) (0xC0 * Config.guiDim / 100f);
        Gui.drawRect(0, 0, sr.getScaledWidth(), sr.getScaledHeight(), (a << 24) | 0x101010);
        ci.cancel();
    }
}
