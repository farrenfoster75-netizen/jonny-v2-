package com.jonny.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.WorldRenderer;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.util.ResourceLocation;
import org.lwjgl.opengl.GL11;

import java.awt.Color;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics2D;
import java.awt.GraphicsEnvironment;
import java.awt.RenderingHints;
import java.awt.font.FontRenderContext;
import java.awt.image.BufferedImage;
import java.io.InputStream;

/** Anti-aliased text from a generated atlas: Segoe UI style sans, plus the bundled Pinyon Script cursive. */
public class ModernFont {
    private static final String[] SANS = {"Segoe UI", "Inter", "Roboto", "Helvetica Neue", "Arial"};
    public static final ModernFont REG = new ModernFont(Font.PLAIN, "jonnyfont_reg", SANS, null, 512, 40, 2, 2);
    public static final ModernFont BOLD = new ModernFont(Font.BOLD, "jonnyfont_bold", SANS, null, 512, 40, 2, 2);
    public static final ModernFont CURSIVE = new ModernFont(Font.PLAIN, "jonnyfont_script", null, "/assets/jonnyclient/fonts/PinyonScript-Regular.ttf", 1024, 64, 14, 18);

    private static final int ATLAS_PX = 32, FIRST = 32, LAST = 126;

    private final int style, size, cellW, pad, extra;
    private final String texName, resource;
    private final String[] prefs;
    private boolean ready, failed;
    private ResourceLocation loc;
    private final float[] gx = new float[128], gy = new float[128], gw = new float[128];
    private float cellH = 40f;

    private ModernFont(int style, String texName, String[] prefs, String resource, int size, int cellW, int pad, int extra) {
        this.style = style; this.texName = texName; this.prefs = prefs; this.resource = resource;
        this.size = size; this.cellW = cellW; this.pad = pad; this.extra = extra;
    }

    private Font loadFont() throws Exception {
        if (resource != null) {
            try (InputStream in = ModernFont.class.getResourceAsStream(resource)) {
                if (in != null) return Font.createFont(Font.TRUETYPE_FONT, in).deriveFont((float) ATLAS_PX);
            }
        }
        String family = "SansSerif";
        if (prefs != null) {
            String[] names = GraphicsEnvironment.getLocalGraphicsEnvironment().getAvailableFontFamilyNames();
            boolean found = false;
            for (String pref : prefs) {
                for (String n : names) if (n.equalsIgnoreCase(pref)) { family = n; found = true; break; }
                if (found) break;
            }
        } else family = "Serif";
        return new Font(family, resource != null ? Font.ITALIC : style, ATLAS_PX);
    }

    private void init() {
        if (ready || failed) return;
        try {
            Font font = loadFont();
            BufferedImage img = new BufferedImage(size, size, BufferedImage.TYPE_INT_ARGB);
            Graphics2D g = img.createGraphics();
            g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
            g.setRenderingHint(RenderingHints.KEY_FRACTIONALMETRICS, RenderingHints.VALUE_FRACTIONALMETRICS_ON);
            g.setFont(font);
            FontMetrics fm = g.getFontMetrics();
            FontRenderContext frc = g.getFontRenderContext();
            cellH = fm.getHeight();
            int cellFull = (int) cellH + 4;
            int cols = size / cellW;
            g.setColor(Color.WHITE);
            for (int c = FIRST; c <= LAST; c++) {
                int idx = c - FIRST;
                int cx = (idx % cols) * cellW;
                int py = (idx / cols) * cellFull + 2;
                String s = String.valueOf((char) c);
                g.drawString(s, cx + pad, py + fm.getAscent());
                gx[c] = cx;
                gy[c] = py;
                gw[c] = (float) font.getStringBounds(s, frc).getWidth();
            }
            g.dispose();
            loc = Minecraft.getMinecraft().getTextureManager().getDynamicTextureLocation(texName, new DynamicTexture(img));
            ready = true;
        } catch (Throwable t) {
            failed = true;
        }
    }

    public float height(float px) { return (ready ? cellH : 40f) * px / ATLAS_PX; }

    public float width(String s, float px) {
        init();
        if (failed) return Minecraft.getMinecraft().fontRendererObj.getStringWidth(s) * px / 8f;
        float k = px / ATLAS_PX, w = 0;
        for (int i = 0; i < s.length(); i++) {
            char ch = s.charAt(i);
            if (ch < FIRST || ch > LAST) ch = '?';
            w += gw[ch] * k;
        }
        return w;
    }

    public void draw(String s, float x, float y, float px, int argb, boolean shadow) {
        init();
        if (failed) {
            float sc = px / 8f;
            GlStateManager.pushMatrix();
            GlStateManager.translate(x, y, 0f);
            GlStateManager.scale(sc, sc, 1f);
            Minecraft.getMinecraft().fontRendererObj.drawString(s, 0, 0, argb | 0xFF000000, shadow);
            GlStateManager.popMatrix();
            return;
        }
        if (shadow) {
            int sh = (argb & 0xFF000000) | ((argb & 0xFCFCFC) >> 2);
            drawRaw(s, x + px / 10f, y + px / 10f, px, sh);
        }
        drawRaw(s, x, y, px, argb);
    }

    private void drawRaw(String s, float x, float y, float px, int argb) {
        float a = ((argb >>> 24) & 255) / 255f;
        if (a == 0f) a = 1f;
        float r = ((argb >> 16) & 255) / 255f, gr = ((argb >> 8) & 255) / 255f, b = (argb & 255) / 255f;
        float k = px / ATLAS_PX, h = cellH * k;
        Minecraft.getMinecraft().getTextureManager().bindTexture(loc);
        GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_MIN_FILTER, GL11.GL_LINEAR);
        GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_MAG_FILTER, GL11.GL_LINEAR);
        GlStateManager.enableTexture2D();
        GlStateManager.enableBlend();
        GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
        GlStateManager.color(r, gr, b, a);
        WorldRenderer wr = Tessellator.getInstance().getWorldRenderer();
        wr.begin(7, DefaultVertexFormats.POSITION_TEX);
        float cx = x;
        for (int i = 0; i < s.length(); i++) {
            char ch = s.charAt(i);
            if (ch < FIRST || ch > LAST) ch = '?';
            float quadW = Math.min(cellW - 2, pad + gw[ch] + extra);
            float xl = cx - pad * k, xr = xl + quadW * k;
            float u0 = gx[ch] / size, u1 = (gx[ch] + quadW) / size;
            float v0 = gy[ch] / size, v1 = (gy[ch] + cellH) / size;
            wr.pos(xl, y + h, 0).tex(u0, v1).endVertex();
            wr.pos(xr, y + h, 0).tex(u1, v1).endVertex();
            wr.pos(xr, y, 0).tex(u1, v0).endVertex();
            wr.pos(xl, y, 0).tex(u0, v0).endVertex();
            cx += gw[ch] * k;
        }
        Tessellator.getInstance().draw();
        GlStateManager.color(1f, 1f, 1f, 1f);
    }
}
