package com.jonny.client;

import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.RenderGlobal;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.item.EntityArmorStand;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.ChatComponentText;
import net.minecraft.util.IChatComponent;
import net.minecraft.util.BlockPos;
import net.minecraft.util.MovingObjectPosition;
import net.minecraft.util.Vec3;
import net.minecraftforge.client.event.*;
import net.minecraftforge.event.entity.EntityJoinWorldEvent;
import net.minecraftforge.event.entity.player.AttackEntityEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import net.minecraftforge.fml.relauncher.ReflectionHelper;
import org.lwjgl.input.Keyboard;
import org.lwjgl.opengl.Display;
import org.lwjgl.opengl.GL11;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.WeakHashMap;

public class Events {
    private final Minecraft mc = Minecraft.getMinecraft();

    private float savedGamma = -1f;
    private boolean gfxApplied = false;
    private boolean throttled = false;
    private int savedLimit;
    private long ticks = 0;
    private int raysThisTick = 0;
    private final HashSet<Integer> allowed = new HashSet<Integer>();
    private boolean budgetReady = false;
    private static boolean benchmarking = false;
    private static int benchTicks = 0;

    /** Starts a 30 second camera spin benchmark (singleplayer only, so no rotation packets reach a server). */
    public static String startBenchmark() {
        Minecraft m = Minecraft.getMinecraft();
        if (m.thePlayer == null || m.theWorld == null) return "Join a world first.";
        if (!m.isSingleplayer()) return "Benchmark runs in singleplayer only.";
        benchmarking = true; benchTicks = 0; Stats.benchStart();
        return "Benchmark started: 30 seconds, camera spins. Don't touch anything.";
    }

    private void buildBudget() {
        allowed.clear();
        budgetReady = false;
        if (!Feature.ENTITY_BUDGET.enabled || mc.theWorld == null || mc.thePlayer == null) return;
        int budget = Config.qd(Config.entityBudget);
        ArrayList<double[]> list = new ArrayList<double[]>();
        for (Object o : mc.theWorld.loadedEntityList) {
            if (o instanceof EntityLivingBase && o != mc.thePlayer) {
                EntityLivingBase en = (EntityLivingBase) o;
                list.add(new double[]{mc.thePlayer.getDistanceSqToEntity(en), en.getEntityId()});
            }
        }
        if (list.size() <= budget) return;
        Collections.sort(list, new Comparator<double[]>() {
            public int compare(double[] a, double[] b) { return Double.compare(a[0], b[0]); }
        });
        for (int i = 0; i < budget; i++) allowed.add((int) list.get(i)[1]);
        budgetReady = true;
    }
    private boolean sneakToggled = false, sneakWasOn = false;
    private boolean hitboxState = false;
    private int lastHurt = 0;
    private double lastX, lastZ;
    private boolean haveLast = false;

    private final Map<Integer, long[]> occl = new HashMap<Integer, long[]>();
    private final Map<Entity, Double> baseWeight = new WeakHashMap<Entity, Double>();
    private Field fxField;
    private boolean fxFailed = false;

    // ---------------------------------------------------------------- tick
    @SubscribeEvent
    public void onTick(TickEvent.ClientTickEvent e) {
        if (e.phase != TickEvent.Phase.END) return;
        if (mc.gameSettings == null) return;
        ticks++;
        raysThisTick = 0;

        if (!gfxApplied) { GfxTuner.apply(); gfxApplied = true; }

        if (JonnyClient.menuKey.isPressed()) {
            if (mc.currentScreen instanceof ModMenu) mc.displayGuiScreen(null);
            else if (mc.currentScreen == null) mc.displayGuiScreen(new ModMenu());
        }

        handleUnfocused();

        if (mc.thePlayer == null || mc.theWorld == null) { haveLast = false; return; }
        EntityPlayer p = mc.thePlayer;

        // sprint / sneak
        if (Feature.TOGGLE_SPRINT.enabled && mc.currentScreen == null
                && mc.gameSettings.keyBindForward.isKeyDown() && !p.isUsingItem()) {
            KeyBinding.setKeyBindState(mc.gameSettings.keyBindSprint.getKeyCode(), true);
        }
        if (JonnyClient.sneakKey.isPressed() && Feature.TOGGLE_SNEAK.enabled && mc.currentScreen == null)
            sneakToggled = !sneakToggled;
        boolean sneakOn = Feature.TOGGLE_SNEAK.enabled && sneakToggled;
        if (sneakOn) {
            KeyBinding.setKeyBindState(mc.gameSettings.keyBindSneak.getKeyCode(), true);
        } else if (sneakWasOn && !Keyboard.isKeyDown(mc.gameSettings.keyBindSneak.getKeyCode())) {
            KeyBinding.setKeyBindState(mc.gameSettings.keyBindSneak.getKeyCode(), false);
        }
        sneakWasOn = sneakOn;

        // fullbright
        if (Feature.FULLBRIGHT.enabled) {
            if (savedGamma < 0) savedGamma = mc.gameSettings.gammaSetting;
            mc.gameSettings.gammaSetting = 100f;
        } else if (savedGamma >= 0) {
            mc.gameSettings.gammaSetting = savedGamma;
            savedGamma = -1f;
        }

        // weather + time
        if (Feature.NO_WEATHER.enabled) {
            mc.theWorld.setRainStrength(0f);
            mc.theWorld.setThunderStrength(0f);
        }
        if (Feature.TIME_CHANGER.enabled) mc.theWorld.setWorldTime((long) Config.timeValue);

        // hitboxes
        if (hitboxState != Feature.HITBOXES.enabled) {
            hitboxState = Feature.HITBOXES.enabled;
            mc.getRenderManager().setDebugBoundingBox(hitboxState);
        }

        // combo / speed stats
        int ht = p.hurtTime;
        if (ht > lastHurt) Stats.combo = 0;
        lastHurt = ht;
        if (Stats.combo > 0 && System.currentTimeMillis() - Stats.lastHit > 2500) Stats.combo = 0;
        if (haveLast) {
            double dx = p.posX - lastX, dz = p.posZ - lastZ;
            Stats.speed = Stats.speed * 0.8 + (Math.sqrt(dx * dx + dz * dz) * 20.0) * 0.2;
        }
        lastX = p.posX; lastZ = p.posZ; haveLast = true;

        adaptive();

        if (!Feature.GOVERNOR.enabled) Config.q = 1f;
        else if (ticks % 10 == 0 && !throttled && Display.isActive()) {
            int fps = Minecraft.getDebugFPS();
            if (fps < Config.adaptiveTarget * 0.92f) Config.q = Math.max(0.35f, Config.q - 0.05f);
            else if (fps > Config.adaptiveTarget * 1.2f) Config.q = Math.min(1f, Config.q + 0.03f);
        }

        if (benchmarking) {
            p.rotationYaw += 4f;
            if (++benchTicks >= 600) {
                benchmarking = false;
                p.addChatMessage(new ChatComponentText("\u00a76[Jonny] \u00a7f" + Stats.benchEnd()));
            }
        }

        // particle cap
        if (Feature.PARTICLE_CAP.enabled && ticks % 2 == 0) capParticles();

        if (occl.size() > 300) occl.clear();
    }

    private void handleUnfocused() {
        int cap = -1;
        if (Feature.UNFOCUSED_LIMIT.enabled) {
            if (!Display.isVisible()) cap = 5;
            else if (!Display.isActive()) cap = 30;
        }
        if (cap > 0) {
            if (!throttled) { savedLimit = mc.gameSettings.limitFramerate; throttled = true; }
            mc.gameSettings.limitFramerate = cap;
        } else if (throttled) {
            mc.gameSettings.limitFramerate = savedLimit;
            throttled = false;
        }
    }

    private long lastAdapt = 0;

    private void adaptive() {
        if (!Feature.ADAPTIVE_RD.enabled || ticks % 20 != 0 || ticks - lastAdapt < 100) return;
        int fps = Minecraft.getDebugFPS();
        net.minecraft.client.settings.GameSettings s = mc.gameSettings;
        int max = Config.renderDistance > 0 ? Config.renderDistance : Math.max(GfxTuner.originalRender(), 8);
        int cur = s.renderDistanceChunks;
        int next = cur;
        if (fps < Config.adaptiveTarget * 0.85 && cur > 4) next = cur - 1;
        else if (fps > Config.adaptiveTarget * 1.3 && cur < max) next = cur + 1;
        if (next != cur) {
            s.renderDistanceChunks = next;
            if (mc.renderGlobal != null) mc.renderGlobal.setDisplayListEntitiesDirty();
            lastAdapt = ticks;
        }
    }

    @SuppressWarnings({"unchecked", "rawtypes"})
    private void capParticles() {
        if (fxFailed || mc.effectRenderer == null) return;
        try {
            if (fxField == null) fxField = ReflectionHelper.findField(net.minecraft.client.particle.EffectRenderer.class, "fxLayers", "field_78876_b");
            List[][] layers = (List[][]) fxField.get(mc.effectRenderer);
            int total = 0;
            for (List[] a : layers) for (List l : a) total += l.size();
            int excess = total - Config.qd(Config.particleCap);
            if (excess <= 0) return;
            for (List[] a : layers) {
                for (List l : a) {
                    if (excess <= 0) return;
                    int rm = Math.min(excess, l.size() / 2 + 1);
                    rm = Math.min(rm, l.size());
                    if (rm > 0) { l.subList(0, rm).clear(); excess -= rm; }
                }
            }
        } catch (Throwable t) {
            fxFailed = true;
        }
    }

    // ---------------------------------------------------------------- input / stats
    @SubscribeEvent
    public void onRenderTick(TickEvent.RenderTickEvent e) {
        if (e.phase == TickEvent.Phase.START) { Stats.itemsThisFrame = 0; Stats.frame(); buildBudget(); }
    }

    private static final java.text.SimpleDateFormat TS = new java.text.SimpleDateFormat("HH:mm");

    @SubscribeEvent
    public void onChat(ClientChatReceivedEvent e) {
        if (e.type == 2 || e.message == null) return;
        IChatComponent msg = e.message;
        if (Feature.NICK_HIDER.enabled && mc.getSession() != null) {
            String name = mc.getSession().getUsername();
            String text = msg.getFormattedText();
            if (name != null && !name.isEmpty() && text.contains(name)) msg = new ChatComponentText(text.replace(name, "Jonny"));
        }
        if (Feature.CHAT_TIMESTAMPS.enabled) msg = new ChatComponentText("\u00a77[" + TS.format(new java.util.Date()) + "] \u00a7r").appendSibling(msg);
        e.message = msg;
    }

    @SubscribeEvent
    public void onMouse(MouseEvent e) {
        if (e.buttonstate) Stats.click(e.button);
    }

    @SubscribeEvent
    public void onAttack(AttackEntityEvent e) {
        if (e.entityPlayer != mc.thePlayer) return;
        Stats.combo++;
        Stats.lastHit = System.currentTimeMillis();
        if (mc.objectMouseOver != null && mc.objectMouseOver.hitVec != null && mc.thePlayer != null)
            Stats.reach = mc.objectMouseOver.hitVec.distanceTo(mc.thePlayer.getPositionEyes(1f));
    }

    @SubscribeEvent
    public void onFov(FOVUpdateEvent e) {
        if (Feature.ZOOM.enabled && JonnyClient.zoomKey.isKeyDown()) e.newfov = e.fov * 0.25f;
    }

    // ---------------------------------------------------------------- entity optimisation
    @SubscribeEvent
    public void onJoin(EntityJoinWorldEvent e) {
        if (!e.world.isRemote) return;
        Entity en = e.entity;
        if (en == mc.thePlayer) return;
        baseWeight.put(en, en.renderDistanceWeight);
        applyWeight(en);
    }

    private void applyWeight(Entity en) {
        Double b = baseWeight.get(en);
        double base = b == null ? en.renderDistanceWeight : b;
        en.renderDistanceWeight = Feature.ENTITY_SCALE.enabled ? base * (Config.entityScale / 100.0) : base;
    }

    /** Called by the menu when the entity render distance setting changes. */
    public static void refreshEntityWeights() {
        Minecraft mc = Minecraft.getMinecraft();
        if (mc.theWorld == null) return;
        for (Object o : mc.theWorld.loadedEntityList) {
            Entity en = (Entity) o;
            if (en == mc.thePlayer) continue;
            en.renderDistanceWeight = Feature.ENTITY_SCALE.enabled ? 1.0 * (Config.entityScale / 100.0) : 1.0;
        }
    }

    private boolean occluded(EntityLivingBase ent) {
        if (!Feature.OCCLUSION_CULLING.enabled) return false;
        if (mc.thePlayer.getDistanceToEntity(ent) < 8f) return false;
        int id = ent.getEntityId();
        long[] st = occl.get(id);
        if (st == null) { st = new long[]{-100, 1}; occl.put(id, st); }
        if (ticks - st[0] >= 5 && raysThisTick < 10) {
            raysThisTick++;
            st[0] = ticks;
            Vec3 eye = mc.thePlayer.getPositionEyes(1f);
            boolean vis = false;
            double[] hs = {ent.height * 0.9, ent.height * 0.5, ent.height * 0.1};
            for (double hh : hs) {
                Vec3 t = new Vec3(ent.posX, ent.posY + hh, ent.posZ);
                if (mc.theWorld.rayTraceBlocks(eye, t, false, true, false) == null) { vis = true; break; }
            }
            st[1] = vis ? 1 : 0;
        }
        return st[1] == 0;
    }

    @SubscribeEvent
    public void onRenderLiving(RenderLivingEvent.Pre e) {
        if (mc.thePlayer == null) return;
        EntityLivingBase ent = e.entity;
        if (ent == mc.thePlayer) return;
        // never hide mounts, riders, or anything in the player's vehicle chain
        if (ent.riddenByEntity != null || ent.ridingEntity != null) return;
        if (mc.thePlayer.ridingEntity == ent) return;

        if (Feature.ARMOR_STAND_CULL.enabled && ent instanceof EntityArmorStand) {
            e.setCanceled(true);
            return;
        }
        if (Feature.ENTITY_CULLING.enabled && mc.thePlayer.getDistanceToEntity(ent) > Config.qd(Config.cullDistance)) {
            e.setCanceled(true);
            return;
        }
        if (occluded(ent)) { e.setCanceled(true); return; }
        if (budgetReady && !allowed.contains(ent.getEntityId()) && mc.thePlayer.getDistanceToEntity(ent) > 10f) e.setCanceled(true);
    }

    @SubscribeEvent
    public void onNametag(RenderLivingEvent.Specials.Pre e) {
        if (!Feature.NAMETAG_CULLING.enabled || mc.thePlayer == null) return;
        if (mc.thePlayer.getDistanceToEntity(e.entity) > Config.qd(Config.nametagDistance)) e.setCanceled(true);
    }

    @SubscribeEvent
    public void onOverlay(RenderBlockOverlayEvent e) {
        if (Feature.LOW_FIRE.enabled
                && e.overlayType == RenderBlockOverlayEvent.OverlayType.FIRE) e.setCanceled(true);
    }

    // ---------------------------------------------------------------- visuals
    @SubscribeEvent
    public void onHighlight(DrawBlockHighlightEvent e) {
        if (!Feature.BLOCK_OUTLINE.enabled || mc.theWorld == null) return;
        if (e.target == null || e.target.typeOfHit != MovingObjectPosition.MovingObjectType.BLOCK) return;
        e.setCanceled(true);
        EntityPlayer p = e.player;
        BlockPos pos = e.target.getBlockPos();
        Block b = mc.theWorld.getBlockState(pos).getBlock();
        if (b.getMaterial() == Material.air) return;
        b.setBlockBoundsBasedOnState(mc.theWorld, pos);
        double dx = p.lastTickPosX + (p.posX - p.lastTickPosX) * e.partialTicks;
        double dy = p.lastTickPosY + (p.posY - p.lastTickPosY) * e.partialTicks;
        double dz = p.lastTickPosZ + (p.posZ - p.lastTickPosZ) * e.partialTicks;
        AxisAlignedBB bb = b.getSelectedBoundingBox(mc.theWorld, pos).expand(0.002, 0.002, 0.002).offset(-dx, -dy, -dz);
        int c = UI.accent();
        GlStateManager.enableBlend();
        GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
        GlStateManager.color(((c >> 16) & 255) / 255f, ((c >> 8) & 255) / 255f, (c & 255) / 255f, 0.95f);
        GL11.glLineWidth(2.5f);
        GlStateManager.disableTexture2D();
        GlStateManager.depthMask(false);
        RenderGlobal.drawSelectionBoundingBox(bb);
        GlStateManager.depthMask(true);
        GlStateManager.enableTexture2D();
        GlStateManager.disableBlend();
        GlStateManager.color(1f, 1f, 1f, 1f);
    }

    @SubscribeEvent
    public void onCrosshair(RenderGameOverlayEvent.Pre e) {
        if (e.type != RenderGameOverlayEvent.ElementType.CROSSHAIRS || !Feature.CROSSHAIR.enabled) return;
        e.setCanceled(true);
        ScaledResolution sr = new ScaledResolution(mc);
        int cx = sr.getScaledWidth() / 2, cy = sr.getScaledHeight() / 2;
        int col = 0xFF000000 | UI.accent();
        int dark = 0xAA000000;
        int style = Math.floorMod(Config.crosshairStyle, 3);
        if (style == 1) {
            Gui.drawRect(cx - 2, cy - 2, cx + 2, cy + 2, dark);
            Gui.drawRect(cx - 1, cy - 1, cx + 1, cy + 1, col);
        } else {
            int gap = style == 0 ? 3 : 0, len = 5;
            Gui.drawRect(cx - 1 - 1, cy - gap - len - 1, cx + 2, cy - gap + 1, dark);
            Gui.drawRect(cx - 1 - 1, cy + gap - 1, cx + 2, cy + gap + len + 1, dark);
            Gui.drawRect(cx - gap - len - 1, cy - 2, cx - gap + 1, cy + 1 + 1, dark);
            Gui.drawRect(cx + gap - 1, cy - 2, cx + gap + len + 1, cy + 1 + 1, dark);
            Gui.drawRect(cx - 1, cy - gap - len, cx + 1, cy - gap, col);
            Gui.drawRect(cx - 1, cy + gap, cx + 1, cy + gap + len, col);
            Gui.drawRect(cx - gap - len, cy - 1, cx - gap, cy + 1, col);
            Gui.drawRect(cx + gap, cy - 1, cx + gap + len, cy + 1, col);
        }
    }
}
