package com.jonny.client.mixins;

import com.jonny.client.Config;
import com.jonny.client.Feature;
import net.minecraft.client.gui.inventory.GuiChest;
import net.minecraft.client.gui.inventory.GuiCrafting;
import net.minecraft.client.gui.inventory.GuiFurnace;
import net.minecraft.client.gui.inventory.GuiInventory;
import net.minecraft.client.renderer.GlStateManager;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyArg;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Translucent inventory, chest, crafting table and furnace backgrounds. */
@Mixin({GuiInventory.class, GuiChest.class, GuiCrafting.class, GuiFurnace.class})
public class MixinContainerBg {
    @Inject(method = "drawGuiContainerBackgroundLayer", at = @At("HEAD"), require = 0)
    private void jonny$blend(float pt, int mx, int my, CallbackInfo ci) {
        if (Feature.CLEAR_GUI.enabled) {
            GlStateManager.enableBlend();
            GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
        }
    }

    @ModifyArg(method = "drawGuiContainerBackgroundLayer", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/renderer/GlStateManager;color(FFFF)V"), index = 3, require = 0)
    private float jonny$alpha(float a) {
        return Feature.CLEAR_GUI.enabled ? Config.guiAlpha / 100f : a;
    }
}
