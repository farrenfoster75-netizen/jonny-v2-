package com.jonny.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.WorldRenderer;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.util.ResourceLocation;
import org.lwjgl.opengl.GL11;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.geom.RoundRectangle2D;
import java.awt.image.BufferedImage;
import java.util.HashMap;
import java.util.Map;

/** Drawing helpers shared by the menu and the HUD (anti-aliased rounded shapes + text). */
public class UI {
    public static final float HUD_SIZE = 9f;
    public static final int LINE_H = 11;
    private static final int SS = 4;
    private static final Map<Integer, ResourceLocation> ROUND = new HashMap<Integer, ResourceLocation>();

    public static int accent() { return Theme.accent(); }

    private static ResourceLocation roundTex(int r) {
        ResourceLocation loc = ROUND.get(r);
        if (loc != null) return loc;
        int corner = r * SS, t = corner * 2 + 2;
        BufferedImage img = new BufferedImage(t, t, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g = img.createGraphics();
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
        g.setColor(Color.WHITE);
        g.fill(new RoundRectangle2D.Float(0, 0, t, t, corner * 2f, corner * 2f));
        g.dispose();
        loc = Minecraft.getMinecraft().getTextureManager().getDynamicTextureLocation("jonny_rr" + r, new DynamicTexture(img));
        ROUND.put(r, loc);
        return loc;
    }

    private static void quad(WorldRenderer wr, float x0, float y0, float x1, float y1, float u0, float v0, float u1, float v1) {
        wr.pos(x0, y1, 0).tex(u0, v1).endVertex();
        wr.pos(x1, y1, 0).tex(u1, v1).endVertex();
        wr.pos(x1, y0, 0).tex(u1, v0).endVertex();
        wr.pos(x0, y0, 0).tex(u0, v0).endVertex();
    }

    /** Smooth anti-aliased rounded rectangle. */
    public static void rrect(int x, int y, int w, int h, int r, int argb) {
        if (w <= 0 || h <= 0) return;
        float a = ((argb >>> 24) & 255) / 255f;
        if (a <= 0f) return;
        r = Math.min(r, Math.min(w, h) / 2);
        if (r <= 0) { Gui.drawRect(x, y, x + w, y + h, argb); return; }
        Minecraft.getMinecraft().getTextureManager().bindTexture(roundTex(r));
        GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_MIN_FILTER, GL11.GL_LINEAR);
        GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_MAG_FILTER, GL11.GL_LINEAR);
        GlStateManager.enableTexture2D();
        GlStateManager.enableBlend();
        GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
        GlStateManager.color(((argb >> 16) & 255) / 255f, ((argb >> 8) & 255) / 255f, (argb & 255) / 255f, a);
        float c = r * SS, t = c * 2 + 2, f = c / t;
        float[] xs = {x, x + r, x + w - r, x + w};
        float[] ys = {y, y + r, y + h - r, y + h};
        float[] us = {0f, f, 1f - f, 1f};
        WorldRenderer wr = Tessellator.getInstance().getWorldRenderer();
        wr.begin(7, DefaultVertexFormats.POSITION_TEX);
        for (int i = 0; i < 3; i++)
            for (int j = 0; j < 3; j++)
                quad(wr, xs[i], ys[j], xs[i + 1], ys[j + 1], us[i], us[j], us[i + 1], us[j + 1]);
        Tessellator.getInstance().draw();
        GlStateManager.color(1f, 1f, 1f, 1f);
    }

    /** Soft glow / shadow made of expanding translucent rounded rects. */
    public static void glow(int x, int y, int w, int h, int r, int rgb, int maxAlpha) {
        for (int i = 6; i >= 1; i--) {
            int e = i * 2;
            int a = (int) (maxAlpha * Math.pow(0.6, i));
            if (a > 0) rrect(x - e, y - e, w + e * 2, h + e * 2, r + e, withAlpha(rgb, a));
        }
    }

    /** Draw a region of a texture. */
    public static void drawTex(ResourceLocation loc, float x, float y, float w, float h, float u0, float v0, float u1, float v1, float alpha, boolean smooth) {
        Minecraft.getMinecraft().getTextureManager().bindTexture(loc);
        int filter = smooth ? GL11.GL_LINEAR : 9728;
        GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_MIN_FILTER, filter);
        GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_MAG_FILTER, filter);
        GlStateManager.enableTexture2D();
        GlStateManager.enableBlend();
        GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
        GlStateManager.color(1f, 1f, 1f, alpha);
        WorldRenderer wr = Tessellator.getInstance().getWorldRenderer();
        wr.begin(7, DefaultVertexFormats.POSITION_TEX);
        quad(wr, x, y, x + w, y + h, u0, v0, u1, v1);
        Tessellator.getInstance().draw();
        GlStateManager.color(1f, 1f, 1f, 1f);
    }

    private static float sz(float size) { return Config.scriptMenu ? size * 1.3f : size; }

    public static float width(String s, float size, boolean bold) {
        if (Config.scriptMenu) return ModernFont.CURSIVE.width(s, sz(size));
        return (bold ? ModernFont.BOLD : ModernFont.REG).width(s, size);
    }

    public static float cursiveWidth(String s, float size) { return ModernFont.CURSIVE.width(s, size); }

    public static void cursive(String s, float x, float y, float size, int argb, boolean shadow) {
        ModernFont.CURSIVE.draw(s, x, y, size, argb, shadow);
    }

    public static float height(float size) { return ModernFont.REG.height(size); }

    public static void text(String s, float x, float y, float size, int argb, boolean bold, boolean shadow) {
        if (Config.scriptMenu) ModernFont.CURSIVE.draw(s, x, y - size * 0.15f, sz(size), argb, shadow);
        else (bold ? ModernFont.BOLD : ModernFont.REG).draw(s, x, y, size, argb, shadow);
    }

    /** HUD text: modern font when enabled, vanilla font otherwise. */
    public static void hudText(String s, int x, int y, int argb) {
        if (Config.modernFont) ModernFont.REG.draw(s, x, y, HUD_SIZE, argb, true);
        else Minecraft.getMinecraft().fontRendererObj.drawStringWithShadow(s, x, y, argb);
    }

    public static int hudWidth(String s) {
        if (Config.modernFont) return Math.round(ModernFont.REG.width(s, HUD_SIZE));
        return Minecraft.getMinecraft().fontRendererObj.getStringWidth(s);
    }

    /** Draw a texture region tinted with a color (used for icons). */
    public static void drawTexTint(ResourceLocation loc, float x, float y, float w, float h, float u0, float v0, float u1, float v1, int argb) {
        Minecraft.getMinecraft().getTextureManager().bindTexture(loc);
        GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_MIN_FILTER, GL11.GL_LINEAR);
        GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_MAG_FILTER, GL11.GL_LINEAR);
        GlStateManager.enableTexture2D();
        GlStateManager.enableBlend();
        GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
        GlStateManager.color(((argb >> 16) & 255) / 255f, ((argb >> 8) & 255) / 255f, (argb & 255) / 255f, ((argb >>> 24) & 255) / 255f);
        WorldRenderer wr = Tessellator.getInstance().getWorldRenderer();
        wr.begin(7, DefaultVertexFormats.POSITION_TEX);
        quad(wr, x, y, x + w, y + h, u0, v0, u1, v1);
        Tessellator.getInstance().draw();
        GlStateManager.color(1f, 1f, 1f, 1f);
    }

    public static int withAlpha(int rgb, int a) { return (Math.max(0, Math.min(255, a)) << 24) | (rgb & 0xFFFFFF); }
}
