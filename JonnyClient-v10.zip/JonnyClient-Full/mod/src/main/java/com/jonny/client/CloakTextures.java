package com.jonny.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.util.ResourceLocation;

import java.awt.AlphaComposite;
import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.GradientPaint;
import java.awt.Graphics2D;
import java.awt.RadialGradientPaint;
import java.awt.RenderingHints;
import java.awt.geom.Area;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Path2D;
import java.awt.image.BufferedImage;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;

/** High-quality painted cloaks (16x res for wearing, 8x for menu previews). */
public class CloakTextures {
    public static final String[] NAMES = {
        "No cloak", "Jonny+ Black & Gold", "Jonny+ Black & Pink", "Jonny+ White", "Jonny+ Royal", "Jonny+ Neon",
        "Nebula Emblem", "Galaxy Ring", "Starry Pines", "Aurora", "Red Moon Torii", "Rainbow Wave", "Neon Grid",
        "Sunset Peaks", "Ocean Moon", "Cherry Night", "Gold Rush", "Cosmic Dust"
    };
    private static final ResourceLocation[] HQ = new ResourceLocation[NAMES.length];
    private static final ResourceLocation[] PREV = new ResourceLocation[NAMES.length];
    public static int budget = 2;
    private static final Map<Integer, BufferedImage> TINTED = new HashMap<Integer, BufferedImage>();

    public static ResourceLocation get(int idx) {
        if (idx <= 0 || idx >= NAMES.length) return null;
        if (HQ[idx] == null) HQ[idx] = make(idx, 16);
        return HQ[idx];
    }

    public static ResourceLocation preview(int idx) {
        if (idx <= 0 || idx >= NAMES.length) return null;
        if (HQ[idx] != null) return HQ[idx];
        if (PREV[idx] == null) {
            if (budget <= 0) return null;
            budget--;
            PREV[idx] = make(idx, 8);
        }
        return PREV[idx];
    }

    private static ResourceLocation make(int idx, int S) {
        int fw = 10 * S, fh = 16 * S;
        BufferedImage face = new BufferedImage(fw, fh, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g = face.createGraphics();
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
        paint(idx, g, fw, fh, S);
        g.dispose();

        BufferedImage img = new BufferedImage(64 * S, 32 * S, BufferedImage.TYPE_INT_ARGB);
        Graphics2D gg = img.createGraphics();
        gg.setColor(new Color(face.getRGB(fw / 2, fh - 2), true).darker().darker());
        gg.fillRect(0, 0, 64 * S, 32 * S);
        gg.drawImage(face, S, S, null);
        gg.drawImage(face, 12 * S, S, null);
        gg.setColor(new Color(0, 0, 0, 120));
        gg.fillRect(12 * S, S, fw, fh);
        gg.dispose();
        return Minecraft.getMinecraft().getTextureManager().getDynamicTextureLocation("jonny_cloak_" + idx + "_" + S, new DynamicTexture(img));
    }

    // ------------------------------------------------------------ painters
    private static Color c(int rgb, int a) { return new Color((rgb >> 16) & 255, (rgb >> 8) & 255, rgb & 255, a); }

    private static void sky(Graphics2D g, int w, int h, int top, int bottom) {
        g.setPaint(new GradientPaint(0, 0, c(top, 255), 0, h, c(bottom, 255)));
        g.fillRect(0, 0, w, h);
    }

    private static void nebula(Graphics2D g, int w, int h, long seed, int[] cols, int blobs, int alpha) {
        Random r = new Random(seed);
        for (int i = 0; i < blobs; i++) {
            float cx = r.nextFloat() * w, cy = r.nextFloat() * h, rad = (0.25f + 0.5f * r.nextFloat()) * w;
            int col = cols[r.nextInt(cols.length)];
            g.setPaint(new RadialGradientPaint(cx, cy, rad, new float[]{0f, 1f}, new Color[]{c(col, alpha), c(col, 0)}));
            g.fillRect(0, 0, w, h);
        }
    }

    private static void stars(Graphics2D g, int w, int h, long seed, int n, int S) {
        Random r = new Random(seed);
        for (int i = 0; i < n; i++) {
            float x = r.nextFloat() * w, y = r.nextFloat() * h, s = (0.25f + r.nextFloat() * 0.7f) * S * 0.45f;
            int a = 120 + r.nextInt(135);
            g.setColor(c(0xFFFFFF, a));
            g.fill(new Ellipse2D.Float(x - s, y - s, s * 2, s * 2));
            if (r.nextInt(7) == 0) {
                g.setStroke(new BasicStroke(Math.max(1f, S * 0.12f)));
                g.drawLine((int) (x - s * 3), (int) y, (int) (x + s * 3), (int) y);
                g.drawLine((int) x, (int) (y - s * 3), (int) x, (int) (y + s * 3));
            }
        }
    }

    private static void moon(Graphics2D g, float cx, float cy, float r, int col, float bite) {
        Area a = new Area(new Ellipse2D.Float(cx - r, cy - r, r * 2, r * 2));
        a.subtract(new Area(new Ellipse2D.Float(cx - r + r * bite, cy - r - r * 0.12f, r * 2, r * 2)));
        g.setPaint(new RadialGradientPaint(cx, cy, r * 2.4f, new float[]{0f, 1f}, new Color[]{c(col, 90), c(col, 0)}));
        g.fill(new Ellipse2D.Float(cx - r * 2.4f, cy - r * 2.4f, r * 4.8f, r * 4.8f));
        g.setColor(c(col, 255));
        g.fill(a);
    }

    private static void pines(Graphics2D g, int w, int h, long seed, int col, int n) {
        Random r = new Random(seed);
        g.setColor(c(col, 255));
        for (int i = 0; i < n; i++) {
            float x = (i + 0.5f) * w / n + (r.nextFloat() - 0.5f) * w / n * 0.5f;
            float th = h * (0.18f + r.nextFloat() * 0.16f), tw = w * 0.13f, base = h;
            for (int k = 0; k < 3; k++) {
                float yy = base - th * (0.28f * k), ww = tw * (1.2f - 0.28f * k);
                Path2D.Float p = new Path2D.Float();
                p.moveTo(x, yy - th * 0.55f); p.lineTo(x + ww, yy); p.lineTo(x - ww, yy); p.closePath();
                g.fill(p);
            }
        }
        g.fillRect(0, (int) (h * 0.93f), w, (int) (h * 0.07f) + 1);
    }

    private static void mountains(Graphics2D g, int w, int h, long seed, int[] cols) {
        Random r = new Random(seed);
        for (int layer = 0; layer < cols.length; layer++) {
            float base = h * (0.55f + 0.12f * layer);
            Path2D.Float p = new Path2D.Float();
            p.moveTo(0, h);
            for (int i = 0; i <= 8; i++) p.lineTo(i * w / 8f, base - r.nextFloat() * h * (0.22f - layer * 0.04f));
            p.lineTo(w, h); p.closePath();
            g.setColor(c(cols[layer], 255));
            g.fill(p);
        }
    }

    private static void aurora(Graphics2D g, int w, int h, int[] cols) {
        for (int k = 0; k < cols.length; k++) {
            float y0 = h * (0.22f + 0.13f * k), len = h * 0.34f, amp = h * 0.05f, ph = k * 1.7f;
            Path2D.Float p = new Path2D.Float();
            p.moveTo(0, y0 + (float) Math.sin(ph) * amp);
            for (int x = 1; x <= 40; x++) p.lineTo(x * w / 40f, y0 + (float) Math.sin(x * 0.28 + ph) * amp);
            for (int x = 40; x >= 0; x--) p.lineTo(x * w / 40f, y0 + len + (float) Math.sin(x * 0.2 + ph * 1.3) * amp * 1.4f);
            p.closePath();
            g.setPaint(new GradientPaint(0, y0, c(cols[k], 190), 0, y0 + len, c(cols[k], 0)));
            g.fill(p);
        }
    }

    private static void torii(Graphics2D g, float cx, float by, float s, int col) {
        g.setColor(c(col, 255));
        g.fillRect((int) (cx - s * 0.42f), (int) (by - s), (int) (s * 0.09f), (int) s);
        g.fillRect((int) (cx + s * 0.33f), (int) (by - s), (int) (s * 0.09f), (int) s);
        g.fillRect((int) (cx - s * 0.62f), (int) (by - s * 1.02f), (int) (s * 1.24f), (int) (s * 0.11f));
        g.fillRect((int) (cx - s * 0.5f), (int) (by - s * 0.82f), (int) (s * 1.0f), (int) (s * 0.07f));
    }

    private static BufferedImage tinted(int rgb) {
        BufferedImage cached = TINTED.get(rgb);
        if (cached != null) return cached;
        BufferedImage src = Bat.image();
        if (src == null) return null;
        BufferedImage out = new BufferedImage(src.getWidth(), src.getHeight(), BufferedImage.TYPE_INT_ARGB);
        int tr = (rgb >> 16) & 255, tg = (rgb >> 8) & 255, tb = rgb & 255;
        for (int y = 0; y < src.getHeight(); y++)
            for (int x = 0; x < src.getWidth(); x++) {
                int p = src.getRGB(x, y), a = (p >>> 24) & 255;
                if (a == 0) continue;
                float lum = Math.min(1f, (((p >> 16) & 255) + ((p >> 8) & 255) + (p & 255)) / 765f * 3.2f + 0.28f);
                out.setRGB(x, y, (a << 24) | (((int) (tr * lum)) << 16) | (((int) (tg * lum)) << 8) | (int) (tb * lum));
            }
        TINTED.put(rgb, out);
        return out;
    }

    private static void emblem(Graphics2D g, float cx, float cy, float size, int rgb) {
        g.setPaint(new RadialGradientPaint(cx, cy, size * 0.9f, new float[]{0f, 1f}, new Color[]{c(rgb, 110), c(rgb, 0)}));
        g.fill(new Ellipse2D.Float(cx - size, cy - size, size * 2, size * 2));
        BufferedImage b = tinted(rgb);
        if (b != null) g.drawImage(b, (int) (cx - size / 2), (int) (cy - size / 2), (int) size, (int) size, null);
    }

    private static void border(Graphics2D g, int w, int h, int S, int rgb) {
        g.setStroke(new BasicStroke(S * 0.35f));
        g.setColor(c(rgb, 200));
        g.drawRect((int) (S * 0.45f), (int) (S * 0.45f), w - (int) (S * 0.9f), h - (int) (S * 0.9f));
    }

    private static void paint(int idx, Graphics2D g, int w, int h, int S) {
        switch (idx) {
            case 1: sky(g, w, h, 0x0A0A0D, 0x1A1508); emblem(g, w / 2f, h * 0.46f, w * 0.78f, 0xF2B632); border(g, w, h, S, 0xF2B632); break;
            case 2: sky(g, w, h, 0x050507, 0x14070F); emblem(g, w / 2f, h * 0.46f, w * 0.78f, 0xFF2FBF); border(g, w, h, S, 0xFF2FBF); break;
            case 3: sky(g, w, h, 0xFAFAFC, 0xD8DAE2); emblem(g, w / 2f, h * 0.46f, w * 0.78f, 0x2A2A33); border(g, w, h, S, 0x2A2A33); break;
            case 4: sky(g, w, h, 0x2A0A55, 0x0E0426); nebula(g, w, h, 41, new int[]{0x8A3FD1, 0xFF6BD6}, 5, 90); emblem(g, w / 2f, h * 0.46f, w * 0.78f, 0xE9D2FF); border(g, w, h, S, 0xB98CFF); break;
            case 5: sky(g, w, h, 0x03070C, 0x04141A); emblem(g, w / 2f, h * 0.46f, w * 0.78f, 0x2FF5FF); border(g, w, h, S, 0x2FF5FF); break;
            case 6: sky(g, w, h, 0x2A0612, 0x14062E); nebula(g, w, h, 7, new int[]{0xFF2A4D, 0x7A2BFF, 0xFF7A3D, 0x3A0A7A}, 9, 140); stars(g, w, h, 8, 70, S); emblem(g, w / 2f, h * 0.4f, w * 0.72f, 0xFFFFFF); break;
            case 7: {
                sky(g, w, h, 0x07061A, 0x1A0B33); nebula(g, w, h, 12, new int[]{0x3A1B7A, 0x1B3A7A}, 4, 80); stars(g, w, h, 13, 55, S);
                g.setStroke(new BasicStroke(S * 0.9f)); g.setPaint(new GradientPaint(0, h * 0.3f, c(0xFF5CC8, 255), w, h * 0.6f, c(0x33C8FF, 255)));
                java.awt.geom.AffineTransform at = g.getTransform();
                g.rotate(-0.55, w / 2.0, h * 0.42);
                g.draw(new Ellipse2D.Float(w * 0.1f, h * 0.31f, w * 0.8f, h * 0.22f));
                g.setTransform(at);
                moon(g, w / 2f, h * 0.42f, w * 0.17f, 0xF4EFE6, 0.45f);
                g.setColor(c(0xFF5CC8, 255)); g.fill(new Ellipse2D.Float(w * 0.72f, h * 0.18f, S * 1.4f, S * 1.4f));
                break;
            }
            case 8: sky(g, w, h, 0x050B26, 0x153A5E); nebula(g, w, h, 21, new int[]{0x2B4DA0}, 3, 70); stars(g, w, h, 22, 70, S); moon(g, w * 0.72f, h * 0.2f, w * 0.1f, 0xFFF3C4, 0.4f); pines(g, w, h, 23, 0x03060F, 5); break;
            case 9: sky(g, w, h, 0x02050F, 0x06182A); stars(g, w, h, 31, 55, S); aurora(g, w, h, new int[]{0x3DFFA0, 0x2BC9FF, 0xA066FF, 0x3DFFA0}); pines(g, w, h, 32, 0x020509, 5); break;
            case 10: sky(g, w, h, 0x1A0508, 0x4A0F12); nebula(g, w, h, 33, new int[]{0x8A1A22}, 3, 80); moon(g, w / 2f, h * 0.3f, w * 0.26f, 0xFF4A3D, -0.2f); torii(g, w / 2f, h * 0.9f, w * 0.62f, 0x070204); g.setColor(c(0x070204, 255)); g.fillRect(0, (int) (h * 0.9f), w, h); break;
            case 11: {
                int[] cols = {0xFF3B3B, 0xFF9A2B, 0xFFE02B, 0x3BFF6A, 0x2BC8FF, 0x6A3BFF, 0xFF3BE0};
                for (int i = 0; i < cols.length; i++) {
                    Path2D.Float p = new Path2D.Float();
                    float y0 = h * i / (float) cols.length, bh = h / (float) cols.length + 2;
                    p.moveTo(0, y0 + (float) Math.sin(i) * S);
                    for (int x = 1; x <= 30; x++) p.lineTo(x * w / 30f, y0 + (float) Math.sin(x * 0.45 + i) * S * 1.3f);
                    for (int x = 30; x >= 0; x--) p.lineTo(x * w / 30f, y0 + bh + (float) Math.sin(x * 0.45 + i + 0.4) * S * 1.3f);
                    p.closePath(); g.setColor(c(cols[i], 255)); g.fill(p);
                }
                break;
            }
            case 12: {
                sky(g, w, h, 0x05020F, 0x1A0536);
                g.setStroke(new BasicStroke(Math.max(1f, S * 0.18f)));
                for (int i = 0; i <= 10; i++) { g.setColor(c(0x2FF5FF, 150)); g.drawLine(w / 2 + (i - 5) * w / 14, (int) (h * 0.5f), (i - 5) * w / 3 + w / 2, h); }
                for (int i = 0; i < 9; i++) { float y = h * (0.5f + 0.5f * (float) Math.pow(i / 8.0, 1.8)); g.setColor(c(0xFF3BE0, 170)); g.drawLine(0, (int) y, w, (int) y); }
                g.setPaint(new GradientPaint(0, h * 0.25f, c(0xFF3BE0, 255), 0, h * 0.5f, c(0xFFE02B, 255)));
                g.fill(new Ellipse2D.Float(w * 0.2f, h * 0.18f, w * 0.6f, w * 0.6f));
                g.setColor(c(0x05020F, 255)); g.fillRect(0, (int) (h * 0.46f), w, (int) (h * 0.04f));
                break;
            }
            case 13: sky(g, w, h, 0x2B1B6B, 0xFF7A4D); g.setColor(c(0xFFE08A, 255)); g.fill(new Ellipse2D.Float(w * 0.25f, h * 0.38f, w * 0.5f, w * 0.5f)); mountains(g, w, h, 41, new int[]{0x7A2B6B, 0x3A1550, 0x160828}); break;
            case 14: {
                sky(g, w, h, 0x050B26, 0x0E2A52); stars(g, w, h, 51, 50, S); moon(g, w * 0.5f, h * 0.27f, w * 0.17f, 0xF4EFE6, 0.4f);
                for (int i = 0; i < 7; i++) {
                    Path2D.Float p = new Path2D.Float(); float y0 = h * (0.66f + i * 0.055f);
                    p.moveTo(0, h); p.lineTo(0, y0);
                    for (int x = 1; x <= 24; x++) p.lineTo(x * w / 24f, y0 + (float) Math.sin(x * 0.6 + i * 1.4) * S * 0.9f);
                    p.lineTo(w, h); p.closePath(); g.setColor(c(i % 2 == 0 ? 0x0A2A66 : 0x061A44, 255)); g.fill(p);
                }
                break;
            }
            case 15: {
                sky(g, w, h, 0x0A1030, 0x241548); stars(g, w, h, 61, 40, S);
                g.setColor(c(0x120A1E, 255)); g.fillRect((int) (w * 0.46f), (int) (h * 0.5f), (int) (w * 0.08f), (int) (h * 0.5f));
                Random r = new Random(62);
                for (int i = 0; i < 70; i++) {
                    float x = w * 0.5f + (r.nextFloat() - 0.5f) * w * 0.9f, y = h * 0.32f + (r.nextFloat() - 0.5f) * h * 0.38f;
                    g.setColor(c(i % 3 == 0 ? 0xFF9AD5 : 0xFFC4E6, 190)); float s = S * (0.5f + r.nextFloat() * 0.9f);
                    g.fill(new Ellipse2D.Float(x - s, y - s, s * 2, s * 2));
                }
                break;
            }
            case 16: sky(g, w, h, 0xFFE08A, 0x8A5A00); emblem(g, w / 2f, h * 0.46f, w * 0.78f, 0x120A00); border(g, w, h, S, 0x120A00); break;
            case 17: sky(g, w, h, 0x0B0620, 0x14062E); nebula(g, w, h, 71, new int[]{0xFF4DB8, 0x4D7BFF, 0x4DFFC8, 0xA04DFF}, 11, 130); stars(g, w, h, 72, 80, S); break;
            default: sky(g, w, h, 0x111111, 0x333333);
        }
    }
}
