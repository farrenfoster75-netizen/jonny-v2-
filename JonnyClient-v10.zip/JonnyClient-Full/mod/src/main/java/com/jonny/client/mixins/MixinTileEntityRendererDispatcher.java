package com.jonny.client.mixins;

import com.jonny.client.Config;
import com.jonny.client.Feature;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.tileentity.TileEntityRendererDispatcher;
import net.minecraft.tileentity.TileEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(TileEntityRendererDispatcher.class)
public class MixinTileEntityRendererDispatcher {
    @Inject(method = "renderTileEntity", at = @At("HEAD"), cancellable = true, require = 0)
    private void jonny$cullTiles(TileEntity te, float partialTicks, int destroyStage, CallbackInfo ci) {
        if (!Feature.TILE_CULLING.enabled || te == null) return;
        Minecraft mc = Minecraft.getMinecraft();
        if (mc.thePlayer == null) return;
        double max = Config.qd(Config.tileDistance);
        if (mc.thePlayer.getDistanceSq(te.getPos()) > max * max) ci.cancel();
    }
}
