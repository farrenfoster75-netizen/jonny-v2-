package com.jonny.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.AbstractClientPlayer;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.WorldRenderer;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.util.ResourceLocation;

/** Draws wings, bandanas and head items on the local player (world and inventory preview). */
public class CosmeticRenderer {
    // dragon wing outline in wing space: x = outward, y = up; wide, thin, scalloped trailing edge
    private static final float[][] OUT = {
            {0.02f, 0.10f}, {0.26f, 0.21f}, {0.50f, 0.17f}, {0.78f, 0.08f}, {1.06f, -0.10f},
            {0.90f, -0.06f}, {0.90f, -0.27f}, {0.76f, -0.12f}, {0.68f, -0.34f}, {0.56f, -0.15f},
            {0.44f, -0.32f}, {0.34f, -0.12f}, {0.20f, -0.20f}, {0.04f, -0.08f}
    };
    private static final float[] CEN = {0.50f, -0.02f};
    private static final float[][] BONES = {
            {0.02f, 0.10f, 0.26f, 0.21f, 0.040f}, {0.26f, 0.21f, 0.50f, 0.17f, 0.034f},
            {0.50f, 0.17f, 1.06f, -0.10f, 0.026f}, {0.50f, 0.17f, 0.90f, -0.27f, 0.024f},
            {0.50f, 0.17f, 0.68f, -0.34f, 0.022f}, {0.50f, 0.17f, 0.44f, -0.32f, 0.020f},
            {0.50f, 0.17f, 0.20f, -0.20f, 0.018f}
    };

    public static void render(AbstractClientPlayer p, double x, double y, double z, float pt) {
        Minecraft mc = Minecraft.getMinecraft();
        if (p != mc.thePlayer || p.isInvisible()) return;
        if (Config.wingIdx <= 0 && Config.bandanaIdx <= 0 && Config.headIdx <= 0 && Config.petIdx <= 0 && Config.packIdx <= 0) return;

        float t = p.ticksExisted + pt;
        GlStateManager.pushMatrix();
        GlStateManager.translate((float) x, (float) y, (float) z);
        GlStateManager.disableLighting();
        GlStateManager.disableCull();
        GlStateManager.enableBlend();
        GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
        GlStateManager.color(1f, 1f, 1f, 1f);

        float bodyYaw = p.prevRenderYawOffset + (p.renderYawOffset - p.prevRenderYawOffset) * pt;
        boolean sneak = p.isSneaking();

        if (Config.wingIdx > 0) {
            GlStateManager.pushMatrix();
            GlStateManager.rotate(-bodyYaw, 0f, 1f, 0f);
            if (sneak) { GlStateManager.translate(0f, -0.15f, 0.05f); GlStateManager.rotate(20f, 1f, 0f, 0f); }
            drawWings(t);
            GlStateManager.popMatrix();
        }

        if (Config.packIdx > 0) {
            GlStateManager.pushMatrix();
            GlStateManager.rotate(-bodyYaw, 0f, 1f, 0f);
            if (sneak) { GlStateManager.translate(0f, -0.15f, 0.05f); GlStateManager.rotate(20f, 1f, 0f, 0f); }
            drawBackpack(Config.packIdx);
            GlStateManager.popMatrix();
        }

        if (Config.petIdx > 0) {
            GlStateManager.pushMatrix();
            double orbit = t * 0.035;
            GlStateManager.translate((float) (Math.cos(orbit) * 0.8), 1.95f + (float) Math.sin(t * 0.12f) * 0.07f, (float) (Math.sin(orbit) * 0.8));
            GlStateManager.rotate(-(float) Math.toDegrees(orbit) - 90f, 0f, 1f, 0f);
            drawPet(Config.petIdx, t);
            GlStateManager.popMatrix();
        }

        if (Config.bandanaIdx > 0 || Config.headIdx > 0) {
            float hy = p.prevRotationYawHead + (p.rotationYawHead - p.prevRotationYawHead) * pt;
            float hp = p.prevRotationPitch + (p.rotationPitch - p.prevRotationPitch) * pt;
            GlStateManager.pushMatrix();
            GlStateManager.rotate(-hy, 0f, 1f, 0f);
            GlStateManager.translate(0f, sneak ? 1.24f : 1.42f, sneak ? 0.07f : 0f);
            GlStateManager.rotate(hp, 1f, 0f, 0f);
            GlStateManager.translate(0f, 0.25f, 0f);
            if (Config.bandanaIdx > 0) drawBandana(t);
            if (Config.headIdx > 0) drawHeadItem(Config.headIdx, t);
            GlStateManager.popMatrix();
        }

        GlStateManager.enableCull();
        GlStateManager.enableTexture2D();
        GlStateManager.disableBlend();
        GlStateManager.enableLighting();
        GlStateManager.color(1f, 1f, 1f, 1f);
        GlStateManager.popMatrix();
    }

    // ------------------------------------------------------------ wings
    private static void drawWings(float t) {
        int idx = Config.wingIdx;
        boolean feathered = WingTextures.feathered(idx);
        float flap = (float) Math.sin(t * 0.07f);           // slow flap, ~4.5 seconds
        for (int side = -1; side <= 1; side += 2) {
            GlStateManager.pushMatrix();
            GlStateManager.translate(0.06f * side, 1.37f, -0.15f);
            GlStateManager.scale((float) side, 1f, 1f);
            if (feathered) {
                GlStateManager.rotate(18f + flap * 12f, 0f, 1f, 0f);
                GlStateManager.rotate(8f + flap * 8f, 0f, 0f, 1f);
                drawFeathered(idx);
            } else {
                GlStateManager.rotate(14f + flap * 9f, 0f, 1f, 0f);    // sweep back
                GlStateManager.rotate(-8f + flap * 6f, 0f, 0f, 1f);    // tips droop / lift
                GlStateManager.scale(1.05f, 1.05f, 1.05f);
                drawDragon(idx);
            }
            GlStateManager.popMatrix();
        }
    }

    private static void vert(WorldRenderer wr, float x, float y) {
        float u = Math.max(0f, Math.min(1f, x / 1.1f));
        float v = Math.max(0f, Math.min(1f, (0.26f - y) / 0.62f));
        wr.pos(x, y, 0).tex(u, v).endVertex();
    }

    private static void drawDragon(int idx) {
        ResourceLocation tex = WingTextures.get(idx);
        if (tex == null) return;
        boolean skel = WingTextures.skeleton(idx);
        Minecraft.getMinecraft().getTextureManager().bindTexture(tex);
        org.lwjgl.opengl.GL11.glTexParameteri(org.lwjgl.opengl.GL11.GL_TEXTURE_2D, org.lwjgl.opengl.GL11.GL_TEXTURE_MIN_FILTER, org.lwjgl.opengl.GL11.GL_LINEAR);
        org.lwjgl.opengl.GL11.glTexParameteri(org.lwjgl.opengl.GL11.GL_TEXTURE_2D, org.lwjgl.opengl.GL11.GL_TEXTURE_MAG_FILTER, org.lwjgl.opengl.GL11.GL_LINEAR);
        GlStateManager.enableTexture2D();
        GlStateManager.color(1f, 1f, 1f, skel ? 0.22f : 1f);
        WorldRenderer wr = Tessellator.getInstance().getWorldRenderer();
        wr.begin(4, DefaultVertexFormats.POSITION_TEX);
        for (int i = 0; i < OUT.length; i++) {
            float[] a = OUT[i], b = OUT[(i + 1) % OUT.length];
            vert(wr, CEN[0], CEN[1]);
            vert(wr, a[0], a[1]);
            vert(wr, b[0], b[1]);
        }
        Tessellator.getInstance().draw();
        GlStateManager.color(1f, 1f, 1f, 1f);

        GlStateManager.disableTexture2D();
        int col = WingTextures.boneColor(idx);
        float thick = skel ? 1.9f : 1f;
        wr = Tessellator.getInstance().getWorldRenderer();
        wr.begin(4, DefaultVertexFormats.POSITION_COLOR);
        for (float[] bone : BONES) {
            float dx = bone[2] - bone[0], dy = bone[3] - bone[1];
            float len = (float) Math.sqrt(dx * dx + dy * dy);
            float wd = bone[4] * thick;
            float nx = -dy / len * wd / 2f, ny = dx / len * wd / 2f;
            for (int face = -1; face <= 1; face += 2) {
                float zz = 0.004f * face;
                quadC(wr, bone[0] - nx, bone[1] - ny, zz, bone[0] + nx, bone[1] + ny, zz, bone[2] + nx, bone[3] + ny, zz, bone[2] - nx, bone[3] - ny, zz, col, 255);
            }
        }
        Tessellator.getInstance().draw();
        GlStateManager.enableTexture2D();
    }

    private static int[] featherColors(int idx, int row, float t) {
        // returns {rootRGB, tipRGB}
        if (idx == WingIdx.ANGEL) return row == 0 ? new int[]{0xFFFFFF, 0xDDE6F5} : (row == 1 ? new int[]{0xFAFBFF, 0xE8EEF9} : new int[]{0xFFFFFF, 0xF4F7FC});
        if (idx == WingIdx.BW) return row == 0 ? new int[]{0x0B0B0F, 0x2A2A33} : (row == 1 ? new int[]{0xF2F2F5, 0xD0D0D8} : new int[]{0x15151A, 0x3A3A44});
        return row == 0 ? new int[]{0xFF3B00, 0xFFD000} : (row == 1 ? new int[]{0xFF6A00, 0xFFB300} : new int[]{0xFF8A00, 0xFFE066});
    }

    private static void drawFeathered(int idx) {
        GlStateManager.disableTexture2D();
        WorldRenderer wr = Tessellator.getInstance().getWorldRenderer();
        wr.begin(4, DefaultVertexFormats.POSITION_COLOR);
        int[][] rows = {{9, 0}, {7, 1}, {6, 2}};      // count, row index
        for (int[] row : rows) {
            int n = row[0], r = row[1];
            int[] cols = featherColors(idx, r, 0);
            for (int i = 0; i < n; i++) {
                float f = n == 1 ? 0f : i / (float) (n - 1);
                float ang = (float) Math.toRadians(r == 0 ? 92 - 84 * f : (r == 1 ? 74 - 78 * f : 60 - 70 * f));
                float len = (r == 0 ? 0.80f + 0.36f * (float) Math.sin(Math.PI * f) : (r == 1 ? 0.52f - 0.08f * f : 0.30f - 0.05f * f));
                float wd = r == 0 ? 0.11f : (r == 1 ? 0.10f : 0.09f);
                float z = 0.003f * r;
                float[] p0 = {0.02f, 0.02f};
                float cx = (float) Math.cos(ang), sy = (float) Math.sin(ang);
                float ang2 = ang - 0.10f;
                float[] pm = {p0[0] + cx * len * 0.55f, p0[1] + sy * len * 0.55f};
                float[] pt = {pm[0] + (float) Math.cos(ang2) * len * 0.45f, pm[1] + (float) Math.sin(ang2) * len * 0.45f};
                float nx0 = -sy * wd / 2f, ny0 = cx * wd / 2f;
                float nx1 = -(float) Math.sin(ang - 0.05f) * wd * 0.30f, ny1 = (float) Math.cos(ang - 0.05f) * wd * 0.30f;
                float nx2 = -(float) Math.sin(ang2) * wd * 0.05f, ny2 = (float) Math.cos(ang2) * wd * 0.05f;
                for (int face = -1; face <= 1; face += 2) {
                    float zz = z * face + 0.002f * face;
                    triC(wr, p0[0] - nx0, p0[1] - ny0, zz, p0[0] + nx0, p0[1] + ny0, zz, pm[0] + nx1, pm[1] + ny1, zz, cols[0], cols[0], mixRgb(cols[0], cols[1], .5f));
                    triC(wr, p0[0] - nx0, p0[1] - ny0, zz, pm[0] + nx1, pm[1] + ny1, zz, pm[0] - nx1, pm[1] - ny1, zz, cols[0], mixRgb(cols[0], cols[1], .5f), mixRgb(cols[0], cols[1], .5f));
                    triC(wr, pm[0] - nx1, pm[1] - ny1, zz, pm[0] + nx1, pm[1] + ny1, zz, pt[0] + nx2, pt[1] + ny2, zz, mixRgb(cols[0], cols[1], .5f), mixRgb(cols[0], cols[1], .5f), cols[1]);
                    triC(wr, pm[0] - nx1, pm[1] - ny1, zz, pt[0] + nx2, pt[1] + ny2, zz, pt[0] - nx2, pt[1] - ny2, zz, mixRgb(cols[0], cols[1], .5f), cols[1], cols[1]);
                }
            }
        }
        Tessellator.getInstance().draw();
        GlStateManager.enableTexture2D();
    }

    /** Indexes of feathered wing styles (see WingTextures). */
    private static final class WingIdx { static final int ANGEL = 11, BW = 12; }

    // ------------------------------------------------------------ bandana
    private static void drawBandana(float t) {
        ResourceLocation tex = BandanaTextures.get(Config.bandanaIdx);
        if (tex == null) return;
        Minecraft.getMinecraft().getTextureManager().bindTexture(tex);
        org.lwjgl.opengl.GL11.glTexParameteri(org.lwjgl.opengl.GL11.GL_TEXTURE_2D, org.lwjgl.opengl.GL11.GL_TEXTURE_MIN_FILTER, 9728);
        org.lwjgl.opengl.GL11.glTexParameteri(org.lwjgl.opengl.GL11.GL_TEXTURE_2D, org.lwjgl.opengl.GL11.GL_TEXTURE_MAG_FILTER, 9728);
        GlStateManager.enableTexture2D();
        GlStateManager.color(1f, 1f, 1f, 1f);
        float hs = 0.268f, y0 = 0.035f, y1 = 0.165f;
        WorldRenderer wr = Tessellator.getInstance().getWorldRenderer();
        wr.begin(7, DefaultVertexFormats.POSITION_TEX);
        // front, back, left, right
        texQuad(wr, -hs, y0, hs, hs, y0, hs, hs, y1, hs, -hs, y1, hs, 0f, 1f);
        texQuad(wr, hs, y0, -hs, -hs, y0, -hs, -hs, y1, -hs, hs, y1, -hs, 0f, 1f);
        texQuad(wr, hs, y0, hs, hs, y0, -hs, hs, y1, -hs, hs, y1, hs, 0f, 1f);
        texQuad(wr, -hs, y0, -hs, -hs, y0, hs, -hs, y1, hs, -hs, y1, -hs, 0f, 1f);
        // knot tails at the back
        float sway = (float) Math.sin(t * 0.12f) * 0.025f;
        texQuad(wr, 0.00f, y1 - 0.01f, -hs - 0.004f, 0.08f + sway, y1 - 0.01f, -hs - 0.004f, 0.10f + sway, y0 - 0.20f, -hs - 0.004f, 0.02f, y0 - 0.20f, -hs - 0.004f, 0f, 1f);
        texQuad(wr, -0.08f - sway, y1 - 0.01f, -hs - 0.004f, 0.00f, y1 - 0.01f, -hs - 0.004f, -0.02f, y0 - 0.22f, -hs - 0.004f, -0.10f - sway, y0 - 0.22f, -hs - 0.004f, 0f, 1f);
        Tessellator.getInstance().draw();
    }

    private static void texQuad(WorldRenderer wr, float x1, float y1, float z1, float x2, float y2, float z2, float x3, float y3, float z3, float x4, float y4, float z4, float v0, float v1) {
        wr.pos(x1, y1, z1).tex(0, v1).endVertex();
        wr.pos(x2, y2, z2).tex(1, v1).endVertex();
        wr.pos(x3, y3, z3).tex(1, v0).endVertex();
        wr.pos(x4, y4, z4).tex(0, v0).endVertex();
    }

    // ------------------------------------------------------------ head items
    private static void drawHeadItem(int idx, float t) {
        GlStateManager.disableTexture2D();
        WorldRenderer wr = Tessellator.getInstance().getWorldRenderer();
        wr.begin(4, DefaultVertexFormats.POSITION_COLOR);
        switch (idx) {
            case 1: { // gold crown
                int g = 0xFFC933;
                box(wr, -0.27f, 0.24f, 0.25f, 0.27f, 0.33f, 0.28f, g, 255);
                box(wr, -0.27f, 0.24f, -0.28f, 0.27f, 0.33f, -0.25f, g, 255);
                box(wr, -0.28f, 0.24f, -0.25f, -0.25f, 0.33f, 0.25f, g, 255);
                box(wr, 0.25f, 0.24f, -0.25f, 0.28f, 0.33f, 0.25f, g, 255);
                float[][] sp = {{-0.18f, 0.265f}, {0f, 0.265f}, {0.18f, 0.265f}, {-0.18f, -0.265f}, {0f, -0.265f}, {0.18f, -0.265f},
                        {0.265f, 0f}, {-0.265f, 0f}, {0.265f, 0.15f}, {-0.265f, 0.15f}, {0.265f, -0.15f}, {-0.265f, -0.15f}};
                for (float[] s : sp) pyramid(wr, s[0], 0.33f, s[1], 0.045f, 0.12f, s[0], s[1], g);
                box(wr, -0.025f, 0.255f, 0.28f, 0.025f, 0.305f, 0.292f, 0xE53935, 255);
                box(wr, -0.20f, 0.265f, 0.28f, -0.16f, 0.30f, 0.292f, 0x3D5AFE, 255);
                box(wr, 0.16f, 0.265f, 0.28f, 0.20f, 0.30f, 0.292f, 0x3D5AFE, 255);
                break;
            }
            case 2: { // halo
                float bob = (float) Math.sin(t * 0.08f) * 0.02f;
                ring(wr, 0.28f, 0.46f + bob, 0.018f, 0xFFE680, 240);
                ring(wr, 0.28f, 0.46f + bob, 0.045f, 0xFFD24D, 70);
                break;
            }
            case 3: { // shades
                box(wr, -0.215f, -0.07f, 0.252f, -0.035f, 0.03f, 0.264f, 0x050505, 240);
                box(wr, 0.035f, -0.07f, 0.252f, 0.215f, 0.03f, 0.264f, 0x050505, 240);
                box(wr, -0.235f, 0.03f, 0.252f, 0.235f, 0.052f, 0.266f, 0xF2B632, 255);
                box(wr, -0.035f, -0.01f, 0.252f, 0.035f, 0.02f, 0.264f, 0xF2B632, 255);
                box(wr, 0.236f, -0.01f, -0.20f, 0.252f, 0.03f, 0.264f, 0x111111, 255);
                box(wr, -0.252f, -0.01f, -0.20f, -0.236f, 0.03f, 0.264f, 0x111111, 255);
                break;
            }
            case 4: { // headphones
                int band = 0x15151A;
                for (int i = 0; i < 14; i++) {
                    double a0 = Math.PI * i / 14.0, a1 = Math.PI * (i + 1) / 14.0;
                    float x0 = (float) (0.285 * Math.cos(a0)), yA = (float) (0.02 + 0.30 * Math.sin(a0));
                    float x1 = (float) (0.285 * Math.cos(a1)), yB = (float) (0.02 + 0.30 * Math.sin(a1));
                    quadC(wr, x0, yA, -0.03f, x1, yB, -0.03f, x1, yB, 0.03f, x0, yA, 0.03f, band, 255);
                    quadC(wr, x0, yA + 0.025f, -0.03f, x1, yB + 0.025f, -0.03f, x1, yB + 0.025f, 0.03f, x0, yA + 0.025f, 0.03f, band, 255);
                }
                for (int side = -1; side <= 1; side += 2) {
                    float xa = 0.25f * side, xb = 0.36f * side;
                    box(wr, Math.min(xa, xb), -0.10f, -0.10f, Math.max(xa, xb), 0.12f, 0.10f, 0x101014, 255);
                    box(wr, Math.min(xa, xb) * 1.0f, -0.02f, -0.105f, Math.max(xa, xb), 0.03f, 0.105f, 0xF2B632, 255);
                }
                break;
            }
            case 5: { // cat ears
                for (int side = -1; side <= 1; side += 2) {
                    float cx = 0.15f * side;
                    tri3(wr, cx - 0.09f, 0.25f, 0f, cx + 0.09f, 0.25f, 0f, cx + 0.03f * side, 0.45f, 0f, 0x1B1B22, 255, 0.02f);
                    tri3(wr, cx - 0.05f, 0.25f, 0.012f, cx + 0.05f, 0.25f, 0.012f, cx + 0.02f * side, 0.38f, 0.012f, 0xFF8FB8, 255, 0.0f);
                }
                break;
            }
            case 6: { // devil horns
                for (int side = -1; side <= 1; side += 2)
                    pyramid(wr, 0.14f * side, 0.25f, 0.02f, 0.05f, 0.18f, 0.21f * side, 0.02f, 0xD01818);
                break;
            }
            case 7: { // top hat
                box(wr, -0.34f, 0.25f, -0.34f, 0.34f, 0.285f, 0.34f, 0x0E0E12, 255);
                box(wr, -0.22f, 0.285f, -0.22f, 0.22f, 0.56f, 0.22f, 0x0E0E12, 255);
                box(wr, -0.226f, 0.30f, -0.226f, 0.226f, 0.35f, 0.226f, 0xF2B632, 255);
                break;
            }
            case 8: { // party hat
                int[] cs = {0xFF4D9D, 0x39D0FF, 0xFFE14D, 0xA66BFF};
                float bx = 0.17f, by = 0.25f, ty = 0.66f;
                float[][] c = {{-bx, bx}, {bx, bx}, {bx, -bx}, {-bx, -bx}};
                for (int i = 0; i < 4; i++) {
                    float[] a = c[i], b = c[(i + 1) % 4];
                    tri3(wr, a[0], by, a[1], b[0], by, b[1], 0.02f, ty, 0f, cs[i], 255, 0f);
                }
                box(wr, -0.035f, ty - 0.01f, -0.035f, 0.055f, ty + 0.07f, 0.035f, 0xFFFFFF, 255);
                break;
            }
            case 9: case 10: { // bows
                int col = idx == 9 ? 0xFF2FA8 : 0xF2B632;
                float bx = 0.17f, by = 0.30f;
                tri3(wr, bx, by, 0f, bx + 0.13f, by + 0.09f, 0f, bx + 0.13f, by - 0.09f, 0f, col, 255, 0.02f);
                tri3(wr, bx, by, 0f, bx - 0.13f, by + 0.09f, 0f, bx - 0.13f, by - 0.09f, 0f, shade(col, .85f), 255, 0.02f);
                box(wr, bx - 0.03f, by - 0.03f, -0.025f, bx + 0.03f, by + 0.03f, 0.025f, shade(col, .7f), 255);
                break;
            }
            case 11: { // wizard hat
                box(wr, -0.36f, 0.25f, -0.36f, 0.36f, 0.278f, 0.36f, 0x2A1B5E, 255);
                pyramid(wr, 0f, 0.278f, 0f, 0.22f, 0.58f, 0.06f, -0.08f, 0x3A2680);
                box(wr, -0.225f, 0.29f, -0.225f, 0.225f, 0.33f, 0.225f, 0xF2B632, 255);
                box(wr, 0.05f, 0.42f, 0.17f, 0.09f, 0.46f, 0.18f, 0xFFE08A, 255);
                box(wr, -0.12f, 0.52f, 0.12f, -0.09f, 0.55f, 0.13f, 0xFFE08A, 255);
                break;
            }
            default: break;
        }
        Tessellator.getInstance().draw();
        GlStateManager.enableTexture2D();
    }

    // ------------------------------------------------------------ backpacks
    private static void drawBackpack(int idx) {
        GlStateManager.disableTexture2D();
        WorldRenderer wr = Tessellator.getInstance().getWorldRenderer();
        wr.begin(4, DefaultVertexFormats.POSITION_COLOR);
        int main = idx == 1 ? 0x15151B : (idx == 2 ? 0xC9951A : 0x4A5D2A);
        int acc = idx == 1 ? 0xF2B632 : (idx == 2 ? 0x15151B : 0x2F3D1A);
        box(wr, -0.20f, 0.80f, -0.34f, 0.20f, 1.30f, -0.14f, main, 255);
        box(wr, -0.20f, 1.14f, -0.345f, 0.20f, 1.31f, -0.13f, shade(main, .82f), 255);
        box(wr, -0.14f, 0.86f, -0.37f, 0.14f, 1.02f, -0.34f, acc, 255);
        box(wr, -0.02f, 1.18f, -0.355f, 0.02f, 1.24f, -0.34f, 0xF2B632, 255);
        for (int s = -1; s <= 1; s += 2) {
            float x0 = s > 0 ? 0.09f : -0.15f, x1 = s > 0 ? 0.15f : -0.09f;
            box(wr, x0, 1.50f, -0.14f, x1, 1.53f, 0.13f, acc, 255);
            box(wr, x0, 1.00f, 0.125f, x1, 1.53f, 0.14f, acc, 255);
        }
        if (idx == 3) {
            box(wr, -0.17f, 0.90f, -0.345f, -0.07f, 1.05f, -0.335f, 0x2F3D1A, 255);
            box(wr, 0.02f, 1.00f, -0.345f, 0.15f, 1.18f, -0.335f, 0x6B7F3A, 255);
            box(wr, -0.12f, 1.15f, -0.345f, -0.02f, 1.27f, -0.335f, 0x6B7F3A, 255);
        }
        Tessellator.getInstance().draw();
        GlStateManager.enableTexture2D();
    }

    // ------------------------------------------------------------ pets (front = +Z)
    private static void drawPet(int idx, float t) {
        GlStateManager.disableTexture2D();
        WorldRenderer wr = Tessellator.getInstance().getWorldRenderer();
        wr.begin(4, DefaultVertexFormats.POSITION_COLOR);
        float flap = (float) Math.sin(t * 0.55f);
        switch (idx) {
            case 1: { // mini bat
                int body = 0x1D1D24, w1 = 0x2E2E3A, w2 = 0x40404F;
                box(wr, -0.05f, -0.05f, -0.07f, 0.05f, 0.04f, 0.05f, body, 255);
                box(wr, -0.045f, -0.02f, 0.04f, 0.045f, 0.06f, 0.12f, body, 255);
                pyramid(wr, -0.03f, 0.06f, 0.09f, 0.02f, 0.07f, -0.03f, 0.09f, body);
                pyramid(wr, 0.03f, 0.06f, 0.09f, 0.02f, 0.07f, 0.03f, 0.09f, body);
                box(wr, -0.03f, 0.02f, 0.12f, -0.012f, 0.04f, 0.126f, 0xFF2020, 255);
                box(wr, 0.012f, 0.02f, 0.12f, 0.03f, 0.04f, 0.126f, 0xFF2020, 255);
                for (int s = -1; s <= 1; s += 2) {
                    float tipY = 0.10f + flap * 0.14f;
                    v(wr, s * 0.05f, 0.02f, -0.01f, w1, 255); v(wr, s * 0.30f, tipY, -0.04f, w2, 255); v(wr, s * 0.05f, -0.03f, -0.07f, w1, 255);
                    v(wr, s * 0.05f, -0.03f, -0.07f, w1, 255); v(wr, s * 0.30f, tipY, -0.04f, w2, 255); v(wr, s * 0.24f, tipY - 0.11f, -0.10f, w2, 255);
                    v(wr, s * 0.05f, 0.02f, -0.01f, w1, 255); v(wr, s * 0.05f, -0.03f, -0.07f, w1, 255); v(wr, s * 0.30f, tipY, -0.04f, w2, 255);
                    v(wr, s * 0.05f, -0.03f, -0.07f, w1, 255); v(wr, s * 0.24f, tipY - 0.11f, -0.10f, w2, 255); v(wr, s * 0.30f, tipY, -0.04f, w2, 255);
                }
                break;
            }
            case 2: { // slime
                box(wr, -0.09f, -0.09f, -0.09f, 0.09f, 0.09f, 0.09f, 0x4CFF6B, 150);
                box(wr, -0.05f, -0.05f, -0.05f, 0.05f, 0.05f, 0.05f, 0x1FAA3A, 225);
                box(wr, -0.05f, 0.0f, 0.092f, -0.02f, 0.04f, 0.1f, 0x0A0A0A, 255);
                box(wr, 0.02f, 0.0f, 0.092f, 0.05f, 0.04f, 0.1f, 0x0A0A0A, 255);
                break;
            }
            case 3: { // orb
                int col = (((int) (127 + 127 * Math.sin(t * 0.05))) << 16) | (((int) (127 + 127 * Math.sin(t * 0.05 + 2.1))) << 8) | (int) (127 + 127 * Math.sin(t * 0.05 + 4.2));
                GlStateManager.rotate(t * 4f, 0f, 1f, 0f);
                pyramid(wr, 0f, 0f, 0f, 0.09f, 0.12f, 0f, 0f, col);
                pyramid(wr, 0f, 0f, 0f, 0.09f, -0.12f, 0f, 0f, col);
                ring(wr, 0.16f, 0f, 0.008f, col, 130);
                break;
            }
            default: { // goldfish
                GlStateManager.rotate((float) Math.sin(t * 0.4f) * 12f, 0f, 1f, 0f);
                box(wr, -0.04f, -0.05f, -0.10f, 0.04f, 0.05f, 0.07f, 0xFF9A1F, 255);
                box(wr, -0.005f, -0.07f, -0.18f, 0.005f, 0.07f, -0.10f, 0xFFB347, 255);
                box(wr, -0.005f, 0.05f, -0.06f, 0.005f, 0.11f, 0.02f, 0xFFB347, 255);
                box(wr, 0.04f, 0.01f, 0.03f, 0.046f, 0.035f, 0.05f, 0x101010, 255);
                box(wr, -0.046f, 0.01f, 0.03f, -0.04f, 0.035f, 0.05f, 0x101010, 255);
            }
        }
        Tessellator.getInstance().draw();
        GlStateManager.enableTexture2D();
    }

    // ------------------------------------------------------------ geometry helpers (triangle mode, vertex colors)
    private static int mixRgb(int a, int b, float f) {
        int r = (int) (((a >> 16) & 255) * (1 - f) + ((b >> 16) & 255) * f);
        int g = (int) (((a >> 8) & 255) * (1 - f) + ((b >> 8) & 255) * f);
        int bl = (int) ((a & 255) * (1 - f) + (b & 255) * f);
        return (r << 16) | (g << 8) | bl;
    }

    private static void v(WorldRenderer wr, float x, float y, float z, int rgb, int a) {
        wr.pos(x, y, z).color((rgb >> 16) & 255, (rgb >> 8) & 255, rgb & 255, a).endVertex();
    }

    private static void triC(WorldRenderer wr, float x1, float y1, float z1, float x2, float y2, float z2, float x3, float y3, float z3, int c1, int c2, int c3) {
        v(wr, x1, y1, z1, c1, 255); v(wr, x2, y2, z2, c2, 255); v(wr, x3, y3, z3, c3, 255);
    }

    /** Quad as two triangles. */
    private static void quadC(WorldRenderer wr, float x1, float y1, float z1, float x2, float y2, float z2, float x3, float y3, float z3, float x4, float y4, float z4, int rgb, int a) {
        v(wr, x1, y1, z1, rgb, a); v(wr, x2, y2, z2, rgb, a); v(wr, x3, y3, z3, rgb, a);
        v(wr, x1, y1, z1, rgb, a); v(wr, x3, y3, z3, rgb, a); v(wr, x4, y4, z4, rgb, a);
    }

    private static int shade(int rgb, float f) {
        return (((int) (((rgb >> 16) & 255) * f)) << 16) | (((int) (((rgb >> 8) & 255) * f)) << 8) | (int) ((rgb & 255) * f);
    }

    private static void box(WorldRenderer wr, float x0, float y0, float z0, float x1, float y1, float z1, int rgb, int a) {
        quadC(wr, x0, y1, z0, x1, y1, z0, x1, y1, z1, x0, y1, z1, rgb, a);                    // top
        quadC(wr, x0, y0, z1, x1, y0, z1, x1, y0, z0, x0, y0, z0, shade(rgb, .55f), a);       // bottom
        quadC(wr, x0, y0, z1, x1, y0, z1, x1, y1, z1, x0, y1, z1, shade(rgb, .85f), a);       // front
        quadC(wr, x1, y0, z0, x0, y0, z0, x0, y1, z0, x1, y1, z0, shade(rgb, .80f), a);       // back
        quadC(wr, x0, y0, z0, x0, y0, z1, x0, y1, z1, x0, y1, z0, shade(rgb, .70f), a);       // left
        quadC(wr, x1, y0, z1, x1, y0, z0, x1, y1, z0, x1, y1, z1, shade(rgb, .70f), a);       // right
    }

    private static void pyramid(WorldRenderer wr, float cx, float by, float cz, float half, float height, float ax, float az, int rgb) {
        float x0 = cx - half, x1 = cx + half, z0 = cz - half, z1 = cz + half, ty = by + height;
        float apx = ax, apz = az;
        v(wr, x0, by, z1, shade(rgb, .85f), 255); v(wr, x1, by, z1, shade(rgb, .85f), 255); v(wr, apx, ty, apz, rgb, 255);
        v(wr, x1, by, z0, shade(rgb, .8f), 255); v(wr, x0, by, z0, shade(rgb, .8f), 255); v(wr, apx, ty, apz, rgb, 255);
        v(wr, x0, by, z0, shade(rgb, .7f), 255); v(wr, x0, by, z1, shade(rgb, .7f), 255); v(wr, apx, ty, apz, rgb, 255);
        v(wr, x1, by, z1, shade(rgb, .7f), 255); v(wr, x1, by, z0, shade(rgb, .7f), 255); v(wr, apx, ty, apz, rgb, 255);
    }

    private static void tri3(WorldRenderer wr, float x1, float y1, float z1, float x2, float y2, float z2, float x3, float y3, float z3, int rgb, int a, float thick) {
        v(wr, x1, y1, z1 + thick, rgb, a); v(wr, x2, y2, z2 + thick, rgb, a); v(wr, x3, y3, z3 + thick, rgb, a);
        v(wr, x2, y2, z2 - thick, shade(rgb, .8f), a); v(wr, x1, y1, z1 - thick, shade(rgb, .8f), a); v(wr, x3, y3, z3 - thick, shade(rgb, .8f), a);
    }

    private static void ring(WorldRenderer wr, float radius, float y, float halfWidth, int rgb, int a) {
        int n = 28;
        for (int i = 0; i < n; i++) {
            double a0 = 2 * Math.PI * i / n, a1 = 2 * Math.PI * (i + 1) / n;
            float ix0 = (float) ((radius - halfWidth) * Math.cos(a0)), iz0 = (float) ((radius - halfWidth) * Math.sin(a0));
            float ox0 = (float) ((radius + halfWidth) * Math.cos(a0)), oz0 = (float) ((radius + halfWidth) * Math.sin(a0));
            float ix1 = (float) ((radius - halfWidth) * Math.cos(a1)), iz1 = (float) ((radius - halfWidth) * Math.sin(a1));
            float ox1 = (float) ((radius + halfWidth) * Math.cos(a1)), oz1 = (float) ((radius + halfWidth) * Math.sin(a1));
            quadC(wr, ix0, y, iz0, ox0, y, oz0, ox1, y, oz1, ix1, y, iz1, rgb, a);
        }
    }
}
