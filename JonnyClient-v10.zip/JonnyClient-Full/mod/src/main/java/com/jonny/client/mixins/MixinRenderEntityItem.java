package com.jonny.client.mixins;

import com.jonny.client.Config;
import com.jonny.client.Feature;
import com.jonny.client.Stats;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.entity.RenderEntityItem;
import net.minecraft.entity.item.EntityItem;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Dropped items: distance limit + per-frame budget (bedwars generators spawn piles). */
@Mixin(RenderEntityItem.class)
public class MixinRenderEntityItem {
    @Inject(method = "doRender(Lnet/minecraft/entity/item/EntityItem;DDDFF)V", at = @At("HEAD"), cancellable = true, require = 0)
    private void jonny$items(EntityItem e, double x, double y, double z, float yaw, float pt, CallbackInfo ci) {
        if (!Feature.ITEM_LOD.enabled) return;
        Minecraft mc = Minecraft.getMinecraft();
        if (mc.thePlayer == null) return;
        double max = Config.qd(Config.itemDistance);
        if (mc.thePlayer.getDistanceSqToEntity(e) > max * max || ++Stats.itemsThisFrame > Config.qd(Config.itemBudget)) ci.cancel();
    }
}
