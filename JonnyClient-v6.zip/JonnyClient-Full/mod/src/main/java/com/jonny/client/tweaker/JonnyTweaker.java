package com.jonny.client.tweaker;

import net.minecraft.launchwrapper.ITweaker;
import net.minecraft.launchwrapper.LaunchClassLoader;
import org.spongepowered.asm.launch.MixinBootstrap;
import org.spongepowered.asm.mixin.MixinEnvironment;
import org.spongepowered.asm.mixin.Mixins;

import java.io.File;
import java.lang.reflect.Method;
import java.net.URL;
import java.security.CodeSource;
import java.util.List;

/** Boots Mixin early, then lets Forge still load this jar as a normal mod. */
public class JonnyTweaker implements ITweaker {
    @Override
    public void acceptOptions(List<String> args, File gameDir, File assetsDir, String profile) {}

    @SuppressWarnings("unchecked")
    @Override
    public void injectIntoClassLoader(LaunchClassLoader classLoader) {
        MixinBootstrap.init();
        Mixins.addConfiguration("mixins.jonnyclient.json");
        MixinEnvironment.getDefaultEnvironment().setObfuscationContext("searge");
        MixinEnvironment.getDefaultEnvironment().setSide(MixinEnvironment.Side.CLIENT);

        // A jar with a TweakClass is treated as a coremod and skipped as a mod. Remove it from
        // the ignore list so @Mod classes in this same jar still load.
        try {
            CodeSource cs = getClass().getProtectionDomain().getCodeSource();
            Class<?> mgr = Class.forName("net.minecraftforge.fml.relauncher.CoreModManager");
            Method ignored = null;
            try { ignored = mgr.getDeclaredMethod("getIgnoredMods"); } catch (NoSuchMethodException ignore) {}
            if (ignored == null) {
                try { ignored = mgr.getDeclaredMethod("getLoadedCoremods"); } catch (NoSuchMethodException ignore) {}
            }
            if (cs != null && ignored != null) {
                URL loc = cs.getLocation();
                File file = new File(loc.toURI());
                if (file.isFile()) ((List<String>) ignored.invoke(null)).remove(file.getName());
            }
        } catch (Throwable t) {
            t.printStackTrace();
        }
    }

    @Override
    public String getLaunchTarget() { return "net.minecraft.client.main.Main"; }

    @Override
    public String[] getLaunchArguments() { return new String[0]; }
}
