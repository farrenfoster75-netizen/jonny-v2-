package com.jonny.client;

import net.minecraft.client.gui.GuiScreen;

import java.io.IOException;

public class HudEditor extends GuiScreen {
    private HudMod dragMod;
    private int offX, offY;

    private void outline(int x, int y, int w, int h, int c) {
        drawRect(x - 1, y - 1, x + w + 1, y, c);
        drawRect(x - 1, y + h, x + w + 1, y + h + 1, c);
        drawRect(x - 1, y, x, y + h, c);
        drawRect(x + w, y, x + w + 1, y + h, c);
    }

    @Override
    public void drawScreen(int mx, int my, float pt) {
        drawRect(0, 0, width, height, 0x99000000);
        Hud.drawAll(true);
        int col = 0xFF000000 | UI.accent();
        for (HudMod m : HudMods.ALL) {
            if (!m.enabled) continue;
            outline(m.x, m.y, Math.max(8, m.sw()), Math.max(8, m.sh()), m == dragMod ? 0xFFFFFFFF : col);
        }
        String msg = "Drag HUD elements anywhere. ESC to go back.";
        float tw = UI.width(msg, 11f, true);
        UI.text(msg, (width - tw) / 2f, 12, 11f, 0xFFFFFFFF, true, true);
        super.drawScreen(mx, my, pt);
    }

    @Override
    protected void mouseClicked(int mx, int my, int btn) throws IOException {
        super.mouseClicked(mx, my, btn);
        if (btn != 0) return;
        for (int i = HudMods.ALL.size() - 1; i >= 0; i--) {
            HudMod m = HudMods.ALL.get(i);
            if (!m.enabled) continue;
            if (mx >= m.x && mx < m.x + Math.max(8, m.sw()) && my >= m.y && my < m.y + Math.max(8, m.sh())) {
                dragMod = m; offX = mx - m.x; offY = my - m.y;
                return;
            }
        }
    }

    @Override
    protected void mouseClickMove(int mx, int my, int btn, long time) {
        if (dragMod == null) return;
        dragMod.x = Math.max(0, Math.min(width - Math.max(8, dragMod.sw()), mx - offX));
        dragMod.y = Math.max(0, Math.min(height - Math.max(8, dragMod.sh()), my - offY));
    }

    @Override
    protected void mouseReleased(int mx, int my, int state) {
        super.mouseReleased(mx, my, state);
        dragMod = null;
        Config.save();
    }

    @Override
    protected void keyTyped(char c, int code) throws IOException {
        if (code == 1) { mc.displayGuiScreen(new ModMenu()); return; }
        super.keyTyped(c, code);
    }

    @Override
    public void onGuiClosed() { Config.save(); }

    @Override
    public boolean doesGuiPauseGame() { return false; }
}
