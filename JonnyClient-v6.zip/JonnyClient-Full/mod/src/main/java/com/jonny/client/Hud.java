package com.jonny.client;

import net.minecraft.client.Minecraft;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class Hud {
    @SubscribeEvent
    public void onRender(RenderGameOverlayEvent.Text e) {
        Minecraft mc = Minecraft.getMinecraft();
        if (mc.gameSettings.showDebugInfo || mc.currentScreen instanceof HudEditor) return;
        drawAll(false);
    }

    public static void drawAll(boolean editor) {
        for (HudMod m : HudMods.ALL) if (m.enabled) m.draw(editor);
    }
}
