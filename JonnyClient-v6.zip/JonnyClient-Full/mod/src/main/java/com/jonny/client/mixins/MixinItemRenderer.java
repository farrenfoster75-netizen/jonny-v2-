package com.jonny.client.mixins;

import com.jonny.client.Feature;
import com.jonny.client.Stats;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.renderer.ItemRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyArg;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** 1.7-style block hit: the sword keeps swinging while you hold block. */
@Mixin(ItemRenderer.class)
public class MixinItemRenderer {
    @Inject(method = "renderItemInFirstPerson", at = @At("HEAD"), require = 0)
    private void jonny$capturePartial(float partialTicks, CallbackInfo ci) {
        Stats.partial = partialTicks;
    }

    @ModifyArg(method = "renderItemInFirstPerson",
            at = @At(value = "INVOKE", target = "Lnet/minecraft/client/renderer/ItemRenderer;transformFirstPersonItem(FF)V", ordinal = 2),
            index = 1, require = 0)
    private float jonny$blockHit(float swing) {
        if (!Feature.BLOCK_HIT.enabled) return swing;
        EntityPlayerSP p = Minecraft.getMinecraft().thePlayer;
        if (p == null || !p.isBlocking()) return swing;
        return p.getSwingProgress(Stats.partial);
    }
}
