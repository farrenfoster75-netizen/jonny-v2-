package com.jonny.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.util.ResourceLocation;

import java.awt.Color;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.GradientPaint;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.geom.RoundRectangle2D;
import java.awt.image.BufferedImage;

/** Free Jonny capes, drawn at runtime as HD (8x) cape textures. */
public class CapeTextures {
    public static final String[] NAMES = {"No cape", "Jonny", "Geeked", "Kai is Zesty"};
    private static final String[][] LINES = {{}, {"JONNY"}, {"GEEKED"}, {"KAI", "IS", "ZESTY"}};
    private static final int[][] COLORS = {{0, 0}, {0x1B2A6B, 0x6B3DD9}, {0x0E5A4A, 0x2FD6A0}, {0xD9306E, 0xFF9A3D}};
    private static final ResourceLocation[] LOCS = new ResourceLocation[4];

    public static final int S = 8;
    // outer face of the cape on a 64x32 layout: x 1..11, y 1..17
    public static final float U0 = 1f / 64f, U1 = 11f / 64f, V0 = 1f / 32f, V1 = 17f / 32f;

    public static ResourceLocation get(int idx) {
        if (idx <= 0 || idx >= NAMES.length) return null;
        if (LOCS[idx] == null) LOCS[idx] = make(idx);
        return LOCS[idx];
    }

    private static ResourceLocation make(int idx) {
        int w = 64 * S, h = 32 * S;
        BufferedImage img = new BufferedImage(w, h, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g = img.createGraphics();
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
        g.setRenderingHint(RenderingHints.KEY_FRACTIONALMETRICS, RenderingHints.VALUE_FRACTIONALMETRICS_ON);
        Color c1 = new Color(COLORS[idx][0]), c2 = new Color(COLORS[idx][1]);
        g.setPaint(new GradientPaint(0, 0, c1, 0, h, c2));
        g.fillRect(0, 0, w, h);

        int bx = 1 * S, by = 1 * S, bw = 10 * S, bh = 16 * S;
        g.setPaint(new GradientPaint(0, by, c1.brighter(), 0, by + bh, c2));
        g.fillRect(bx, by, bw, bh);
        g.setColor(new Color(255, 255, 255, 70));
        g.draw(new RoundRectangle2D.Float(bx + 6, by + 6, bw - 12, bh - 12, 14, 14));

        String[] lines = LINES[idx];
        String family = "SansSerif";
        for (String n : java.awt.GraphicsEnvironment.getLocalGraphicsEnvironment().getAvailableFontFamilyNames())
            if (n.equalsIgnoreCase("Segoe UI")) { family = n; break; }
        int maxW = bw - 18;
        float lineGap = 6f;
        int[] sizes = new int[lines.length];
        int totalH = 0;
        for (int i = 0; i < lines.length; i++) {
            Font f = new Font(family, Font.BOLD, 40);
            FontMetrics fm = g.getFontMetrics(f);
            int sz = Math.min(40, Math.max(10, 40 * maxW / Math.max(1, fm.stringWidth(lines[i]))));
            if (lines.length == 1) sz = Math.min(sz, 30);
            sizes[i] = sz;
            totalH += g.getFontMetrics(new Font(family, Font.BOLD, sz)).getHeight();
        }
        totalH += (int) (lineGap * (lines.length - 1));
        float y = by + (bh - totalH) / 2f;
        for (int i = 0; i < lines.length; i++) {
            Font f = new Font(family, Font.BOLD, sizes[i]);
            g.setFont(f);
            FontMetrics fm = g.getFontMetrics();
            float x = bx + (bw - fm.stringWidth(lines[i])) / 2f;
            g.setColor(new Color(0, 0, 0, 110));
            g.drawString(lines[i], x + 2, y + fm.getAscent() + 2);
            g.setColor(Color.WHITE);
            g.drawString(lines[i], x, y + fm.getAscent());
            y += fm.getHeight() + lineGap;
        }
        g.dispose();
        return Minecraft.getMinecraft().getTextureManager().getDynamicTextureLocation("jonny_cape_" + idx, new DynamicTexture(img));
    }
}
