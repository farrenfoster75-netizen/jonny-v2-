package com.jonny.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.settings.KeyBinding;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.client.registry.ClientRegistry;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import org.lwjgl.input.Keyboard;

import java.io.File;

@Mod(modid = "jonnyclient", name = "Jonny Client", version = "1.0",
     clientSideOnly = true, acceptedMinecraftVersions = "[1.8.9]")
public class JonnyClient {
    public static KeyBinding menuKey, zoomKey, sneakKey;

    @Mod.EventHandler
    public void init(FMLInitializationEvent e) {
        Config.load(new File(Minecraft.getMinecraft().mcDataDir, "config/jonnyclient.cfg"));
        menuKey = new KeyBinding("Open Jonny Menu", Keyboard.KEY_RSHIFT, "Jonny Client");
        zoomKey = new KeyBinding("Zoom", Keyboard.KEY_C, "Jonny Client");
        sneakKey = new KeyBinding("Toggle Sneak", Keyboard.KEY_NONE, "Jonny Client");
        ClientRegistry.registerKeyBinding(menuKey);
        ClientRegistry.registerKeyBinding(zoomKey);
        ClientRegistry.registerKeyBinding(sneakKey);
        MinecraftForge.EVENT_BUS.register(new Events());
        MinecraftForge.EVENT_BUS.register(new Hud());
        MinecraftForge.EVENT_BUS.register(new WingRenderer());
    }
}
