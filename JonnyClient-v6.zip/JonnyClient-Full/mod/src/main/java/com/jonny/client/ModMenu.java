package com.jonny.client;

import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.util.ResourceLocation;
import org.lwjgl.input.Mouse;
import org.lwjgl.opengl.GL11;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.function.BooleanSupplier;
import java.util.function.IntConsumer;
import java.util.function.IntSupplier;

/** Jonny Client vX menu: smooth AA rounded UI, animated switches, expandable cards, cosmetics. */
public class ModMenu extends GuiScreen {
    private enum Tab {
        HUD("HUD MODS"), PVP("PVP & UTILITY"), FPS("FPS BOOST"), GFX("GRAPHICS"), COSMETICS("COSMETICS"), SETTINGS("SETTINGS");
        final String title;
        Tab(String title) { this.title = title; }
    }

    private static final int BG = 0x0D0F15, PANEL = 0x131620, ROW = 0x1A1E2B, ROW_HOVER = 0x252B3E,
            TEXT = 0xEDEFF5, SUB = 0x8B93A7, OFF = 0x384056;
    private static final int SB = 138;
    private static Tab lastTab = Tab.HUD;
    private static final Set<String> expanded = new HashSet<String>();

    private Tab tab = lastTab;
    private float scrollPos, scrollTarget, tabInd = -1f;
    private int maxScroll;
    private final long openTime = System.currentTimeMillis();
    private float alpha = 1f;
    private int px, py, pw, ph, cx, cy, cw, ch, sf, sh;
    private Item dragging;
    private int dragX, dragW;
    private final Map<String, Float> anim = new HashMap<String, Float>();

    // ------------------------------------------------------------ helpers
    private int ca(int rgb) { return (((int) (alpha * 255)) << 24) | (rgb & 0xFFFFFF); }
    private int ac(int rgb, int a) { return (((int) (alpha * a)) << 24) | (rgb & 0xFFFFFF); }
    private void t(String s, float x, float y, float size, int rgb, boolean bold) { UI.text(s, x, y, size, ca(rgb), bold, false); }
    private float tw(String s, float size, boolean bold) { return UI.width(s, size, bold); }
    private static boolean in(int mx, int my, int x, int y, int w, int h) { return mx >= x && mx < x + w && my >= y && my < y + h; }
    private boolean inContent(int mx, int my) { return in(mx, my, cx, cy, cw, ch); }

    private static int mix(int c1, int c2, float f) {
        int r = (int) (((c1 >> 16) & 255) * (1 - f) + ((c2 >> 16) & 255) * f);
        int g = (int) (((c1 >> 8) & 255) * (1 - f) + ((c2 >> 8) & 255) * f);
        int b = (int) ((c1 & 255) * (1 - f) + (c2 & 255) * f);
        return (r << 16) | (g << 8) | b;
    }

    private float anim(String key, boolean on) {
        Float c = anim.get(key);
        float cur = c == null ? (on ? 1f : 0f) : c;
        float tgt = on ? 1f : 0f;
        cur += (tgt - cur) * 0.25f;
        if (Math.abs(tgt - cur) < 0.01f) cur = tgt;
        anim.put(key, cur);
        return cur;
    }

    private float animVal(String key, boolean def) {
        Float c = anim.get(key);
        return c == null ? (def ? 1f : 0f) : c;
    }

    private int hovCol(String key, boolean hov) { return ca(mix(ROW, ROW_HOVER, anim("hv:" + key, hov))); }

    private void scissor(int x, int y, int w, int h) {
        GL11.glScissor(x * sf, (sh - (y + h)) * sf, Math.max(0, w) * sf, Math.max(0, h) * sf);
    }

    private void clipTo(int x, int y, int w, int h) {
        int x0 = Math.max(x, cx), y0 = Math.max(y, cy), x1 = Math.min(x + w, cx + cw), y1 = Math.min(y + h, cy + ch);
        scissor(x0, y0, x1 - x0, y1 - y0);
    }

    private void drawSwitch(int x, int y, boolean on, String key) {
        float a = anim(key, on);
        UI.rrect(x, y, 32, 16, 8, ca(mix(OFF, UI.accent(), a)));
        UI.rrect(x + 2 + Math.round(16 * a), y + 2, 12, 12, 6, ca(0xFFFFFF));
    }

    private void drawTrack(int x, int y, int w, float frac) {
        frac = Math.max(0f, Math.min(1f, frac));
        int fw = (int) (w * frac);
        UI.rrect(x, y, w, 4, 2, ca(OFF));
        UI.rrect(x, y, Math.max(fw, 4), 4, 2, ca(UI.accent()));
        UI.rrect(x + fw - 5, y - 3, 10, 10, 5, ca(0xFFFFFF));
    }

    // ------------------------------------------------------------ rows
    private abstract class Item {
        abstract int step();
        abstract void draw(int x, int y, int w, int mx, int my);
        void click(int x, int y, int w, int mx, int my) {}
        void drag(int mx) {}
    }

    private abstract class SwitchRow extends Item {
        final String key, label, desc;
        SwitchRow(String key, String label, String desc) { this.key = key; this.label = label; this.desc = desc; }
        abstract boolean on();
        abstract void toggle();
        int step() { return 38; }
        void draw(int x, int y, int w, int mx, int my) {
            boolean hov = inContent(mx, my) && in(mx, my, x, y, w, 34);
            UI.rrect(x, y, w, 34, 8, hovCol(key, hov));
            t(label, x + 14, y + 5, 10f, TEXT, true);
            t(desc, x + 14, y + 19, 8f, SUB, false);
            drawSwitch(x + w - 46, y + 9, on(), key);
        }
        void click(int x, int y, int w, int mx, int my) { toggle(); }
    }

    private class FeatureRow extends SwitchRow {
        final Feature f;
        FeatureRow(Feature f) { super("f:" + f.name(), f.label, f.desc); this.f = f; }
        boolean on() { return f.enabled; }
        void toggle() {
            f.enabled = !f.enabled;
            if (f.gfx) GfxTuner.apply();
            if (f == Feature.ENTITY_SCALE) Events.refreshEntityWeights();
            Config.save();
        }
    }

    private class BoolRow extends SwitchRow {
        final BooleanSupplier get; final Runnable flip;
        BoolRow(String key, String label, String desc, BooleanSupplier get, Runnable flip) {
            super(key, label, desc); this.get = get; this.flip = flip;
        }
        boolean on() { return get.getAsBoolean(); }
        void toggle() { flip.run(); Config.save(); }
    }

    private class HudRow extends Item {
        final HudMod m;
        HudRow(HudMod m) { this.m = m; }
        boolean exp() { return expanded.contains(m.id); }
        int cardH() { return 34 + Math.round(66 * animVal("e:" + m.id, false)); }
        int step() { return cardH() + 4; }
        void draw(int x, int y, int w, int mx, int my) {
            float e = anim("e:" + m.id, exp());
            int h = 34 + Math.round(66 * e);
            boolean hov = inContent(mx, my) && in(mx, my, x, y, w, 34);
            UI.rrect(x, y, w, h, 8, ca(ROW));
            if (hov) UI.rrect(x, y, w, 34, 8, ac(ROW_HOVER, 255));
            t(e > 0.5f ? "v" : ">", x + 14, y + 9, 10f, SUB, true);
            t(m.name, x + 30, y + 5, 10f, TEXT, true);
            t(m.desc, x + 30, y + 19, 8f, SUB, false);
            drawSwitch(x + w - 46, y + 9, m.enabled, "h:" + m.id);
            if (e > 0.03f) {
                clipTo(x, y + 34, w, h - 34);
                int sy = y + 38;
                drawRect(x + 12, sy - 3, x + w - 12, sy - 2, ac(0xFFFFFF, 18));
                t("Scale", x + 14, sy + 2, 9f, TEXT, false);
                String v = m.scale + "%";
                t(v, x + w - 14 - tw(v, 9f, false), sy + 2, 9f, UI.accent(), false);
                drawTrack(x + 14, sy + 20, w - 28, (m.scale - 50) / 150f);
                t("Background", x + 14, sy + 36, 9f, TEXT, false);
                drawSwitch(x + w - 46, sy + 33, m.bg, "hb:" + m.id);
                clipTo(cx, cy, cw, ch);
            }
        }
        void click(int x, int y, int w, int mx, int my) {
            if (my < y + 34) {
                if (mx >= x + w - 54) { m.enabled = !m.enabled; Config.save(); }
                else if (exp()) expanded.remove(m.id);
                else expanded.add(m.id);
                return;
            }
            if (!exp()) return;
            int sy = y + 38;
            if (in(mx, my, x + 8, sy + 12, w - 16, 20)) { dragging = this; dragX = x; dragW = w; drag(mx); return; }
            if (in(mx, my, x + 8, sy + 30, w - 16, 24)) { m.bg = !m.bg; Config.save(); }
        }
        void drag(int mx) {
            float p = (mx - (dragX + 14)) / (float) (dragW - 28);
            p = Math.max(0f, Math.min(1f, p));
            m.scale = 50 + 5 * Math.round(p * 30f);
        }
    }

    private class SliderRow extends Item {
        final String label, suffix; final int min, max; final IntSupplier get; final IntConsumer set;
        SliderRow(String label, String suffix, int min, int max, IntSupplier get, IntConsumer set) {
            this.label = label; this.suffix = suffix; this.min = min; this.max = max; this.get = get; this.set = set;
        }
        int step() { return 44; }
        void draw(int x, int y, int w, int mx, int my) {
            UI.rrect(x, y, w, 40, 8, ca(ROW));
            t(label, x + 14, y + 6, 10f, TEXT, true);
            String v = get.getAsInt() + suffix;
            t(v, x + w - 14 - tw(v, 10f, true), y + 6, 10f, UI.accent(), true);
            drawTrack(x + 14, y + 28, w - 28, (get.getAsInt() - min) / (float) (max - min));
        }
        void click(int x, int y, int w, int mx, int my) { dragging = this; dragX = x; dragW = w; drag(mx); }
        void drag(int mx) {
            float p = (mx - (dragX + 14)) / (float) (dragW - 28);
            p = Math.max(0f, Math.min(1f, p));
            set.accept(Math.round(min + p * (max - min)));
        }
    }

    private class BtnRow extends Item {
        final java.util.function.Supplier<String> label; final Runnable action;
        BtnRow(java.util.function.Supplier<String> label, Runnable action) { this.label = label; this.action = action; }
        int step() { return 34; }
        void draw(int x, int y, int w, int mx, int my) {
            boolean hov = inContent(mx, my) && in(mx, my, x, y, w, 30);
            float a = anim("hb:" + label.get(), hov);
            UI.rrect(x, y, w, 30, 8, ac(UI.accent(), 90 + (int) (110 * a)));
            UI.rrect(x + 1, y + 1, w - 2, 28, 7, ca(mix(ROW, ROW_HOVER, a)));
            String s = label.get();
            t(s, x + (w - tw(s, 10f, true)) / 2f, y + 8, 10f, UI.accent(), true);
        }
        void click(int x, int y, int w, int mx, int my) { action.run(); Config.save(); }
    }

    private class HeaderRow extends Item {
        final String text;
        HeaderRow(String text) { this.text = text; }
        int step() { return 22; }
        void draw(int x, int y, int w, int mx, int my) { t(text, x + 4, y + 4, 8f, SUB, true); }
    }

    /** Cosmetic selector card (cape or wings) with preview. */
    private class CosmeticRow extends Item {
        final boolean cape; final int idx;
        CosmeticRow(boolean cape, int idx) { this.cape = cape; this.idx = idx; }
        int step() { return 62; }
        boolean selected() { return (cape ? Config.capeIdx : Config.wingIdx) == idx; }
        void draw(int x, int y, int w, int mx, int my) {
            boolean hov = inContent(mx, my) && in(mx, my, x, y, w, 58);
            boolean sel = selected();
            float a = anim("sel:" + cape + idx, sel);
            if (a > 0.01f) UI.rrect(x - 1, y - 1, w + 2, 60, 9, ac(UI.accent(), (int) (200 * a)));
            UI.rrect(x, y, w, 58, 8, hovCol("c:" + cape + idx, hov));
            ResourceLocation tex = cape ? CapeTextures.get(idx) : WingTextures.get(idx);
            UI.rrect(x + 10, y + 9, 40, 40, 6, ca(0x0A0C11));
            if (tex != null) {
                if (cape) UI.drawTex(tex, x + 20, y + 11, 20, 36, CapeTextures.U0, CapeTextures.V0, CapeTextures.U1, CapeTextures.V1, alpha);
                else UI.drawTex(tex, x + 14, y + 13, 32, 32, 0f, 0f, 1f, 1f, alpha);
            } else {
                t("-", x + 28, y + 20, 14f, SUB, true);
            }
            String name = cape ? CapeTextures.NAMES[idx] : WingTextures.NAMES[idx];
            t(name, x + 62, y + 14, 11f, TEXT, true);
            t(sel ? "Equipped" : "Click to equip", x + 62, y + 31, 8.5f, sel ? UI.accent() : SUB, false);
            if (sel) {
                UI.rrect(x + w - 74, y + 20, 60, 18, 9, ac(UI.accent(), 60));
                t("ACTIVE", x + w - 74 + (60 - tw("ACTIVE", 8f, true)) / 2f, y + 24, 8f, UI.accent(), true);
            }
        }
        void click(int x, int y, int w, int mx, int my) {
            if (cape) Config.capeIdx = idx; else Config.wingIdx = idx;
            Config.save();
        }
    }

    private BtnRow btn(String label, Runnable r) { return new BtnRow(() -> label, r); }

    private List<Item> items() {
        List<Item> l = new ArrayList<Item>();
        switch (tab) {
            case HUD:
                l.add(btn("Edit HUD Layout  (drag & drop)", () -> mc.displayGuiScreen(new HudEditor())));
                l.add(new HeaderRow("CLICK A MOD TO OPEN ITS SCALE AND BACKGROUND OPTIONS"));
                for (HudMod m : HudMods.ALL) l.add(new HudRow(m));
                break;
            case PVP:
                for (Feature f : Feature.values()) if (f.category == Feature.Category.PVP) l.add(new FeatureRow(f));
                l.add(new HeaderRow("OPTIONS"));
                l.add(new SliderRow("Time of day", "", 0, 24000, () -> Config.timeValue, v -> Config.timeValue = v));
                l.add(new BtnRow(() -> "Crosshair style: " + new String[]{"Cross", "Dot", "Plus"}[Math.floorMod(Config.crosshairStyle, 3)] + "  (click)",
                        () -> Config.crosshairStyle = (Config.crosshairStyle + 1) % 3));
                break;
            case FPS:
                l.add(btn("Apply MAX FPS Preset", GfxTuner::applyMaxFpsPreset));
                for (Feature f : Feature.values()) if (f.category == Feature.Category.FPS) l.add(new FeatureRow(f));
                l.add(new HeaderRow("TUNING"));
                l.add(new SliderRow("Entity cull distance", "", 16, 128, () -> Config.cullDistance, v -> Config.cullDistance = v));
                l.add(new SliderRow("Entity render distance", "%", 25, 100, () -> Config.entityScale,
                        v -> { Config.entityScale = v; Events.refreshEntityWeights(); }));
                l.add(new SliderRow("Nametag distance", "", 8, 64, () -> Config.nametagDistance, v -> Config.nametagDistance = v));
                l.add(new SliderRow("Tile entity distance", "", 8, 64, () -> Config.tileDistance, v -> Config.tileDistance = v));
                l.add(new SliderRow("Particle draw distance", "", 8, 64, () -> Config.particleDistance, v -> Config.particleDistance = v));
                l.add(new SliderRow("Armor draw distance", "", 8, 64, () -> Config.armorDistance, v -> Config.armorDistance = v));
                l.add(new SliderRow("Particle cap", "", 50, 1000, () -> Config.particleCap, v -> Config.particleCap = v));
                l.add(new SliderRow("Adaptive target FPS", "", 60, 300, () -> Config.adaptiveTarget, v -> Config.adaptiveTarget = v));
                l.add(new SliderRow("Render distance (chunks)", "", 2, 16, () -> mc.gameSettings.renderDistanceChunks,
                        v -> { Config.renderDistance = v; GfxTuner.apply(); }));
                break;
            case GFX:
                for (Feature f : Feature.values()) if (f.category == Feature.Category.GRAPHICS) l.add(new FeatureRow(f));
                break;
            case COSMETICS:
                l.add(new HeaderRow("CAPES  -  ONLY YOU CAN SEE THEM FOR NOW"));
                for (int i = 0; i < CapeTextures.NAMES.length; i++) l.add(new CosmeticRow(true, i));
                l.add(new HeaderRow("WINGS  -  VISIBLE IN THIRD PERSON (F5)"));
                for (int i = 0; i < WingTextures.NAMES.length; i++) l.add(new CosmeticRow(false, i));
                break;
            default:
                l.add(new BoolRow("s:font", "Modern HUD font", "Smooth Segoe UI text on the HUD",
                        () -> Config.modernFont, () -> Config.modernFont = !Config.modernFont));
                l.add(new BtnRow(() -> "Accent color: " + UI.ACCENT_NAMES[Math.floorMod(Config.accentIdx, UI.ACCENTS.length)] + "  (click)",
                        () -> Config.accentIdx = (Config.accentIdx + 1) % UI.ACCENTS.length));
                l.add(btn("Reset HUD positions and options", HudMods::resetAll));
                l.add(btn("Reset everything to default", () -> { HudMods.resetAll(); GfxTuner.resetAll(); Events.refreshEntityWeights(); }));
                break;
        }
        return l;
    }

    private String subtitle() {
        switch (tab) {
            case HUD: {
                int n = 0;
                for (HudMod m : HudMods.ALL) if (m.enabled) n++;
                return n + " of " + HudMods.ALL.size() + " HUD mods enabled";
            }
            case PVP: return "Combat and utility mods";
            case FPS: return "Performance systems and tuning";
            case GFX: return "Game graphics toggles (all restorable)";
            case COSMETICS: return "Free Jonny capes and wings";
            default: return "Look and reset options";
        }
    }

    // ------------------------------------------------------------ screen
    @Override
    public void initGui() {
        pw = Math.min(width - 20, 600);
        ph = Math.min(height - 20, 360);
        px = (width - pw) / 2;
        py = (height - ph) / 2;
        cx = px + SB + 14;
        cy = py + 52;
        cw = pw - SB - 28;
        ch = ph - 64;
    }

    @Override
    public void drawScreen(int mx, int my, float pt) {
        alpha = Math.max(0.12f, Math.min(1f, (System.currentTimeMillis() - openTime) / 240f));
        ScaledResolution sr = new ScaledResolution(mc);
        sf = sr.getScaleFactor();
        sh = sr.getScaledHeight();
        drawRect(0, 0, width, height, ((int) (alpha * 160)) << 24);

        GlStateManager.pushMatrix();
        GlStateManager.translate(0f, (1f - alpha) * 10f, 0f);

        UI.glow(px, py, pw, ph, 12, 0x000000, (int) (alpha * 110));
        UI.rrect(px - 1, py - 1, pw + 2, ph + 2, 13, ac(UI.accent(), 80));
        UI.rrect(px, py, pw, ph, 12, ca(BG));
        UI.rrect(px, py, SB, ph, 12, ca(PANEL));
        drawRect(px + SB - 12, py, px + SB, py + ph, ca(PANEL));

        t("JONNY", px + 18, py + 14, 17f, TEXT, true);
        t("CLIENT", px + 18, py + 31, 12f, UI.accent(), true);
        t("vX", px + 18 + tw("CLIENT", 12f, true) + 6, py + 31, 12f, SUB, true);

        Tab[] tabs = Tab.values();
        if (tabInd < 0) tabInd = tab.ordinal();
        tabInd += (tab.ordinal() - tabInd) * 0.28f;
        UI.rrect(px + 10, py + 66 + Math.round(tabInd * 29), SB - 20, 25, 8, ac(UI.accent(), 50));
        UI.rrect(px + 10, py + 66 + Math.round(tabInd * 29) + 5, 3, 15, 1, ca(UI.accent()));
        for (int i = 0; i < tabs.length; i++) {
            int ty = py + 66 + i * 29;
            boolean sel = tabs[i] == tab;
            boolean hov = in(mx, my, px + 10, ty, SB - 20, 25);
            float h = anim("tab:" + i, hov && !sel);
            if (h > 0.02f) UI.rrect(px + 10, ty, SB - 20, 25, 8, ac(ROW, (int) (255 * h)));
            t(tabs[i].title, px + 24, ty + 7, 9f, sel ? UI.accent() : TEXT, true);
        }
        t("Right Shift to close", px + 16, py + ph - 22, 8f, SUB, false);

        t(tab.title, cx, py + 14, 16f, TEXT, true);
        t(subtitle(), cx, py + 33, 8.5f, SUB, false);
        boolean xHover = in(mx, my, px + pw - 34, py + 12, 22, 22);
        UI.rrect(px + pw - 34, py + 12, 22, 22, 7, ca(mix(ROW, 0xD04050, anim("xbtn", xHover))));
        t("x", px + pw - 26, py + 16, 11f, TEXT, true);

        List<Item> list = items();
        int total = 0;
        for (Item it : list) total += it.step();
        maxScroll = Math.max(0, total - ch);
        scrollTarget = Math.max(0, Math.min(maxScroll, scrollTarget));
        scrollPos += (scrollTarget - scrollPos) * 0.26f;
        int scroll = Math.round(scrollPos);

        GL11.glEnable(GL11.GL_SCISSOR_TEST);
        scissor(cx, cy, cw, ch);
        int y = cy - scroll;
        int rw = cw - 8;
        for (Item it : list) {
            if (y + it.step() > cy - 60 && y < cy + ch + 60) it.draw(cx, y, rw, mx, my);
            y += it.step();
        }
        GL11.glDisable(GL11.GL_SCISSOR_TEST);

        if (maxScroll > 0) {
            int barH = Math.max(26, ch * ch / (ch + maxScroll));
            int barY = cy + (int) ((ch - barH) * (scroll / (float) maxScroll));
            UI.rrect(cx + cw - 3, barY, 3, barH, 1, ac(UI.accent(), 200));
        }

        GlStateManager.popMatrix();
        super.drawScreen(mx, my, pt);
    }

    @Override
    protected void mouseClicked(int mx, int my, int btn) throws IOException {
        super.mouseClicked(mx, my, btn);
        if (btn != 0) return;
        if (in(mx, my, px + pw - 34, py + 12, 22, 22)) { mc.displayGuiScreen(null); return; }
        Tab[] tabs = Tab.values();
        for (int i = 0; i < tabs.length; i++) {
            if (in(mx, my, px + 10, py + 66 + i * 29, SB - 20, 25)) {
                tab = tabs[i]; lastTab = tab; scrollTarget = 0; scrollPos = 0;
                return;
            }
        }
        if (!inContent(mx, my)) return;
        int y = cy - Math.round(scrollPos);
        int rw = cw - 8;
        for (Item it : items()) {
            int st = it.step();
            if (my >= y && my < y + st - 4 && mx >= cx && mx < cx + rw) { it.click(cx, y, rw, mx, my); return; }
            y += st;
        }
    }

    @Override
    protected void mouseClickMove(int mx, int my, int btn, long time) {
        if (dragging != null) dragging.drag(mx);
    }

    @Override
    protected void mouseReleased(int mx, int my, int state) {
        super.mouseReleased(mx, my, state);
        dragging = null;
        Config.save();
    }

    @Override
    public void handleMouseInput() throws IOException {
        super.handleMouseInput();
        int d = Mouse.getEventDWheel();
        if (d != 0) scrollTarget = Math.max(0, Math.min(maxScroll, scrollTarget - Integer.signum(d) * 40));
    }

    @Override
    public void onGuiClosed() { Config.save(); }

    @Override
    public boolean doesGuiPauseGame() { return false; }
}
