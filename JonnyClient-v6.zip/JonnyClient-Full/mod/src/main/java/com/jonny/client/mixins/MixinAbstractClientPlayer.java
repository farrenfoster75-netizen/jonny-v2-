package com.jonny.client.mixins;

import com.jonny.client.CapeTextures;
import com.jonny.client.Config;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.AbstractClientPlayer;
import net.minecraft.util.ResourceLocation;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(AbstractClientPlayer.class)
public class MixinAbstractClientPlayer {
    @Inject(method = "getLocationCape", at = @At("HEAD"), cancellable = true, require = 0)
    private void jonny$cape(CallbackInfoReturnable<ResourceLocation> cir) {
        if (Config.capeIdx <= 0) return;
        Minecraft mc = Minecraft.getMinecraft();
        Object self = this;
        if (mc.thePlayer == null || self != mc.thePlayer) return;
        ResourceLocation loc = CapeTextures.get(Config.capeIdx);
        if (loc != null) cir.setReturnValue(loc);
    }
}
