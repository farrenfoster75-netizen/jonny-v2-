package com.jonny.client;

import java.io.*;
import java.util.Properties;

public class Config {
    public static int cullDistance = 64;
    public static int nametagDistance = 32;
    public static int renderDistance = 0;   // 0 = leave vanilla setting alone
    public static int entityScale = 75;     // percent of vanilla entity render distance
    public static int particleCap = 300;
    public static int tileDistance = 32;
    public static int armorDistance = 24;
    public static int capeIdx = 0;
    public static int wingIdx = 0;
    public static int adaptiveTarget = 144;
    public static int particleDistance = 24;
    public static int timeValue = 6000;
    public static int crosshairStyle = 0;
    public static int accentIdx = 0;
    public static boolean modernFont = true;
    private static File file;

    private static int geti(Properties p, String k, int d) {
        try { return Integer.parseInt(p.getProperty(k, String.valueOf(d))); } catch (Exception e) { return d; }
    }

    private static boolean getb(Properties p, String k, boolean d) {
        return Boolean.parseBoolean(p.getProperty(k, String.valueOf(d)));
    }

    public static void load(File f) {
        file = f;
        Properties p = new Properties();
        try (FileInputStream in = new FileInputStream(f)) {
            p.load(in);
        } catch (Exception ignored) { return; }
        for (Feature ft : Feature.values()) ft.enabled = getb(p, ft.name(), ft.def);
        cullDistance = geti(p, "cullDistance", 64);
        nametagDistance = geti(p, "nametagDistance", 32);
        renderDistance = geti(p, "renderDistance", 0);
        entityScale = geti(p, "entityScale", 75);
        particleCap = geti(p, "particleCap", 300);
        tileDistance = geti(p, "tileDistance", 32);
        armorDistance = geti(p, "armorDistance", 24);
        capeIdx = geti(p, "capeIdx", 0);
        wingIdx = geti(p, "wingIdx", 0);
        adaptiveTarget = geti(p, "adaptiveTarget", 144);
        particleDistance = geti(p, "particleDistance", 24);
        timeValue = geti(p, "timeValue", 6000);
        crosshairStyle = geti(p, "crosshairStyle", 0);
        accentIdx = geti(p, "accentIdx", 0);
        modernFont = getb(p, "modernFont", true);
        for (HudMod m : HudMods.ALL) {
            String k = "hud." + m.id + ".";
            m.enabled = getb(p, k + "enabled", m.defEnabled);
            m.bg = getb(p, k + "bg", true);
            m.x = geti(p, k + "x", m.defX);
            m.y = geti(p, k + "y", m.defY);
            m.scale = Math.max(50, Math.min(200, geti(p, k + "scale", 100)));
        }
    }

    public static void save() {
        if (file == null) return;
        Properties p = new Properties();
        for (Feature ft : Feature.values()) p.setProperty(ft.name(), String.valueOf(ft.enabled));
        p.setProperty("cullDistance", String.valueOf(cullDistance));
        p.setProperty("nametagDistance", String.valueOf(nametagDistance));
        p.setProperty("renderDistance", String.valueOf(renderDistance));
        p.setProperty("entityScale", String.valueOf(entityScale));
        p.setProperty("particleCap", String.valueOf(particleCap));
        p.setProperty("tileDistance", String.valueOf(tileDistance));
        p.setProperty("armorDistance", String.valueOf(armorDistance));
        p.setProperty("capeIdx", String.valueOf(capeIdx));
        p.setProperty("wingIdx", String.valueOf(wingIdx));
        p.setProperty("adaptiveTarget", String.valueOf(adaptiveTarget));
        p.setProperty("particleDistance", String.valueOf(particleDistance));
        p.setProperty("timeValue", String.valueOf(timeValue));
        p.setProperty("crosshairStyle", String.valueOf(crosshairStyle));
        p.setProperty("accentIdx", String.valueOf(accentIdx));
        p.setProperty("modernFont", String.valueOf(modernFont));
        for (HudMod m : HudMods.ALL) {
            String k = "hud." + m.id + ".";
            p.setProperty(k + "enabled", String.valueOf(m.enabled));
            p.setProperty(k + "bg", String.valueOf(m.bg));
            p.setProperty(k + "x", String.valueOf(m.x));
            p.setProperty(k + "y", String.valueOf(m.y));
            p.setProperty(k + "scale", String.valueOf(m.scale));
        }
        try {
            file.getParentFile().mkdirs();
            try (FileOutputStream out = new FileOutputStream(file)) { p.store(out, "Jonny Client"); }
        } catch (Exception ignored) {}
    }
}
