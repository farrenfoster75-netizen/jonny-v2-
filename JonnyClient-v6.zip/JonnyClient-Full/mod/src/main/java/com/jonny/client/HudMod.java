package com.jonny.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GlStateManager;

import java.util.ArrayList;
import java.util.List;

/** One draggable HUD element with its own on/off, position, scale and background. */
public abstract class HudMod {
    public final String id, name, desc;
    public final boolean defEnabled;
    public final int defX, defY;
    public boolean enabled, bg = true;
    public int x, y, scale = 100;
    public int w = 60, h = 14;

    protected HudMod(String id, String name, String desc, boolean enabled, int x, int y) {
        this.id = id; this.name = name; this.desc = desc;
        this.defEnabled = enabled; this.enabled = enabled;
        this.defX = x; this.defY = y; this.x = x; this.y = y;
    }

    /** Simple label/value rows. Override this, or override render() for custom drawing. */
    protected List<String[]> rows(Minecraft mc) { return new ArrayList<String[]>(); }

    protected static List<String[]> one(String label, String value) {
        List<String[]> l = new ArrayList<String[]>();
        l.add(new String[]{label, value});
        return l;
    }

    protected void render(Minecraft mc, boolean editor) {
        List<String[]> rows = rows(mc);
        if (rows.isEmpty()) {
            if (!editor) { w = 0; h = 0; return; }
            rows = one(name, "");
        }
        int pad = 4, maxw = 0;
        for (String[] r : rows) maxw = Math.max(maxw, UI.hudWidth(r[0] + " " + r[1]));
        w = maxw + pad * 2;
        h = rows.size() * UI.LINE_H + pad * 2 - 3;
        if (bg) UI.rrect(0, 0, w, h, 3, 0x78000000);
        int yy = pad - 1;
        int labelColor = 0xFF000000 | UI.accent();
        for (String[] r : rows) {
            int xx = pad;
            if (!r[0].isEmpty()) { UI.hudText(r[0], xx, yy, labelColor); xx += UI.hudWidth(r[0] + " "); }
            UI.hudText(r[1], xx, yy, 0xFFFFFFFF);
            yy += UI.LINE_H;
        }
    }

    public final void draw(boolean editor) {
        Minecraft mc = Minecraft.getMinecraft();
        float s = scale / 100f;
        GlStateManager.pushMatrix();
        GlStateManager.translate((float) x, (float) y, 0f);
        GlStateManager.scale(s, s, 1f);
        render(mc, editor);
        GlStateManager.popMatrix();
        GlStateManager.color(1f, 1f, 1f, 1f);
    }

    public int sw() { return Math.round(w * scale / 100f); }
    public int sh() { return Math.round(h * scale / 100f); }

    public void resetPosition() { x = defX; y = defY; scale = 100; bg = true; }
}
