package com.jonny.client;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/** Shared live stats used by HUD mods. */
public class Stats {
    private static final List<Long> LEFT = new ArrayList<Long>();
    private static final List<Long> RIGHT = new ArrayList<Long>();
    public static int combo;
    public static double reach;
    public static long lastHit;
    public static double speed;
    public static float partial;

    public static void click(int button) {
        if (button == 0) LEFT.add(System.currentTimeMillis());
        else if (button == 1) RIGHT.add(System.currentTimeMillis());
    }

    private static int count(List<Long> l) {
        long now = System.currentTimeMillis();
        Iterator<Long> it = l.iterator();
        while (it.hasNext()) if (now - it.next() > 1000) it.remove();
        return l.size();
    }

    public static int left() { return count(LEFT); }
    public static int right() { return count(RIGHT); }
}
