package com.jonny.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.WorldRenderer;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.util.ResourceLocation;
import org.lwjgl.opengl.GL11;

import java.awt.Color;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.GraphicsEnvironment;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.font.FontRenderContext;
import java.awt.image.BufferedImage;

/** Anti-aliased TTF text renderer (uses Segoe UI on Windows) drawn from a generated texture atlas. */
public class ModernFont {
    public static final ModernFont REG = new ModernFont(Font.PLAIN, "jonnyfont_reg");
    public static final ModernFont BOLD = new ModernFont(Font.BOLD, "jonnyfont_bold");

    private static final int ATLAS_PX = 32, FIRST = 32, LAST = 126, SIZE = 512, CELL_W = 40;

    private final int style;
    private final String texName;
    private boolean ready, failed;
    private ResourceLocation loc;
    private final float[] gx = new float[128], gy = new float[128], gw = new float[128];
    private float cellH = 40f;

    private ModernFont(int style, String texName) { this.style = style; this.texName = texName; }

    private void init() {
        if (ready || failed) return;
        try {
            String family = "SansSerif";
            String[] names = GraphicsEnvironment.getLocalGraphicsEnvironment().getAvailableFontFamilyNames();
            String[] prefs = {"Segoe UI", "Inter", "Roboto", "Helvetica Neue", "Arial"};
            boolean found = false;
            for (String pref : prefs) {
                for (String n : names) if (n.equalsIgnoreCase(pref)) { family = n; found = true; break; }
                if (found) break;
            }
            Font font = new Font(family, style, ATLAS_PX);
            BufferedImage img = new BufferedImage(SIZE, SIZE, BufferedImage.TYPE_INT_ARGB);
            Graphics2D g = img.createGraphics();
            g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
            g.setRenderingHint(RenderingHints.KEY_FRACTIONALMETRICS, RenderingHints.VALUE_FRACTIONALMETRICS_ON);
            g.setFont(font);
            FontMetrics fm = g.getFontMetrics();
            FontRenderContext frc = g.getFontRenderContext();
            cellH = fm.getHeight();
            int cellFull = (int) cellH + 4;
            int cols = SIZE / CELL_W;
            g.setColor(Color.WHITE);
            for (int c = FIRST; c <= LAST; c++) {
                int idx = c - FIRST;
                int px = (idx % cols) * CELL_W + 2;
                int py = (idx / cols) * cellFull + 2;
                String s = String.valueOf((char) c);
                g.drawString(s, px, py + fm.getAscent());
                gx[c] = px;
                gy[c] = py;
                gw[c] = (float) font.getStringBounds(s, frc).getWidth();
            }
            g.dispose();
            DynamicTexture tex = new DynamicTexture(img);
            loc = Minecraft.getMinecraft().getTextureManager().getDynamicTextureLocation(texName, tex);
            ready = true;
        } catch (Throwable t) {
            failed = true;
        }
    }

    public float height(float size) { return (ready ? cellH : 40f) * size / ATLAS_PX; }

    public float width(String s, float size) {
        init();
        if (failed) return Minecraft.getMinecraft().fontRendererObj.getStringWidth(s) * size / 8f;
        float k = size / ATLAS_PX, w = 0;
        for (int i = 0; i < s.length(); i++) {
            char ch = s.charAt(i);
            if (ch < FIRST || ch > LAST) ch = '?';
            w += gw[ch] * k;
        }
        return w;
    }

    public void draw(String s, float x, float y, float size, int argb, boolean shadow) {
        init();
        if (failed) {
            float sc = size / 8f;
            GlStateManager.pushMatrix();
            GlStateManager.translate(x, y, 0f);
            GlStateManager.scale(sc, sc, 1f);
            Minecraft.getMinecraft().fontRendererObj.drawString(s, 0, 0, argb | 0xFF000000, shadow);
            GlStateManager.popMatrix();
            return;
        }
        if (shadow) {
            int sh = (argb & 0xFF000000) | ((argb & 0xFCFCFC) >> 2);
            drawRaw(s, x + size / 10f, y + size / 10f, size, sh);
        }
        drawRaw(s, x, y, size, argb);
    }

    private void drawRaw(String s, float x, float y, float size, int argb) {
        float a = ((argb >>> 24) & 255) / 255f;
        if (a == 0f) a = 1f;
        float r = ((argb >> 16) & 255) / 255f, gr = ((argb >> 8) & 255) / 255f, b = (argb & 255) / 255f;
        float k = size / ATLAS_PX, h = cellH * k;
        Minecraft.getMinecraft().getTextureManager().bindTexture(loc);
        GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_MIN_FILTER, GL11.GL_LINEAR);
        GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_MAG_FILTER, GL11.GL_LINEAR);
        GlStateManager.enableTexture2D();
        GlStateManager.enableBlend();
        GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
        GlStateManager.color(r, gr, b, a);
        WorldRenderer wr = Tessellator.getInstance().getWorldRenderer();
        wr.begin(7, DefaultVertexFormats.POSITION_TEX);
        float cx = x;
        for (int i = 0; i < s.length(); i++) {
            char ch = s.charAt(i);
            if (ch < FIRST || ch > LAST) ch = '?';
            float gwid = Math.min(CELL_W - 4, gw[ch] + 2);
            float w = gwid * k;
            float u0 = gx[ch] / SIZE, u1 = (gx[ch] + gwid) / SIZE;
            float v0 = gy[ch] / SIZE, v1 = (gy[ch] + cellH) / SIZE;
            wr.pos(cx, y + h, 0).tex(u0, v1).endVertex();
            wr.pos(cx + w, y + h, 0).tex(u1, v1).endVertex();
            wr.pos(cx + w, y, 0).tex(u1, v0).endVertex();
            wr.pos(cx, y, 0).tex(u0, v0).endVertex();
            cx += gw[ch] * k;
        }
        Tessellator.getInstance().draw();
        GlStateManager.color(1f, 1f, 1f, 1f);
    }
}
