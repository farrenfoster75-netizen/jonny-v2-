package com.jonny.client.mixins;

import com.jonny.client.Feature;
import net.minecraft.client.renderer.texture.TextureMap;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(TextureMap.class)
public class MixinTextureMap {
    @Inject(method = "updateAnimations", at = @At("HEAD"), cancellable = true, require = 0)
    private void jonny$freezeAnimations(CallbackInfo ci) {
        if (Feature.NO_ANIM_TEXTURES.enabled) ci.cancel();
    }
}
