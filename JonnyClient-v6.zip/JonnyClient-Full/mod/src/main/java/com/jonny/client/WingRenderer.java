package com.jonny.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.WorldRenderer;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.client.event.RenderWorldLastEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

/** Draws small bat/dragon wings on the local player, flapping slowly. */
public class WingRenderer {
    // wing outline in wing space (x = outward, y = up), counter-clockwise around the membrane
    private static final float[][] OUTLINE = {
            {0.02f, 0.04f}, {0.16f, 0.20f}, {0.32f, 0.33f}, {0.62f, 0.40f}, {0.49f, 0.24f},
            {0.71f, 0.12f}, {0.55f, 0.00f}, {0.58f, -0.17f}, {0.42f, -0.10f}, {0.36f, -0.31f},
            {0.21f, -0.14f}, {0.04f, -0.25f}
    };
    private static final float[] CENTER = {0.30f, 0.04f};
    // bones: from the root along the arm, then fingers out of the wrist
    private static final float[][] BONES = {
            {0.02f, 0.04f, 0.32f, 0.33f, 0.034f},
            {0.32f, 0.33f, 0.62f, 0.40f, 0.024f},
            {0.32f, 0.33f, 0.71f, 0.12f, 0.024f},
            {0.32f, 0.33f, 0.58f, -0.17f, 0.022f},
            {0.32f, 0.33f, 0.36f, -0.31f, 0.020f}
    };

    @SubscribeEvent
    public void onWorldLast(RenderWorldLastEvent e) {
        Minecraft mc = Minecraft.getMinecraft();
        if (Config.wingIdx <= 0 || mc.thePlayer == null || mc.theWorld == null) return;
        if (mc.gameSettings.thirdPersonView == 0 || mc.thePlayer.isInvisible()) return;
        ResourceLocation tex = WingTextures.get(Config.wingIdx);
        if (tex == null) return;

        EntityPlayer p = mc.thePlayer;
        float pt = e.partialTicks;
        RenderManager rm = mc.getRenderManager();
        double x = p.lastTickPosX + (p.posX - p.lastTickPosX) * pt - rm.viewerPosX;
        double y = p.lastTickPosY + (p.posY - p.lastTickPosY) * pt - rm.viewerPosY;
        double z = p.lastTickPosZ + (p.posZ - p.lastTickPosZ) * pt - rm.viewerPosZ;
        float yaw = p.prevRenderYawOffset + (p.renderYawOffset - p.prevRenderYawOffset) * pt;
        float t = p.ticksExisted + pt;
        float flap = (float) Math.sin(t * 0.08);          // ~4 second slow flap

        GlStateManager.pushMatrix();
        GlStateManager.translate((float) x, (float) y, (float) z);
        GlStateManager.rotate(-yaw, 0f, 1f, 0f);
        if (p.isSneaking()) {
            GlStateManager.translate(0f, -0.17f, 0.06f);
            GlStateManager.rotate(24f, 1f, 0f, 0f);
        }
        GlStateManager.disableLighting();
        GlStateManager.disableCull();
        GlStateManager.enableBlend();
        GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
        GlStateManager.color(1f, 1f, 1f, 1f);

        for (int side = -1; side <= 1; side += 2) {
            GlStateManager.pushMatrix();
            GlStateManager.translate(0.05f * side, 1.30f, -0.14f);
            GlStateManager.scale((float) side, 1f, 1f);
            GlStateManager.rotate(26f + flap * 13f, 0f, 1f, 0f);   // sweep back / forward
            GlStateManager.rotate(12f + flap * 7f, 0f, 0f, 1f);    // lift tips
            drawWing(tex);
            GlStateManager.popMatrix();
        }

        GlStateManager.enableCull();
        GlStateManager.enableTexture2D();
        GlStateManager.color(1f, 1f, 1f, 1f);
        GlStateManager.popMatrix();
    }

    private void drawWing(ResourceLocation tex) {
        Minecraft mc = Minecraft.getMinecraft();
        mc.getTextureManager().bindTexture(tex);
        GlStateManager.enableTexture2D();
        WorldRenderer wr = Tessellator.getInstance().getWorldRenderer();
        wr.begin(4, DefaultVertexFormats.POSITION_TEX);
        for (int i = 0; i < OUTLINE.length; i++) {
            float[] a = OUTLINE[i], b = OUTLINE[(i + 1) % OUTLINE.length];
            vert(wr, CENTER[0], CENTER[1]);
            vert(wr, a[0], a[1]);
            vert(wr, b[0], b[1]);
        }
        Tessellator.getInstance().draw();

        // dark bones on both faces
        GlStateManager.disableTexture2D();
        wr = Tessellator.getInstance().getWorldRenderer();
        wr.begin(7, DefaultVertexFormats.POSITION_COLOR);
        int col = Config.wingIdx == 3 ? 0xB8C0D6 : (Config.wingIdx == 1 ? 0x12041F : 0x050507);
        int r = (col >> 16) & 255, g = (col >> 8) & 255, b = col & 255;
        for (float[] bone : BONES) {
            float dx = bone[2] - bone[0], dy = bone[3] - bone[1];
            float len = (float) Math.sqrt(dx * dx + dy * dy);
            float nx = -dy / len * bone[4] / 2f, ny = dx / len * bone[4] / 2f;
            for (int face = -1; face <= 1; face += 2) {
                float z = 0.004f * face;
                wr.pos(bone[0] - nx, bone[1] - ny, z).color(r, g, b, 255).endVertex();
                wr.pos(bone[0] + nx, bone[1] + ny, z).color(r, g, b, 255).endVertex();
                wr.pos(bone[2] + nx, bone[3] + ny, z).color(r, g, b, 255).endVertex();
                wr.pos(bone[2] - nx, bone[3] - ny, z).color(r, g, b, 255).endVertex();
            }
        }
        Tessellator.getInstance().draw();
        GlStateManager.enableTexture2D();
    }

    private void vert(WorldRenderer wr, float x, float y) {
        float u = Math.max(0f, Math.min(1f, x / 0.75f));
        float v = Math.max(0f, Math.min(1f, (0.5f - y) / 0.9f));
        wr.pos(x, y, 0).tex(u, v).endVertex();
    }
}
