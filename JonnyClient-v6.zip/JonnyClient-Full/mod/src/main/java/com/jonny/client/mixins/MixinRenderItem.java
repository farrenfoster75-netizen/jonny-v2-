package com.jonny.client.mixins;

import com.jonny.client.Feature;
import net.minecraft.client.renderer.entity.RenderItem;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(RenderItem.class)
public class MixinRenderItem {
    @Inject(method = "renderEffect", at = @At("HEAD"), cancellable = true, require = 0)
    private void jonny$noItemGlint(CallbackInfo ci) {
        if (Feature.NO_GLINT.enabled) ci.cancel();
    }
}
