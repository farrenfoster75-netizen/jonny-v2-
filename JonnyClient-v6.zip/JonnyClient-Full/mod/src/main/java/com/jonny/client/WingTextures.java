package com.jonny.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.util.ResourceLocation;

import java.awt.Color;
import java.awt.GradientPaint;
import java.awt.Graphics2D;
import java.awt.RadialGradientPaint;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;
import java.util.Random;

/** Generated wing membrane textures. */
public class WingTextures {
    public static final String[] NAMES = {"No wings", "Nebula Dragon", "Shadow", "Angel", "Black & White"};
    private static final ResourceLocation[] LOCS = new ResourceLocation[5];

    public static ResourceLocation get(int idx) {
        if (idx <= 0 || idx >= NAMES.length) return null;
        if (LOCS[idx] == null) LOCS[idx] = make(idx);
        return LOCS[idx];
    }

    private static ResourceLocation make(int idx) {
        int n = 128;
        BufferedImage img = new BufferedImage(n, n, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g = img.createGraphics();
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        Random rnd = new Random(1337L + idx);
        Color top, bottom;
        Color[] blobs;
        if (idx == 1) { // nebula dragon: dark violet with magenta / blue-violet clouds
            top = new Color(0x1B0830); bottom = new Color(0x3A1070);
            blobs = new Color[]{new Color(0xC23CFF), new Color(0xFF6BD6), new Color(0x6A4CFF), new Color(0x9B2BE0)};
        } else if (idx == 2) { // shadow
            top = new Color(0x0A0A0D); bottom = new Color(0x1A1A22);
            blobs = new Color[]{new Color(0x34343F), new Color(0x22222B)};
        } else if (idx == 3) { // angel
            top = new Color(0xFFFFFF); bottom = new Color(0xDDE3F0);
            blobs = new Color[]{new Color(0xFFFFFF), new Color(0xC9D3EA)};
        } else { // black & white
            top = new Color(0x08080A); bottom = new Color(0xF2F2F5);
            blobs = new Color[]{new Color(0x777788), new Color(0xFFFFFF)};
        }
        g.setPaint(new GradientPaint(0, 0, top, 0, n, bottom));
        g.fillRect(0, 0, n, n);
        for (int i = 0; i < 26; i++) {
            float cx = rnd.nextFloat() * n, cy = rnd.nextFloat() * n, r = 14 + rnd.nextFloat() * 30;
            Color c = blobs[rnd.nextInt(blobs.length)];
            Color c0 = new Color(c.getRed(), c.getGreen(), c.getBlue(), idx == 1 ? 120 : 70);
            Color c1 = new Color(c.getRed(), c.getGreen(), c.getBlue(), 0);
            g.setPaint(new RadialGradientPaint(cx, cy, r, new float[]{0f, 1f}, new Color[]{c0, c1}));
            g.fillOval((int) (cx - r), (int) (cy - r), (int) (r * 2), (int) (r * 2));
        }
        for (int i = 0; i < 70; i++) { // star specks
            int x = rnd.nextInt(n), y = rnd.nextInt(n);
            int a = 120 + rnd.nextInt(135);
            Color s = idx == 3 ? new Color(150, 165, 200, a) : (idx == 1 ? new Color(255, 225, 255, a) : new Color(255, 255, 255, a));
            img.setRGB(x, y, s.getRGB());
        }
        g.dispose();
        return Minecraft.getMinecraft().getTextureManager().getDynamicTextureLocation("jonny_wings_" + idx, new DynamicTexture(img));
    }
}
