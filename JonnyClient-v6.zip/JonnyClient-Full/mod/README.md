# Jonny Client (Forge 1.8.9)

## Easiest install (works from your phone)
1. Make a free GitHub account, create a new repo, upload everything in this folder (keep the `.github` folder).
2. Open the repo > Actions tab > "Build Jonny Client" > wait ~3-5 min.
3. Open the finished run > download **JonnyClient-jar** (a zip with ONE file: JonnyClient-1.0.jar).
4. Install Forge 1.8.9 (1.8.9-11.15.1.2318), put JonnyClient-1.0.jar in `.minecraft/mods`, launch the Forge profile.

## Use
- Right Shift = menu, C = zoom (rebind in Controls)
- Menu has "Apply MAX FPS Preset" for one-click graphics settings.

## Recommended JVM args (launcher > profile > JVM arguments)
-Xmx3G -Xms3G -XX:+UseG1GC -XX:+UnlockExperimentalVMOptions -XX:MaxGCPauseMillis=50 -XX:G1NewSizePercent=20 -XX:G1ReservePercent=20 -XX:G1HeapRegionSize=16M

## Local build (PC)
JDK 8 + Gradle 2.14.1: `gradle setupDecompWorkspace build`, jar in build/libs.

## Notes
v4: modern font + menu, 17 HUD mods, entity render-distance scaling, particle cap, occlusion culling (beta), block outline, crosshair, time changer, toggle sneak.

v5: Mixin FPS pack (tile entity culling, particle distance culling, frozen animated textures, no enchant glint). Mixin setup follows the SkyblockAddons recipe.

vX: smooth AA menu, 26 HUD mods, 1.7 block hit, no hurt cam, far armor culling, adaptive render distance, minimized-window FPS cap, capes (Jonny / Geeked / Kai is Zesty), nebula dragon + other wings.

## Next
Mixins (chunk throttle, fast math, raycast culling), HUD drag editor, 1.7 animations, bedwars overlays.
