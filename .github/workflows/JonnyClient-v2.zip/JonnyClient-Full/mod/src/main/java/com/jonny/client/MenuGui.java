package com.jonny.client;

import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;

import java.io.IOException;

public class MenuGui extends GuiScreen {
    private static final int PRESET = 100, CLOSE = 101, DIST_UP = 102, DIST_DOWN = 103;

    @Override
    public void initGui() {
        buttonList.clear();
        Feature[] f = Feature.values();
        for (int i = 0; i < f.length; i++) {
            int col = i % 2, row = i / 2;
            buttonList.add(new GuiButton(i, width / 2 - 155 + col * 160, 40 + row * 24, 150, 20, text(f[i])));
        }
        int by = 40 + (f.length / 2 + 1) * 24;
        buttonList.add(new GuiButton(DIST_DOWN, width / 2 - 155, by, 20, 20, "-"));
        buttonList.add(new GuiButton(DIST_UP, width / 2 + 135, by, 20, 20, "+"));
        buttonList.add(new GuiButton(PRESET, width / 2 - 100, by + 28, 200, 20, "Apply MAX FPS Preset"));
        buttonList.add(new GuiButton(CLOSE, width / 2 - 100, by + 52, 200, 20, "Done"));
    }

    private String text(Feature f) { return f.label + ": " + (f.enabled ? "\u00a7aON" : "\u00a7cOFF"); }

    @Override
    protected void actionPerformed(GuiButton b) throws IOException {
        if (b.id < Feature.values().length) {
            Feature f = Feature.values()[b.id];
            f.enabled = !f.enabled;
            b.displayString = text(f);
        } else if (b.id == PRESET) FpsTuner.applyMaxFps();
        else if (b.id == DIST_UP) Config.entityCullDistance = Math.min(128, Config.entityCullDistance + 8);
        else if (b.id == DIST_DOWN) Config.entityCullDistance = Math.max(16, Config.entityCullDistance - 8);
        else if (b.id == CLOSE) mc.displayGuiScreen(null);
        Config.save();
    }

    @Override
    public void drawScreen(int mx, int my, float pt) {
        drawDefaultBackground();
        drawCenteredString(fontRendererObj, "\u00a7lJonny Client", width / 2, 15, 0xFFFFFF);
        int by = 40 + (Feature.values().length / 2 + 1) * 24;
        drawCenteredString(fontRendererObj, "Entity cull distance: " + (int) Config.entityCullDistance, width / 2, by + 6, 0xFFFFFF);
        super.drawScreen(mx, my, pt);
    }

    @Override
    public boolean doesGuiPauseGame() { return false; }
}
