package com.jonny.client;

public enum Feature {
    TOGGLE_SPRINT("Toggle Sprint", true),
    FULLBRIGHT("Fullbright", false),
    ZOOM("Zoom (hold C)", true),
    HUD_FPS("HUD: FPS", true),
    HUD_CPS("HUD: CPS", true),
    HUD_PING("HUD: Ping", true),
    KEYSTROKES("Keystrokes", true),
    ENTITY_CULLING("Entity Distance Culling", true),
    ARMOR_STAND_CULL("Hide Armor Stands", false),
    LOW_FIRE("Low Fire Overlay", true),
    NO_WEATHER("Disable Weather", true),
    LOW_PARTICLES("Minimal Particles", true);

    public final String label;
    public final boolean def;
    public boolean enabled;

    Feature(String label, boolean def) { this.label = label; this.def = def; this.enabled = def; }
}
