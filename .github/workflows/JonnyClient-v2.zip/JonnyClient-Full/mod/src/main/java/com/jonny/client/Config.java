package com.jonny.client;

import java.io.*;
import java.util.Properties;

public class Config {
    public static double entityCullDistance = 40.0;
    private static File file;

    public static void load(File f) {
        file = f;
        Properties p = new Properties();
        try (FileInputStream in = new FileInputStream(f)) {
            p.load(in);
            for (Feature ft : Feature.values())
                ft.enabled = Boolean.parseBoolean(p.getProperty(ft.name(), String.valueOf(ft.def)));
            entityCullDistance = Double.parseDouble(p.getProperty("entityCullDistance", "40"));
        } catch (Exception ignored) {}
    }

    public static void save() {
        Properties p = new Properties();
        for (Feature ft : Feature.values()) p.setProperty(ft.name(), String.valueOf(ft.enabled));
        p.setProperty("entityCullDistance", String.valueOf(entityCullDistance));
        try {
            file.getParentFile().mkdirs();
            try (FileOutputStream out = new FileOutputStream(file)) { p.store(out, "Jonny Client"); }
        } catch (Exception ignored) {}
    }
}
