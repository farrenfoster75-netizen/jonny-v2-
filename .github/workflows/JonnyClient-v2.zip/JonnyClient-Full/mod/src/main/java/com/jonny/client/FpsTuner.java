package com.jonny.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.settings.GameSettings;

public class FpsTuner {
    /** One-click max FPS preset. */
    public static void applyMaxFps() {
        GameSettings s = Minecraft.getMinecraft().gameSettings;
        s.fancyGraphics = false;
        s.clouds = 0;
        s.ambientOcclusion = 0;
        s.particleSetting = 2;
        s.renderDistanceChunks = 8;
        s.enableVsync = false;
        s.limitFramerate = 260;
        s.entityShadows = false;
        s.mipmapLevels = 0;
        s.useVbo = true;
        s.saveOptions();
    }
}
