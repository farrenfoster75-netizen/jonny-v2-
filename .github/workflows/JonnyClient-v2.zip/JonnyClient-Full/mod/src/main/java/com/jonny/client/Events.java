package com.jonny.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.entity.item.EntityArmorStand;
import net.minecraftforge.client.event.*;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class Events {
    private final Minecraft mc = Minecraft.getMinecraft();
    private static final List<Long> clicks = new ArrayList<>();
    private float savedGamma = -1f;

    public static int getCps() {
        long now = System.currentTimeMillis();
        Iterator<Long> it = clicks.iterator();
        while (it.hasNext()) if (now - it.next() > 1000) it.remove();
        return clicks.size();
    }

    @SubscribeEvent
    public void onTick(TickEvent.ClientTickEvent e) {
        if (e.phase != TickEvent.Phase.END) return;

        if (JonnyClient.menuKey.isPressed()) mc.displayGuiScreen(new MenuGui());
        if (mc.thePlayer == null || mc.theWorld == null) return;

        if (Feature.TOGGLE_SPRINT.enabled && mc.currentScreen == null
                && mc.gameSettings.keyBindForward.isKeyDown() && !mc.thePlayer.isUsingItem()) {
            KeyBinding.setKeyBindState(mc.gameSettings.keyBindSprint.getKeyCode(), true);
        }

        if (Feature.FULLBRIGHT.enabled) {
            if (savedGamma < 0) savedGamma = mc.gameSettings.gammaSetting;
            mc.gameSettings.gammaSetting = 100f;
        } else if (savedGamma >= 0) {
            mc.gameSettings.gammaSetting = savedGamma;
            savedGamma = -1f;
        }

        if (Feature.NO_WEATHER.enabled) {
            mc.theWorld.setRainStrength(0f);
            mc.theWorld.setThunderStrength(0f);
        }

        if (Feature.LOW_PARTICLES.enabled) mc.gameSettings.particleSetting = 2;
    }

    @SubscribeEvent
    public void onMouse(MouseEvent e) {
        if (e.button == 0 && e.buttonstate) clicks.add(System.currentTimeMillis());
    }

    @SubscribeEvent
    public void onFov(FOVUpdateEvent e) {
        if (Feature.ZOOM.enabled && JonnyClient.zoomKey.isKeyDown()) e.newfov = e.fov * 0.25f;
    }

    @SubscribeEvent
    public void onRenderLiving(RenderLivingEvent.Pre e) {
        if (mc.thePlayer == null || e.entity == mc.thePlayer) return;
        if (Feature.ARMOR_STAND_CULL.enabled && e.entity instanceof EntityArmorStand) {
            e.setCanceled(true);
            return;
        }
        if (Feature.ENTITY_CULLING.enabled
                && mc.thePlayer.getDistanceToEntity(e.entity) > Config.entityCullDistance) {
            e.setCanceled(true);
        }
    }

    @SubscribeEvent
    public void onOverlay(RenderBlockOverlayEvent e) {
        if (Feature.LOW_FIRE.enabled
                && e.overlayType == RenderBlockOverlayEvent.OverlayType.FIRE) e.setCanceled(true);
    }
}
