package com.jonny.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.network.NetworkPlayerInfo;
import net.minecraft.client.settings.KeyBinding;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class Hud {
    private final Minecraft mc = Minecraft.getMinecraft();

    @SubscribeEvent
    public void onRender(RenderGameOverlayEvent.Text e) {
        if (mc.thePlayer == null || mc.gameSettings.showDebugInfo) return;
        FontRenderer fr = mc.fontRendererObj;
        int y = 4;
        if (Feature.HUD_FPS.enabled) fr.drawStringWithShadow("FPS: " + Minecraft.getDebugFPS(), 4, y, 0xFFFFFF); y += 10;
        if (Feature.HUD_CPS.enabled) fr.drawStringWithShadow("CPS: " + Events.getCps(), 4, y, 0xFFFFFF); y += 10;
        if (Feature.HUD_PING.enabled) {
            NetworkPlayerInfo info = mc.getNetHandler() == null ? null
                    : mc.getNetHandler().getPlayerInfo(mc.thePlayer.getUniqueID());
            fr.drawStringWithShadow("Ping: " + (info == null ? 0 : info.getResponseTime()) + "ms", 4, y, 0xFFFFFF);
        }
        if (Feature.KEYSTROKES.enabled) drawKeystrokes(fr, 4, 44);
    }

    private void drawKeystrokes(FontRenderer fr, int x, int y) {
        key(fr, mc.gameSettings.keyBindForward, "W", x + 22, y);
        key(fr, mc.gameSettings.keyBindLeft, "A", x, y + 22);
        key(fr, mc.gameSettings.keyBindBack, "S", x + 22, y + 22);
        key(fr, mc.gameSettings.keyBindRight, "D", x + 44, y + 22);
    }

    private void key(FontRenderer fr, KeyBinding kb, String label, int x, int y) {
        Gui.drawRect(x, y, x + 20, y + 20, kb.isKeyDown() ? 0xAAFFFFFF : 0x80000000);
        fr.drawString(label, x + 7, y + 6, kb.isKeyDown() ? 0x000000 : 0xFFFFFF);
    }
}
